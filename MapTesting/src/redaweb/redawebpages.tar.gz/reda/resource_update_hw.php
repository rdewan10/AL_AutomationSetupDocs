<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  resource_update_hw.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
include 'func.php';
mysqlSetup($db);
$font_color = "#005830";
?>

<html>
<head>
  <title>LeapFrog HW Lab Resource Update</title> <!-- The <title> tag denotes what is displayed on bar
                                                         at the top of the browser -->
  <link rel="stylesheet" type="text/css" href="reda.css">
</head>

<div id="banner"><h4><center>HW Lab Resource Update</center></h4><h5><center><b>LeapFrog</b></center></h5></div>

<?php
echo "<div><center><font face=\"arial\" size=4 color=\"$font_color\">";
echo "<br><br><br>";

  if($_POST != NULL){
    // get form inputs
    //echo print_r($_POST);
    //echo "<br>";
    while(list($key, $value) = each($_POST)){
      $pos = strpos($key,"ResourceID"); 
      if ($pos !== FALSE) {
        $resquery .= "ResourceID=$value OR ";
      } elseif ($key != "submit") {
        $input[$key] = $value;
        $fields .= "$key=\"$value\","; 
      }
    }

    //check that user was input
    if ($input[User] == "" && $input[State] == "reserved") {
      echo "No username specified for reservation!  Use browser back button to add user.";
    } else {
      if (strpos($fields,"reserve")===FALSE) {
        $fields .= "DurationHrs=NULL,";
      }
      $fields .= "Timestamp=NOW()";
    
      echo "<br>";

      // update resource status
      $resquery = substr($resquery,0,-3);
      $query = "UPDATE ResourcesHW SET $fields WHERE $resquery";
      $result = mysql_query($query,$db);

      if ($result == 1) {
        echo "Resource status update successful";
      } else {
        echo "Resource status update failure: $result";
      }

      //echo "$query";
    }
  } else {
     echo "No form input posted, you must view this page via report_check_hw.php!";
  }  
?>

<br><br><br>
<a href=resource_status_hw.php>Resource Status Page</a>

</font></center></div>
</html>
