<?php
	include 'func.php';
	mysqlSetup($db);	
	
	function grabOptionsInTable($table, $current, $db) {
		$query="SELECT "."$table"."."."$table"."ID".", "."$table".".Description FROM "."$table";
		$result = mysql_query($query,$db);
		$return = "";
		while($option = mysql_fetch_row($result)) {
			$return = $return . "<option value='" . $option[0] . "'";
			if ($option[1] == $current) $return = $return . " SELECTED";
			$return = $return . ">" . $option[1] . "</option>";
		}
		return $return;
	}
?>

<html>
	<head>
		<title>BOLTS: Broadband Online Large Tracking System</title>
		<link rel="shortcut icon" href="favicon.ico" >
		<link rel="stylesheet" type="text/css" href="bolts.css">
		<script>
                        <?php
                                echo "function GrabAgilePartNums(proto) {\n";
                                $query="SELECT * FROM prototype";
                                $result_proto = mysql_query($query,$db);
                                while($option_proto = mysql_fetch_row($result_proto)) {
                                        echo "if (proto==" . $option_proto[0] . ") {\ndocument.getElementById(\"AgilePartNums\").innerHTML=\"<select name ='agilepartnum'>";
                                        $query="SELECT * FROM agilepartnum WHERE PrototypeID=" . $option_proto[0];
                                        $result_agile = mysql_query($query,$db);
                                        while ($option_agile = mysql_fetch_row($result_agile)) echo "<option value='" . $option_agile[0] . "'>" . $option_agile[0] . " - " . $option_agile[2] . "</option>";
                                        echo "</select>\";\n}\n";
                                }
                                echo "}\n";
                        ?>
		</script>
	</head>
	
	<body bgcolor="#FFFFFF">
		<div id="banner"><h4><center>BOLTS</center></h4><h5><center><b>Edit Page</b></center></h5></div>
                <div id="subbanner"><a href="index.php"><h6><center><b>Main Page</b></center></h6></a></div>
		<div class="post">
			<?php
				if($_GET != NULL){
					while(list($key, $value) = each($_GET)) $input[$key] = $value;
					if(isset($input["serial"])) {
						$query="SELECT modem.Mac, modem.Serial, modem.ProdDate, prototype.Description 'Prototype', agilepartnum.Description 'Agile Part Number' FROM modem, prototype, agilepartnum WHERE modem.Serial='" . $input["serial"] . "' AND modem.AgilePartNumID=agilepartnum.AgilePartNumID AND prototype.PrototypeID=agilepartnum.PrototypeID";
						$rs = mysql_query($query,$db);
						$serialInfo = mysql_fetch_row($rs);
						echo "<form method=\"post\" action=\"edit.php\"><input type=\"hidden\" name=\"oldSerial\" value=\"" . $input["serial"] . "\"><table>";
						for($i=0;$i<mysql_num_fields($rs);$i++) {
							echo "<tr><td>" . mysql_field_name($rs, $i) . "</td><td>";
							if ($i==3) echo "<select name='prototype' onChange='GrabAgilePartNums(this.value)'>" . grabOptionsInTable("prototype", $serialInfo[$i], $db) . "</select>";
							else if ($i==4) echo "<span id='AgilePartNums'></span>";
							else echo "<input type=\"text\" name=\"" . mysql_field_name($rs, $i) . "\" value=\"" . $serialInfo[$i]  . "\">";
							echo "</td></tr>";
						}
						echo "</table><input type=\"submit\" values=\"Edit\">";
						echo "<input type=\"button\" name=\"Cancel\" value=\"Cancel\" onClick=\"window.location='history.php?serial=". $input["serial"] ."'\" /></form>";
					}
				} else if($_POST != NULL){
					while(list($key, $value) = each($_POST)) $input[$key] = $value;
				
					echo "<center>";
					if(isset($input["oldSerial"])){
						$update1 =	"UPDATE modem SET Mac='" . $input["Mac"] . 
									"',Serial='" . $input["Serial"] . 
									"',ProdDate='" . $input["ProdDate"];
						if ($input["agilepartnum"] != "") $update1 = $update1 . "',AgilePartNumID='" . $input["agilepartnum"];
						$update1 = $update1 . "' WHERE Serial='" . $input["oldSerial"] . "' LIMIT 1";

						$update2 =      "UPDATE event SET Serial='" . $input["Serial"] . "' WHERE Serial='"  . $input["oldSerial"] . "'";
                                        	if(mysql_query($update1,$db)) echo "<p><i>modem</i> Table Update Successful: " . mysql_affected_rows($db). " rows updated!</p>";
                                        	else echo "<p><i>modem</i> Table Update Failed!</p>";
                                        	if(mysql_query($update2,$db)) echo "<p><i>event</i> Table Update Successful: " . mysql_affected_rows($db). " rows updated!</p>";
                                        	else echo "<p><i>event</i> Table Update Failed!</p>";
					}
					echo "<p><a href=\"history.php?serial=" . $input["Serial"] . "\">Return to the Edit Page.</a></p></center>";
				}
			?>
		</div>
	</body>
</html>
