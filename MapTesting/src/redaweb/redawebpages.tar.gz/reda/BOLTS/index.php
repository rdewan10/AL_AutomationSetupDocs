<?php
	include 'func.php';
	mysqlSetup($db);
		
	function grabOptionsInTable($table, $db) {
		$query="SELECT "."$table"."."."$table"."ID".", "."$table".".Description FROM "."$table";
		$result = mysql_query($query,$db);
		$return = "";
		while($option = mysql_fetch_row($result)) $return = $return . "<option value='" . $option[0] . "'>" . $option[1] . "</option>";
		return $return;
	}

	function testModemExistence($input, $db) {
		$format= array(".",":"," ");
		$macRegExp = "^[0-9]{0,12}[a-f][0-9,a-f]{0,12}$";
		$id=str_replace($format,"",$input);
		$query= "SELECT modem.Serial, event.UTID FROM modem, event WHERE ";
		if(ereg($macRegExp,$id)) $query.="modem.Mac";
		else $query.="modem.Serial";
		$query.="='" . $id . "' AND event.Serial=modem.Serial ORDER BY event.DateTime DESC LIMIT 1";
		$result = mysql_query($query,$db);
		return mysql_fetch_row($result);
	}
?>

<html>
	<head>
<link rel="shortcut icon" href="favicon.ico" >		
<title>BOLTS: Broadband Online Large Tracking System</title>
		<link rel="stylesheet" type="text/css" href="bolts.css">
		<script>
			function modemFields(type) {
				if(type=="new") {
					<?php
						echo	"document.getElementById(\"fieldsArea\").innerHTML=\"<input type='hidden' name='eventType' value='new'><table>" .
							"  <tr><td><p>MAC Address</p></td><td><input type='Text' name='mac' size='15' onBlur='validateID(this.value)'></td></tr>" .
							"  <tr><td><p>Serial Number</p></td><td><input type='Text' name='serial' size='15' onBlur='validateID(this.value)'></td></tr>" .
							"  <tr><td><p>Date</p></td><td><input type='Text' name='time' size='15' onBlur='checkTime(this.value)'><font face='Arial' size=0> YYYY-MM-DD. Leave blank to specify date as now.</font></td></tr>" .
							"  <tr><td><p>UTID</p></td><td><input type='Text' name='utid' size='15'><font face='Arial' size=0> UT###. For example: UT108. Do NOT leave a space between UT and ###.</font></td></tr>" .
							"  <tr><td><p>Prototype ID Version</p></td><td><select name='prototype' onChange='GrabAgilePartNums(this.value)'>" . grabOptionsInTable("prototype", $db) . "</select></td></tr>" .
							"  <tr><td><p>Agile Part Number</p></td><td><span id='AgilePartNums'></span></td></tr>" .
							"  <tr><td><p>Location</p></td><td><select name='location'>" . grabOptionsInTable("location", $db) . "</select></td></tr></table>\";";
					?>
				} else if(type=="edit") {
					<?php
						echo 	"document.getElementById(\"fieldsArea\").innerHTML=\"<input type='hidden' name='eventType' value='edit'><table>" .
							"  <tr><td><p>MAC or Serial</p></td><td><input type='Text' name='mac' size='15' onBlur='validateID(this.value)'></td></tr>" .
							"  <tr><td><p>Date</p></td><td><input type='Text' name='time' size='15' onBlur='checkTime(this.value)'><font face='Arial' size=0> YYYY-MM-DD. Leave blank to specify date as now.</font></td></tr>" .
                                                        "  <tr><td><p>UTID</p></td><td><input type='Text' name='utid' size='15'><font face='Arial' size=0> Leave blank to keep existing UTID.</font></td></tr>" .
							"  <tr><td><p>State</p></td><td><select name='state'>" . grabOptionsInTable("state", $db) . "</select></td></tr>" .
							"  <tr><td><p>Location</p></td><td><select name='location'>" . grabOptionsInTable("location", $db) . "</select></td></tr></table>\";";
					?>
				}
			}

			<?php
				echo "function GrabAgilePartNums(proto) {\n";
                		$query="SELECT * FROM prototype";
                		$result_proto = mysql_query($query,$db);
                		while($option_proto = mysql_fetch_row($result_proto)) {
					echo "if (proto==" . $option_proto[0] . ") {\ndocument.getElementById(\"AgilePartNums\").innerHTML=\"<select name ='agilepartnum'>";
					$query="SELECT * FROM agilepartnum WHERE PrototypeID=" . $option_proto[0];
					$result_agile = mysql_query($query,$db);
					while ($option_agile = mysql_fetch_row($result_agile)) echo "<option value='" . $option_agile[0] . "'>" . $option_agile[0] . " - " . $option_agile[2] . "</option>";
					echo "</select>\";\n}\n";
				}
				echo "}\n";
			?>

			function openFlowchart() {
				document.getElementById("Flowchart").innerHTML="<div id='subbanner'><a href='javascript:closeFlowchart()'><h6><center><b>Close Process Flowchart</b></center></h6></a></div><img src='flowchart.jpg' /><br>";
			}
			
			function closeFlowchart() {
				document.getElementById("Flowchart").innerHTML="<div id='subbanner'><a href='javascript:openFlowchart()'><h6><center><b>View Process Flowchart</b></center></h6></a></div>";
			}

			function checkTime(time){
				if(time!=""){
					var strmatch=/^20\d\d-[0-1]\d-[0-3]\d$/;
					if(!strmatch.test(time)) alert("Invalid Date!");
				}
			}

			function validateID(id){
				var id2;
				id2=id.toLowerCase();
				id2=id2.replace(/\./g,"");
				id2=id2.replace(/ /g,"");
				id2=id2.replace(/:/g,"");
				var macRegExp = /^[0-9]{0,12}[a-f][0-9,a-f]{0,12}$/;
				var serialRegExp = /^[0-9]{12}$/;
				if(id2.length !=12 || !macRegExp.test(id2) && !serialRegExp.test(id2)){
					alert("Your MAC address or serial number must be 12 hexadecimal characters (MAC) or 12 numbers (Serial). Only delimiters ':','.', and ' ' are allowed.");
					return false;
				} 
				return true;
			}
		</script>
	</head>

	<body bgcolor="#FFFFFF">
		<div id="banner">
			<h4><center>BOLTS</center></h4>
			<h5><center><b>Broadband Online Large Tracking System</b></center></h5>
		</div>

		<span id='Flowchart'><div id="subbanner"><a href="javascript:openFlowchart()"><h6><center><b>View Process Flowchart</b></center></h6></a></div></span>
		<div id="subbanner"><a href="checkFKconstraints.php"><h6><center><b>Fix Broken Foreign Keys</b></center></h6></a></div>
<!-- UPDATE/INSERT PORTAL-->		
		<?php
			if($_POST != NULL) {
				while(list($key, $value) = each($_POST)) $input[$key] = $value;

				$format=array(".",":"," ");
				$msg=NULL;
				$serial=str_replace($format,"",$input["serial"]);
				$mac=str_replace($format,"",$input["mac"]);

				if($input["eventType"]=="new"){
					$existsID = testModemExistence($serial, $db);

					if ($existsID!="") {
						$msg = "BOLTS SERVER ERROR: Serial number " . $serial . " already exists in modem table!";
					}else if ($input["mac"] == NULL) {
                                                $msg = "BOLTS SERVER ERROR: MAC Address must be non-null for any new modem!";
					}else if ($input["agilepartnum"] == NULL) {
						$msg = "BOLTS SERVER ERROR: Agile Part Number must be non-null for any new modem!";
                                        }else if ($input["location"] == NULL) {
                                                $msg = "BOLTS SERVER ERROR: Location must be non-null for any new modem!";
					}else {
						$insert =	"INSERT INTO modem VALUES(" .
								"'" . $mac . "'," .
								"'" . $serial . "'," .
								"'" . substr($serial,4,4) . "'," .
								"'" . $input["agilepartnum"] . "')";
						echo $insert . "\n";
						if(mysql_query($insert,$db) == FALSE) {
							$msg = "BOLTS SERVER ERROR: Inserting information into modem table failed!";
						}else {
                                                	$insert = "INSERT INTO event VALUES(NULL,'" . $serial . "',";
	                                                if($input["time"]==0) $insert .= "NOW(),";
       		                                        else $insert .= "'" . $input["time"] . "',";
                	                                $insert .= 	"'" . 3 . "'," .
                        	                        		"'" . $input["location"] . "'," .
                                	                		"'" . $input["utid"] . "'," .
                                        	        		"'" . $input["notes"] . "')";
                                                	echo $insert . "\n";
        	                                        if(mysql_query($insert,$db) == FALSE) $msg = "BOLTS SERVER ERROR: Inserting information into event table failed!";
                	                                else echo "Successfully logged modem event";
						}
					}
				} else if($input["eventType"]=="edit"){
                                        $existsID = testModemExistence($mac, $db);

                                        if($existsID == "") {
						$msg = "BOLTS SERVER ERROR: " . $mac . " does not exist!";
					}else if ($input["state"] == NULL) {
						$msg = "BOLTS SERVER ERROR: State must be non-null for any new event!";	
					}else if ($input["location"] == NULL) {
						$msg = "BOLTS SERVER ERROR: Location must be non-null for any new event!";
                                        }else {
						$insert = "INSERT INTO event VALUES(NULL, '" . $existsID[0] . "',";
						if($input["time"]==0) 	$insert .= "NOW(),";
						else 			$insert .= "'" . $input["time"] . "',";
									$insert .= "'" . $input["state"] . "',";
									$insert .= "'" . $input["location"] . "',";
						if($input["utid"]=="")	$insert .= "'" . $existsID[1] . "',";
						else			$insert .= "'" . $input["utid"] . "',";
									$insert .= "'" . $input["notes"] . "')";
						echo $insert;
						if(mysql_query($insert,$db) == FALSE) $msg = "BOLTS SERVER ERROR: Inserting information into events table failed!";
						else echo "Successfully logged modem event!";
					}
				} else $msg="BOLTS SERVER ERROR: event not specified!";

				if ($msg!=NULL) echo "<script>alert(\"$msg\")</script>";
			}
		?>
		<div class="post">
			<form method="post" action="">
				<p class="checkboxes"><input type="radio" name="modemType" value="new" checked onclick="modemFields('new');"><b>Enter New Modem</b></p>
				<p class="checkboxes"><input type="radio" name="modemType" value="edit" onclick="modemFields('edit');"><b>Change Modem Status</b></p>
				<br>
				<span id="fieldsArea"></span>
				<script>
					modemFields('new');
				</script>
				<p>Optional Notes:</p>
				<center><TEXTAREA NAME="notes" ROWS=2 COLS=60></TEXTAREA></center>
				<br>
				<p class="right"><input type="Submit" name="submit" value="Submit"></p>
				<br>
			</form>
		</div>

<!--VIEW STATUS-->
		<script>
			function viewModemStatus(sort) {
				var url="http://reda01.sb.viasat.com/BOLTS/status.php";
				url=url+"?sort="+sort;
				window.location.href=url;
			}
		</script>
		<h3>View Current Status - ALL MODEMS</h3>
		<div class="post">
			<form method="post" action="">
				<p>Sort By 
					<select name="sort">
						<option value="Mac">MAC</option>
						<option value="Serial">Serial</option>
						<option value="UTID">UTID</option>
						<option value="Prototype ID Version">Prototype ID Version</option>
						<option value="Agile Part Number">Agile Part Number</option>
						<option value="Description">Description</option>
						<option value="Last Modification">Last Modification</option>
						<option value="Current State">Current State</option>
						<option value="Current Location">Current Location</option>
						<option value="Notes">Notes</option>
					</select>
				</p>
				<p class="right"><input type="button" value="View Status" onclick='viewModemStatus(sort.value)'></p>
			</form>
		</div>

<!--VIEW EVENTS-->
                <script>
                        function viewEventHistory(sort) {
                                var url="http://reda01.sb.viasat.com/BOLTS/events.php";
                                url=url+"?sort="+sort;
                                window.location.href=url;
                        }
                </script>
                <h3>View Change History - ALL MODEMS</h3>
                <div class="post">
                        <form method="post" action="">
                                <p>Sort By
                                        <select name="sort">
                                                <option value="EventID">EventID</option>
                                                <option value="Serial">Serial</option>
                                                <option value="Timestamp">Timestamp</option>
                                                <option value="Modem Status">Modem Status</option>
                                                <option value="Modem Location">Modem Location</option>
                                                <option value="UTID">UTID</option>
                                                <option value="Notes">Notes</option>
                                        </select>
                                </p>
                                <p class="right"><input type="button" value="View Events" onclick='viewEventHistory(sort.value)'></p>
                        </form>
                </div>
	</body>
</html
