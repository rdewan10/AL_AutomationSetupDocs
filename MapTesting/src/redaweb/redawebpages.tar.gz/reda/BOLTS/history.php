<?php
	include 'func.php';
	mysqlSetup($db);
	
	if($_GET != NULL) while(list($key, $value) = each($_GET))	$input[$key] = $value;

        if(isset($input["deleteSerial"])) {
		$select1 =	"SELECT EventID FROM event WHERE Serial='" . $input["deleteSerial"] . "'";
		$result = mysql_query($select1,$db);
		while($myrow = mysql_fetch_row($result)) {
                	$update1 =      "DELETE FROM event WHERE EventID='"  . $myrow[0] . "' LIMIT 1";
                	if(mysql_query($update1,$db) == FALSE) {
				echo "<p><i>event</i> Table Delete Failed!<br>$update1</p>";
				exit();
			}
		}

                $update1 =      "DELETE FROM modem WHERE Serial='"  . $input["deleteSerial"] . "' LIMIT 1";
                if(mysql_query($update1,$db)) {
                        header('Location:status.php');
                } else {
                        echo "<p><i>modem</i> Table Delete Failed!<br>$update1</p>";
                        exit();
                }
        } else if(isset($input["deleteId"])) {
       		$update1 =      "DELETE FROM event WHERE EventID='"  . $input["deleteId"] . "' LIMIT 1";
		if(mysql_query($update1,$db)) {
                	header('Location:history.php?serial='.$input["serial"]);
		} else {
                	echo "<p><i>event</i> Table Delete Failed!<br>$update1</p>";
			exit();
		}	
        }
	
	if($input["mac"]!=NULL){
		$idType = "Mac";
		$id = $input["mac"];
	} elseif($input["serial"]!=NULL){
		$idType = "Serial";
		$id = $input["serial"];
	} else{
		$idType = NULL;
		$id = NULL;
	}
	
	if ($idType==NULL) {
		echo "&nbsp;No modem mac or serial specified. Must use one of the following formats:<br>";
		echo "&nbsp;http://reda01.sb.viasat.com/BOLTS/history.php?mac=00a0bc012345<br>";
		echo "&nbsp;http://reda01.sb.viasat.com/BOLTS/history.php?serial=011606192842";
	} else {
?>

<html>
	<script>
		function confirmEventDelete(serial, id) {
			if (confirm("Are you sure you want to delete this?")) window.location="history.php?serial=" + serial + "&deleteId="+id;
		}
                function confirmModemDelete(serial) {
                        if (confirm("Are you sure you want to delete this modem?")) window.location="history.php?deleteSerial=" + serial;
                }
	</script>

	<head>
		<link rel="shortcut icon" href="favicon.ico" >
		<link rel="stylesheet" type="text/css" href="bolts.css">
		<title>BOLTS: Modem History - <?php echo $id; ?></title>
	</head>

	<body bgcolor="#FFFFFF">
		<div id="banner">
			<h4><center>BOLTS</center></h4>
			<h5><center><b>Modem History Report</b></center></h5>
		</div>
		<div id="subbanner"><a href="index.php"><h6><center><b>Main Page</b></center></h6></a></div>
		<h3><center>Modem Details</center></h3>
		<div class="post" style="width: 256px">
			<table cellpadding=2 cellspacing=2>
				<?php
					$query = "SELECT * FROM modem WHERE " . $idType .  " = '" . $id . "'";
					$result = mysql_query($query,$db);
					$myrow = mysql_fetch_row($result);
					for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<tr><td><p class=\"tableheader\">%s</p></td><td><p class=\"table\">%s</p></td></tr>", mysql_field_name($result, $i), $myrow[$i]);
				?>
			</table>
			<br>
			<a href=<?php echo "'edit.php?serial=" .  $myrow[1] . "'"; ?>><p>Edit</p></a>
			<a href="javascript:confirmModemDelete('<?php echo $myrow[1] ?>')"><p>Delete</p></a>
		</div>

		<h3><center>Modem Event History</center></h3>
		<div class="post" style="width: 100%">
			<table cellpadding=2 cellspacing=2>
				<?php
					$query = "SELECT event.Serial, event.EventID, event.DateTime 'Date', state.Description 'Current State', location.Description 'Current Location', event.UTID 'UTID', event.Notes FROM modem, event, state, location WHERE modem." . $idType . " = '" . $id . "' AND modem.Serial = event.Serial AND event.StateID = state.StateID AND event.LocationID = location.LocationID ORDER BY event.DateTime";
					echo "<tr>";
					$result = mysql_query($query,$db);
                                        for ($i=1; $i<mysql_num_fields($result); $i++) printf("<td><p class=\"tableheader\">%s</p></td>", mysql_field_name($result, $i));
					echo "<td><p class=\"tableheader\">Link</p></td></tr>";
					$count=0;
                                        while($myrow = mysql_fetch_row($result)) {
						echo "<tr>";
						for ($i = 1; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"table\">%s</p></td>", $myrow[$i]);
						if ($count>0) printf("<td><p class=\"table\"><a href=\"javascript:confirmEventDelete('%s', '%s')\">Delete</a></p></td>", $myrow[0], $myrow[1]);
						echo "</tr>";
						$count++;
                                        }
				?>
			</table>
		</div>
	</body>
</html>

<?php
	}
?>
