<?php
/******************************************************************************
 *
 & Filename: csv.php
 * Purpose: Basically, this page prints out the data that would normally be 
 *          displayed on the results table. This allows for someone to
 *          download this page and then save it as a .csv file. The entries 
 *          are comma "," delimited.
 *
 *****************************************************************************/
include 'func.php';
header('Content-type: application/ms-excel');
header("Content-Disposition: attachment; filename=BOLTS_export.csv");
mysqlSetup($db);

//Pull in the variables that the user supplied us...
while(list($key, $value) = each($_GET)){
  $input[$key] = $value;
  if($input["sort"]!=NULL) $sort = $input["sort"];
  else $sort = "Mac";
}

$query =        "SELECT event.EventID, event.Serial, event.DateTime 'Timestamp', state.Description 'Modem Status', location.Description 'Modem Location', event.UTID, event.Notes " .
                                                        "FROM event, state, location " .
                                                        "WHERE event.LocationID = location.LocationID AND event.StateID = state.StateID " .
                                                        "ORDER BY `" . $sort . "`";

$query_count =  "SELECT count(*) FROM event";

$result = mysql_query($query,$db);
$result_count = mysql_query($query_count,$db);
//Start filling out the CSV table...
for ($i = 0; $i < mysql_num_fields($result);$i++){
  if($i != 0){
    echo ",";
  }
  echo mysql_field_name($result, $i);
}
echo "\n";

while ($myrow = mysql_fetch_row($result)) {
  for ($i = 0; $i < mysql_num_fields($result);$i++){
    if($i !=0){
      echo ",";
    }
    else{
    $myrow[$i]=strtoupper($myrow[$i]); 
    }
    echo str_replace("\r"," ",str_replace("\n"," ",str_replace(",",".",$myrow[$i])));
  }
  echo "\n";
}
?>

