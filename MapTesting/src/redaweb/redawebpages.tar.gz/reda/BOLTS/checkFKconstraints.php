<?php
	include 'func.php';
	mysqlSetup($db);

        if($_GET != NULL) while(list($key, $value) = each($_GET))       $input[$key] = $value;

        if(isset($input["deleteEvent"])) {
                $update1 =      "DELETE FROM event WHERE EventID='"  . $input["deleteEvent"] . "' LIMIT 1";
                if(mysql_query($update1,$db)) {
			header('Location:checkFKconstraints.php');
                } else {
                        echo "<p><i>event</i> Table Delete Failed!<br>$update1</p>";
                        exit();
                }
        } else if(isset($input["deleteAgilePartNum"])) {
                $update1 =      "DELETE FROM agilepartnum WHERE AgilePartNumID='"  . $input["deleteAgilePartNum"] . "' LIMIT 1";
                if(mysql_query($update1,$db)) {
			header('Location:checkFKconstraints.php');
                } else {
                        echo "<p><i>agilepartnum</i> Table Delete Failed!<br>$update1</p>";
                        exit();
                }
        } else if(isset($input["deleteModem"])) {
	        $update1 =      "DELETE FROM modem WHERE Mac = '"  . $input["deleteModem"] . "' AND Serial = '" . $input["deleteSerial"] . "' LIMIT 1";
                if(mysql_query($update1,$db)) {
                        header('Location:checkFKconstraints.php');
                } else {
                        echo "<p><i>modem</i> Table Delete Failed!<br>$update1</p>";
                        exit();
                }
        }

?>

<html>
        <script>
                function confirmEventDelete(EventID) {
                        if (confirm("Are you sure you want to delete this?")) window.location="checkFKconstraints.php?deleteEvent=" + EventID;
                }
		function confirmAgilePartNumDelete(AgilePartNumID) {
			if (confirm("Are you sure you want to delete this?")) window.location="checkFKconstraints.php?deleteAgilePartNum=" + AgilePartNumID;
		}
                function confirmModemDelete(Mac, Serial) {
                        if (confirm("Are you sure you want to delete this?")) window.location="checkFKconstraints.php?deleteModem=" + Mac + "&deleteSerial=" + Serial;
                }
        </script>

	<head>
		<link rel="shortcut icon" href="favicon.ico" >
		<link rel="stylesheet" type="text/css" href="bolts.css">
		<title>BOLTS: Check Foreign Key Constraints</title>
	</head>
	
	<body bgcolor="#FFFFFF">
		<div id="banner">
			<h4><center>BOLTS</center></h4>
			<h5><center><b>Check Foreign Key Constraints</b></center></h5>
		</div>
		<div id="subbanner"><a href="index.php"><h6><center><b>Main Page</b></center></h6></a></div>
		<div class="post" style="width: 100%">
			<table cellpadding=2 cellspacing=2>
				<?php
					$event_query = 	"SELECT modem.Mac, event.EventID, event.Serial, event.UTID, state.Description as 'State', location.Description as 'Location' FROM ((event LEFT JOIN state ON event.StateID=state.StateID) LEFT JOIN location ON event.LocationID=location.LocationID) LEFT JOIN modem ON event.Serial=modem.Serial WHERE location.LocationID IS NULL OR state.StateID IS NULL OR modem.Mac IS NULL";
					$result = mysql_query($event_query,$db);
					echo "<tr><i>The following rows in the EVENT table have broken foreign keys to STATE, LOCATION, or MODEM tables!<i></tr><tr>";
					for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"tableheader\">" . mysql_field_name($result,$i) . "</p></td>");
					echo "<td><p class=\"tableheader\">Link</p></td></tr>";
					while($myrow = mysql_fetch_row($result)) {
						echo "<tr>";
						for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"table\">%s</p></td>", $myrow[$i]);
						printf("<td><p class=\"table\"><a href=\"javascript:confirmEventDelete(%s)\">Delete</a></p></td>", $myrow[1]);
						echo "</tr>";
					}
				?>
			</table>
		</div>
                <div class="post" style="width: 100%">
                        <table cellpadding=2 cellspacing=2>
                                <?php
                                        $event_query =  "SELECT agilepartnum.AgilePartNumID, prototype.Description as 'Prototype' from agilepartnum LEFT JOIN prototype ON agilepartnum.PrototypeID=prototype.PrototypeID where prototype.PrototypeID IS NULL";
                                        $result = mysql_query($event_query,$db);
					echo "<tr><i>The following rows in the AGILEPARTNUM table have broken foreign keys to PROTOTYPE table!<i></tr><tr>";
                                        for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"tableheader\">" . mysql_field_name($result,$i) . "</p></td>");
                                        echo "<td><p class=\"tableheader\">Link</p></td></tr>";
                                        while($myrow = mysql_fetch_row($result)) {
                                                echo "<tr>";
                                                for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"table\">%s</p></td>", $myrow[$i]);
                                                printf("<td><p class=\"table\"><a href=\"javascript:confirmAgilePartNumDelete(%s)\">Delete</a></p></td>", $myrow[0]);
                                                echo "</tr>";
                                        }
                                ?>
                        </table>
                </div>
                <div class="post" style="width: 100%">
                        <table cellpadding=2 cellspacing=2>
                                <?php
                                        $event_query =  "SELECT modem.Mac, modem.Serial, event.EventID, event.UTID, agilepartnum.AgilePartNumID, event.DateTime from (modem LEFT JOIN event on modem.Serial=event.Serial) LEFT JOIN agilepartnum ON modem.AgilePartNumID=agilepartnum.AgilePartNumID where event.EventID IS NULL OR agilepartnum.AgilePartNumID IS NULL group by modem.Mac, modem.Serial, modem.AgilePartNumID, event.UTID, event.DateTime";
                                        $result = mysql_query($event_query,$db);
					echo "<tr><i>The following rows in the MODEM table have broken foreign keys to EVENT or AGILEPARTNUM tables!<i></tr><tr>";
                                        for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"tableheader\">" . mysql_field_name($result,$i) . "</p></td>");
                                        echo "<td><p class=\"tableheader\">Link</p></td></tr>";
                                        while($myrow = mysql_fetch_row($result)) {
                                                echo "<tr>";
                                                for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"table\">%s</p></td>", $myrow[$i]);
                                                printf("<td><p class=\"table\"><a href=\"javascript:confirmModemDelete('%s', '%s')\">Delete</a></p></td>", $myrow[0], $myrow[1]);
                                                echo "</tr>";
                                        }
                                ?>
                        </table>
                </div>
	</body>
</html>
