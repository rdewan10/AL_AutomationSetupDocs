<?php
	function mysqlSetup(&$db) {
		$db = mysql_connect("localhost", "root", "Dankberg1"); //Specify database server (localhost) and login (leapfrog).
		if (!$db) {
			die('Could not connect: ' . mysql_error());
		}
		mysql_select_db("bolts",$db); //Specify our database (reda2)
	}
?>
