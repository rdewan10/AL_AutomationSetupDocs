<?php
	include 'func.php';
	mysqlSetup($db);

	if($_GET != NULL) while(list($key, $value) = each($_GET)) $input[$key] = $value;

	if($input["sort"]!=NULL) $sort = $input["sort"];
	else $sort = "EventID";
?>

<html>
	<head>
		<link rel="shortcut icon" href="favicon.ico" >
		<link rel="stylesheet" type="text/css" href="bolts.css">
		<title>BOLTS: Change History</title>
	</head>
	
	<body bgcolor="#FFFFFF">
		<div id="banner">
			<h4><center>BOLTS</center></h4>
			<h5><center><b>Modem Change History</b></center></h5>
		</div>
		<div id="subbanner"><a href="index.php"><h6><center><b>Main Page</b></center></h6></a></div>
<input type=hidden name=sort>
                <div id="subbanner"><a href="csv_events.php?sort=UTID" sort ><h6><center><b>Export results to CSV</b></center></h6></a></div>
		<div class="post" style="width: 100%">
			<table cellpadding=2 cellspacing=2>
				<?php
					$query =	"SELECT event.EventID, event.Serial, event.DateTime 'Timestamp', state.Description 'Modem Status', location.Description 'Modem Location', event.UTID, event.Notes " .
							"FROM event, state, location " .
							"WHERE event.LocationID = location.LocationID AND event.StateID = state.StateID " .
							"ORDER BY `" . $sort . "`";
					$query_count =	"SELECT count(*) FROM event";

					$result = mysql_query($query,$db);
					$result_count = mysql_query($query_count,$db);

					printf("<tr>");
					for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"tableheader\"><a href=\"events.php?sort=" . mysql_field_name($result,$i) . "\">". mysql_field_name($result,$i) . "</a></p></td>");
					printf("</tr>");

					$count = 0;
					$qcount = mysql_fetch_row($result_count);

					while($myrow = mysql_fetch_row($result)) {
						$count++;
						printf("<tr>");
						for ($i = 0; $i < mysql_num_fields($result);$i++) {
							if ($i == 1) printf("<td><p class=\"table\"><a href=\"history.php?serial=" . $myrow[$i] . "\">". $myrow[$i] . "</a></p></td>");
							else printf("<td><p class=\"table\">%s</p></td>", $myrow[$i]);
						}
						printf("</tr>");
					}

					printf("<tr><i>" . $count . " out of " . $qcount[0] . " events returned!</i></tr>"); 
				?>
			</table>
		</div>
	</body>
</html>
