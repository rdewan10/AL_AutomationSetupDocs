<?php
/******************************************************************************
 *
 & Filename: csv.php
 * Purpose: Basically, this page prints out the data that would normally be 
 *          displayed on the results table. This allows for someone to
 *          download this page and then save it as a .csv file. The entries 
 *          are comma "," delimited.
 *
 *****************************************************************************/
include 'func.php';
header('Content-type: application/ms-excel');
header("Content-Disposition: attachment; filename=BOLTS_export.csv");
mysqlSetup($db);

//Pull in the variables that the user supplied us...
while(list($key, $value) = each($_GET)){
  $input[$key] = $value;
  if($input["sort"]!=NULL) $sort = $input["sort"];
  else $sort = "Mac";
}

$query =        "SELECT modem.Mac, modem.Serial, event.UTID, prototype.Description 'Prototype', agilepartnum.AgilePartNumID 'Agile Part Number', agilepartnum.Description 'Description', event.DateTime 'Last Modification', state.Description 'Current State', location.Description 'Current Location', event.Notes " . "FROM modem, event, (select Serial, max(DateTime) 'DateTime' From event GROUP BY Serial) as latest_event, state, prototype, agilepartnum, location " . "WHERE modem.Serial = latest_event.Serial AND event.Serial = latest_event.Serial AND event.DateTime = latest_event.DateTime AND modem.AgilePartNumID = agilepartnum.AgilePartNumID AND agilepartnum.PrototypeID = prototype.PrototypeID AND event.LocationID = location.LocationID AND event.StateID = state.StateID " . "ORDER BY `" . $sort . "`";

$result = mysql_query($query,$db);
//Start filling out the CSV table...
for ($i = 0; $i < mysql_num_fields($result);$i++){
  if($i != 0){
    echo ",";
  }
  echo mysql_field_name($result, $i);
}
echo "\n";

while ($myrow = mysql_fetch_row($result)) {
  for ($i = 0; $i < mysql_num_fields($result);$i++){
    if($i !=0){
      echo ",";
    }
    else{
    $myrow[$i]=strtoupper($myrow[$i]); 
    }
    echo str_replace("\r"," ",str_replace("\n"," ",str_replace(",",".",$myrow[$i])));
  }
  echo "\n";
}
?>

