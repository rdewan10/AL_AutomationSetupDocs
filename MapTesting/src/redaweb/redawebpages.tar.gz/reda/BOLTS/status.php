<?php
	include 'func.php';
	mysqlSetup($db);

	if($_GET != NULL) while(list($key, $value) = each($_GET)) $input[$key] = $value;

	if($input["sort"]!=NULL) $sort = $input["sort"];
	else $sort = "Mac";
?>

<html>
	<head>
		<link rel="stylesheet" type="text/css" href="bolts.css">
		<title>BOLTS: Modem Status</title>
		<link rel="shortcut icon" href="favicon.ico" >
	</head>
	
	<body bgcolor="#FFFFFF">
		<div id="banner">
			<h4><center>BOLTS</center></h4>
			<h5><center><b>Modem Current Status</b></center></h5>
		</div>
		<div id="subbanner"><a href="index.php"><h6><center><b>Main Page</b></center></h6></a></div>
		<input type=hidden name=sort>
		<div id="subbanner"><a href="csv.php?sort=UTID" sort ><h6><center><b>Export results to CSV</b></center></h6></a></div>
		<div class="post" style="width: 100%">
			<table cellpadding=2 cellspacing=2>
				<?php
					$query = 	"SELECT modem.Mac, modem.Serial, event.UTID, prototype.Description 'Prototype', agilepartnum.AgilePartNumID 'Agile Part Number', agilepartnum.Description 'Description', event.DateTime 'Last Modification', state.Description 'Current State', location.Description 'Current Location', event.Notes " .
							"FROM modem, event, (select Serial, max(DateTime) 'DateTime' From event GROUP BY Serial) as latest_event, state, prototype, agilepartnum, location " .
							"WHERE modem.Serial = latest_event.Serial AND event.Serial = latest_event.Serial AND event.DateTime = latest_event.DateTime AND modem.AgilePartNumID = agilepartnum.AgilePartNumID AND agilepartnum.PrototypeID = prototype.PrototypeID AND event.LocationID = location.LocationID AND event.StateID = state.StateID " .
							"ORDER BY `" . $sort . "`";
					$query_count =	"SELECT count(*) FROM modem";

					$result = mysql_query($query,$db);
					$result_count = mysql_query($query_count,$db);

					printf("<tr>");
					for ($i = 0; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"tableheader\"><a href=\"status.php?sort=" . mysql_field_name($result,$i) . "\">". mysql_field_name($result,$i) . "</a></p></td>");
					printf("</tr>");

					$count=0;
					$qcount=mysql_fetch_row($result_count);

					while($myrow = mysql_fetch_row($result)) {
						$count++;
						printf("<tr><td><p class=\"table\"><a href=\"history.php?mac=" . $myrow[0] . "\">". $myrow[0] . "</a></p></td>");
						printf("<td><p class=\"table\"><a href=\"history.php?serial=" . $myrow[1] . "\">". $myrow[1] . "</a></p></td>");
						for ($i = 2; $i < mysql_num_fields($result);$i++) printf("<td><p class=\"table\">%s</p></td>", $myrow[$i]);
						printf("</tr>");
					}
					printf("<tr><i>" . $count . " out of " . $qcount[0] . " modems returned!</i></tr>");
				?>
			</table>
		</div>
	</body>
</html>
