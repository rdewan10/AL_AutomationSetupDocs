<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  admin.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: admin.php
 * Purpose: Simple page. Displays the admin webpage in Reda.
 *
 *****************************************************************************/
?>
<!-- Refer to comments in index.php for help -->
<html>
<head>
<title>Help Page</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
include 'func.php';
bodyStyle();
banner();
navbar1("admin");
navbar2("admin", "");
navbar3("admin");
?>
</body>
</html>
