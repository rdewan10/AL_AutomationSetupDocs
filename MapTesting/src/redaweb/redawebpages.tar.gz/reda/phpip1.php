<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  phpip1.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: phpip_func.php
 * Purpose: This page is what the administrator should edit to include 
 *          info on connecting to the phpip database.
 *
 *****************************************************************************/

//Info about the database
$phpip_dbHost = "192.168.24.10";
$phpip_dbUsername = "phpipadmin";
$phpip_dbPassword = "1pN3tw0rk";
$phpip_dbName = "phpip_management";

function phpip_mysqlSetup(&$phpip_db) {
  global $phpip_dbHost, $phpip_dbUsername, $phpip_dbPassword, $phpip_dbName;
  if($phpip_dbPassword==""){
    $phpip_db = mysql_connect($phpip_dbHost, $phpip_dbUsername);
  } else {
    $phpip_db = mysql_connect($phpip_dbHost, $phpip_dbUsername, $phpip_dbPassword);
  }
  if (!$phpip_db) {
    echo "Unable to connect to phpip database: " . mysql_error() . "<br>";
  }
  if (!mysql_select_db($phpip_dbName,$phpip_db)) {
    echo "Unable to select " . $phpip_dbName . ": " . mysql_error() . "<br>";
  }
}

function getPhpipArray($whereString) {
  phpip_mysqlSetup($phpip_db);
  $query = "SELECT ip,deviceOwner,deviceModel,description FROM addresses WHERE $whereString";
  //echo "$query<br>"; 

  $result = mysql_query($query);
  while ($myrow = mysql_fetch_assoc($result)) {
    $ip = $myrow['ip'];
    $owner = $myrow['deviceOwner'];
    $type = $myrow['deviceModel'];
    $desc = $myrow['description'];
    //echo "$ip#$owner#$type#$desc<br>";
    $ipArray[$owner][$type][$desc]=$ip;
  }
  return ($ipArray);
}

?>
