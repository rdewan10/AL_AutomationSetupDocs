<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  manualReport.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
	ini_set('display_errors', 1);
	error_reporting(E_ALL);

	mysqlSetup($db);

	if(!$_POST["testCase"] || !$_POST["releaseCycle"] || !$_POST["smtsSwVersion"] || !$_POST["utSoftwareVersion"])
	{
		echo "Test Case, Release Cycle, SMTS Software Version and UT Software Version fields are mandatory to be filled." . "<br>";
		exit;
	}
	else
	{
		if(!mysql_query(createInsertQueryGroupInfo(), $db))
		{
			echo "Error = " . mysql_error() . "<br>";
			echo "Failed to insert data." . "<br>";
			exit;
		}
		else
		{
			echo "Data inserted successfully." . "<br>";
			$groupid = mysql_insert_id();
			echo "Group ID = " . $groupid . "<br>";
			$resultDirectory = "'/mnt/results/" . $groupid . "/'";

			$update = "UPDATE GroupInfo SET Results=$resultDirectory";
			echo "update = " . $update . "<br>";

			if(!mysql_query($update, $db))
			{
				echo "Error = " . mysql_error() . "<br>";
				echo "Failed to update data." . "<br>";
				exit;
			}
			else
			{
				echo "Updated data successfully." . "<br>";
			}
		}
	}

	$select = "SELECT TestID, GrpID FROM TestInfo WHERE GrpID = " . $groupid;
	echo "select = " . $select . "<br>";
	$results = mysql_query($select, $db);
	echo "Number of TestID in TestInfo = " . mysql_num_rows($results) . "<br>";
	$testid = 0;
	while ($row = mysql_fetch_array($results))
	{
		$testid += 1;
		printf("TestID in TestInfo = %d", $row[0]);
		echo "<br>";
		printf("GrpID in TestInfo = %d", $row[1]);
		echo "<br>";
	}
	$testid += 1;
	echo "testid = " . $testid . "<br>";
	
	if(!mysql_query(createInsertQueryTestInfo($testid, $groupid), $db))
	{
		echo "Error = " . mysql_error() . "<br>";
		echo "Failed to insert data." . "<br>";
		exit;
	}
	else
	{
		echo "Data inserted successfully." . "<br>";
	}

	uploadFile($groupid);
	echo "Report successfully created." . "<br>";
	echo "You can view your created report ";
?>

<a href="/report.php?grpID=<?php echo $groupid ?>">here.</a>

<?php
function recursive_mkdir($folder)
{
   $folder = preg_split("/[\\\\\/]/" , $folder);
   $mkfolder = '';
   for($i = 0; isset($folder[$i]); $i++)
   {
       if(!strlen(trim($folder[$i])))continue;
       $mkfolder .= $folder[$i];
       if(!is_dir($mkfolder))
	   {
           mkdir("$mkfolder", 0777);
       }
       $mkfolder .= DIRECTORY_SEPARATOR;
	   chmod("$mkfolder", 0777);
   }
}
?>

<?php
function unzipFile($file, $destination)
{
	$zip = new ZipArchive;
	if ($zip->open($file) === TRUE)
	{
		$zip->extractTo($destination);
		$zip->close();
		echo 'Unzipped to ' . $destination . ' successfully.' . "<br>";
		
		if(unlink($file))
		{
			echo 'Successfully deleted ' . $file . "<br>";
		}
		else
		{
			echo 'Failed to delete ' . $file . "<br>";
		}
	}
	else
	{
		echo 'Error: Failed to unzip a file ' . $file . '.' . "<br>";
	}
}
?>

<?php
function mysqlSetup(&$db)
{
	$dbHost = "reda01.sb.viasat.com";
	$dbUsername = "leapfrog";
	$dbPassword = "leapfrog";
	$dbName = "reda";

	if($dbPassword == "")
	{
		$db = mysql_connect($dbHost, $dbUsername);
	}
	else
	{
		$db = mysql_connect($dbHost, $dbUsername, $dbPassword);
	}
	mysql_select_db($dbName, $db);
}
?>

<?php
function createInsertQueryGroupInfo()
{
	$insert = "INSERT INTO GroupInfo (TestCase, ReleaseCycle";
	$value =  " VALUES ('" . $_POST["testCase"] . "', '" . $_POST["releaseCycle"];

	if($_POST["dateTime"])
	{
		$insert .= ", Datetime";
		$value .= "', '" . $_POST["dateTime"];
	}

	if($_POST["durationHrs"])
	{
		$insert .= ", DurationHrs";
		$value .= "', '" . $_POST["durationHrs"];
	}

	if($_POST["stationName"])
	{
		$insert .= ", StationName";
		$value .= "', '" . $_POST["stationName"];
	}


	if($_POST["stationType"])
	{
		$insert .= ", StationType";
		$value .= "', '" . $_POST["stationType"];
	}

	if($_POST["smtsType"])
	{
		$insert .= ", SmtsType";
		$value .= "', '" . $_POST["smtsType"];
	}

	if($_POST["utType"])
	{
		$insert .= ", UtType";
		$value .= "', '" . $_POST["utType"];
	}

	if($_POST["groupName"])
	{
		$insert .= ", GroupName";
		$value .= "', '" . $_POST["groupName"];
	}

	if($_POST["samVersion"])
	{
		$insert .= ", SAMVersion";
		$value .= "', '" . $_POST["samVersion"];
	}

	if($_POST["samStation"])
	{
		$insert .= ", SAMStation";
		$value .= "', '" . $_POST["samStation"];
	}

	if($_POST["samRunMode"])
	{
		$insert .= ", SAMRunMode";
		$value .= "', '" . $_POST["samRunMode"];
	}

	if($_POST["samTestCase"])
	{
		$insert .= ", SAMTestCase";
		$value .= "', '" . $_POST["samTestCase"];
	}

	if($_POST["description"])
	{
		$insert .= ", Description";
		$value .= "', '" . $_POST["description"];
	}

	if($_POST["specPassFail"])
	{
		$insert .= ", SpecPassFail";
		$value .= "', '" . $_POST["specPassFail"];
	}

	if($_POST["utStartTotal"])
	{
		$insert .= ", UtStartTotal";
		$value .= "', '" . $_POST["utStartTotal"];
	}

	if($_POST["utEndTotal"])
	{
		$insert .= ", UtEndTotal";
		$value .= "', '" . $_POST["utEndTotal"];
	}

	if($_POST["utOnlineTotal"])
	{
		$insert .= ", UtOnlineTotal";
		$value .= "', '" . $_POST["utOnlineTotal"];
	}

	if($_POST["utOnlinePct"])
	{
		$insert .= ", UtOnlinePct";
		$value .= "', '" . $_POST["utOnlinePct"];
	}

	if($_POST["msmStartTotal"])
	{
		$insert .= ", MSMStartTotal";
		$value .= "', '" . $_POST["msmStartTotal"];
	}

	if($_POST["msmEndTotal"])
	{
		$insert .= ", MSMEndTotal";
		$value .= "', '" . $_POST["msmEndTotal"];
	}

	if($_POST["msmOnlineTotal"])
	{
		$insert .= ", MSMOnlineTotal";
		$value .= "', '" . $_POST["msmOnlineTotal"];
	}

	if($_POST["msmOnlinePct"])
	{
		$insert .= ", MSMOnlinePct";
		$value .= "', '" . $_POST["msmOnlinePct"];
	}

	if($_POST["userRating"])
	{
		$insert .= ", userRating";
		$value .= "', '" . $_POST["userRating"];
	}

	if($_POST["notes"])
	{
		$insert .= ", Notes";
		$value .= "', '" . $_POST["notes"];
	}

	if($_POST["user"])
	{
		$insert .= ", User";
		$value .= "', '" . $_POST["user"];
	}

	if($_POST["status"])
	{
		$insert .= ", Status";
		$value .= "', '" . $_POST["status"];
	}

	$insert .= ")";
	$value .= "')";
	$insert .= $value;
	echo "insert = " . $insert . "<br>";
	return $insert;
}
?>

<?php
function createInsertQueryTestInfo($testid, $groupid)
{
	$insert = "INSERT INTO TestInfo (TestID, GrpID, SmtsSwVersion, UtSoftwareVersion";
	$value =  " VALUES ('" . $testid . "', '" . $groupid  . "', '" .  $_POST["smtsSwVersion"]  . "', '" .  $_POST["utSoftwareVersion"];

	if($_POST["status"])
	{
		$insert .= ", Status";
		$value .= "', '" . $_POST["status"];
	}

	if($_POST["dateTime"])
	{
		$insert .= ", Datetime";
		$value .= "', '" . $_POST["dateTime"];
	}

	if($_POST["durationHrs"])
	{
		$insert .= ", DurationHrs";
		$value .= "', '" . $_POST["durationHrs"];
	}

	if($_POST["scriptName"])
	{
		$insert .= ", ScriptName";
		$value .= "', '" . $_POST["scriptName"];
	}

	if($_POST["scriptVersion"])
	{
		$insert .= ", ScriptVersion";
		$value .= "', '" . $_POST["scriptVersion"];
	}

	if($_POST["samParamFile"])
	{
		$insert .= ", SAMParamFile";
		$value .= "', '" . $_POST["samParamFile"];
	}

	if($_POST["resultValue"])
	{
		$insert .= ", ResultValue";
		$value .= "', '" . $_POST["resultValue"];
	}

	if($_POST["specPassFail"])
	{
		$insert .= ", SpecPassFail";
		$value .= "', '" . $_POST["specPassFail"];
	}

	if($_POST["utStartTotal"])
	{
		$insert .= ", UtStartTotal";
		$value .= "', '" . $_POST["utStartTotal"];
	}

	if($_POST["utEndTotal"])
	{
		$insert .= ", UtEndTotal";
		$value .= "', '" . $_POST["utEndTotal"];
	}

	if($_POST["utOnlineTotal"])
	{
		$insert .= ", UtOnlineTotal";
		$value .= "', '" . $_POST["utOnlineTotal"];
	}

	if($_POST["utOnlinePct"])
	{
		$insert .= ", UtOnlinePct";
		$value .= "', '" . $_POST["utOnlinePct"];
	}

	if($_POST["msmStartTotal"])
	{
		$insert .= ", MSMStartTotal";
		$value .= "', '" . $_POST["msmStartTotal"];
	}

	if($_POST["msmEndTotal"])
	{
		$insert .= ", MSMEndTotal";
		$value .= "', '" . $_POST["msmEndTotal"];
	}

	if($_POST["msmOnlineTotal"])
	{
		$insert .= ", MSMOnlineTotal";
		$value .= "', '" . $_POST["msmOnlineTotal"];
	}

	if($_POST["msmOnlinePct"])
	{
		$insert .= ", MSMOnlinePct";
		$value .= "', '" . $_POST["msmOnlinePct"];
	}

	$insert .= ")";
	$value .= "')";
	$insert .= $value;
	echo "insert = " . $insert . "<br>";
	return $insert;
}
?>

<?php
function uploadFile($groupid)
{
	if($_FILES["zippedFile"]['size'] > 0)
	{
		$allowedExts = array('rar', 'zip');
		$temp = explode('.', $_FILES['zippedFile']['name']);
		$extension = end($temp);

		if (($_FILES['zippedFile']['size'] < 2000000) && in_array($extension, $allowedExts))
		{
			if ($_FILES['zippedFile']['error'] !== UPLOAD_ERR_OK)
			{
				echo "Return Code: " . $_FILES['zippedFile']['error'] . "<br>";
				exit;
			}
			else
			{
				echo "Upload: " . $_FILES['zippedFile']['name'] . "<br>";
				echo "Type: " . $_FILES['zippedFile']['type'] . "<br>";
				echo "Size: " . $_FILES['zippedFile']['size'] . "<br>";
				echo "Temp file: " . $_FILES['zippedFile']['tmp_name'] . "<br>";

				if (file_exists("/opt/share/data/results/" . $groupid))
				{
					echo $groupid . " already exists. " . "<br>";
					exit;
				}
				else
				{
					$destination = "/opt/share/data/results/" . $groupid . "/";
					mkdir("$destination", 0777);
					chmod($destination, 0777);
					$filepath = $destination . $_FILES['zippedFile']['name'];

					if(!move_uploaded_file($_FILES['zippedFile']['tmp_name'], $filepath))
					{
						echo "Not able to upload a file." . "<br>";
						print_r($_FILES);
						exit;
					}
					else
					{
						chmod($filepath, 0777);
						echo "Stored in: /opt/share/data/results/" . $groupid . "/" . "<br>";
						unzipFile($filepath, $destination);
						print_r($_FILES);
						echo "<br>";
					}
				}
			}
		}
		else
		{
			echo "Invalid file." . "<br>";
			print_r($_FILES);
			exit;
		}
	}
	else
	{
		echo "No file was chosen to be uploaded." . "<br>";
		$destination = "/opt/share/data/results/" . $groupid . "/";
		mkdir("$destination", 0777);
		chmod($destination, 0777);
		echo "Created an empty directory: /opt/share/data/results/" . $groupid . "/" . "<br>";
	}
}
?>
