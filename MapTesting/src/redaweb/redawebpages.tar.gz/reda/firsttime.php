<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  firsttime.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<!-- Refer to comments in index.php for help -->
<html>
<head>
<title>Help Page</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
include 'func.php';
bodyStyle();
banner();
navbar1("help");
navbar2("help", "firsttime", "");
?>
<br>
<fieldset class="fieldset">
 <legend><font face="arial"><b>Welcome to Reda!</b></font></legend>
<font face="arial">
There are a few small steps that you need to take to ensure that Reda will work properly.<br>
<br>
First, you must map the results folder where all the files are stored. To do that simply:<br>
1. Press the START button on the lower left hand side of your screen. Then press Run... and type in "cmd".<br>
2. Now, type in <font color="228b22">net use q: "\\172.18.46.124\results" leapfrog /user:leapfrog</font>.<br>
<br>
If you are using <b>Internet Explorer</b>, simply click the "I'm Done!" button below.<br>
<br>
If you are using <b>Firefox</b>, you will need to download the <a href="https://addons.mozilla.org/firefox/1429/">IE View Lite</a> extension. You must then open all Results links using this extension.<br>
<br>
<center><a href="index.php?tutscreen=no">I'm Done!</a></center>
</fieldset>
</font>

