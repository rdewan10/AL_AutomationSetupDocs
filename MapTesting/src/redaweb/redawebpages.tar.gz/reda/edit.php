<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  edit.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: edit.php
 * Purpose: This page is used to edit some fields of a test result. The fields 
 *          that can be edited should be specified in the func.php file.
 *
 *****************************************************************************/
include 'func.php';

//This function constructs a search query to get the values of the fields the
//user may potentialy change.
function createQuery($fields, $tables, $idFieldName, $id){
  $query = "SELECT ";

  foreach($fields as $field=>$value){
    if($value!="MULTINUM")
      $query .= $field . ",";
  }
  $query = substr($query,0,-1) . " FROM ";
  
  foreach($tables as $table){
    $query.= $table . ",";
  }
  $query = substr($query,0,-1) . " WHERE ";

  foreach($tables as $table){
    $query.= $table . "." . $idFieldName . "=" . $id . " AND ";
  }
  $query = substr($query,0,-5);

  return $query;
}

mysqlSetup($db);
?>
<!-- Refer to the comments in index.php for help with basic html and help with the title/nav bars. -->
<html>
<head>
<title>Editing Entry</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
//Header, navigation bar, etc.
bodyStyle();
banner();
navbar1("admin");
navbar2("admin", "");
navbar3("edit");
?>
<br><br>
<?php
if($_GET != NULL){
  //Pull in the GET values. (which is just ID or GrpID)
  while(list($key, $value) = each($_GET)){
    $input[$key] = $value;
  }
  ?>
  <form method="post" action="update.php">
  <?php
  if(isset($input["ID"])){//If a TestID is given...
    $id = $input["ID"];
  } 
  $grpID = $input["grpID"];
  ?>
  &nbsp;
  <div class="post">
  <h1><b>Group Information for GrpID <?php echo $grpID; ?></b></h1>
  <p>
  <?php
  //Set two hidden values so update.php can figure out what Test or Grp ID we 
  //are talking about.
  if(isset($id)){
    echo "<input type=\"hidden\" name=\"TestID\" value=\"" . $id . "\">";
  }
  echo "<input type=\"hidden\" name=\"GrpID\" value=\"" . $grpID . "\">";

  $query = createQuery($editableGroupFields, $editableGroupTables, $grpIDField, $grpID);
  $result = mysql_query($query,$db);
  $row =  mysql_fetch_row($result);
  echo "<table>";
  //Display each editable field on it's own separate line.
  for ($i = 0; $i < mysql_num_fields($result);$i++){
    $fullFieldName = mysql_field_table($result, $i) . "." . mysql_field_name($result, $i);
    //The field warrants a drop down box...
    if($editableGroupFields[$fullFieldName]=="DROPDOWN"){
      $distinctQuery= "SELECT DISTINCT " . mysql_field_name($result, $i) . " FROM " . mysql_field_table($result, $i) . " ORDER BY " . mysql_field_name($result, $i) . " ASC";
      $options = mysql_query($distinctQuery,$db);
      printf("<tr><td>%s</td><td>",mysql_field_name($result, $i),$row[$i]);
      printf("<select name=\"grp_%s\" size=1 STYLE=\"width: 346px\">",$fullFieldName);
      while ($option = mysql_fetch_row($options)){
        printf("<option value=\"%s\"",$option[0]);
        if($option[0] == $row[$i]){
          echo " SELECTED";
        }
        printf(">%s</option>",$option[0]);
      }
      echo "</select>";
    } elseif($editableGroupFields[$fullFieldName]== "TEXTAREA"){
      printf("<tr><td>%s </td><td><TEXTAREA name=\"grp_%s\" COLS=\"40\" ROWS=\"4\">%s</textarea></td></tr>", mysql_field_name($result, $i), $fullFieldName, $row[$i]);
    } elseif($editableGroupFields[$fullFieldName]== "TEXT"){
      printf("<tr><td>%s </td><td><input type=\"Text\" name=\"grp_%s\" value=\"%s\" STYLE=\"width: 346px\"></td></tr>", mysql_field_name($result, $i), $fullFieldName, $row[$i]);
    }
  }

  //Now for the fun stuff. We are dealing with N:1 types of fields.
  //There may be more than one entry per Group ID. The example in
  //Surfbeam is STR.
  foreach($editableGroupFields as $table=>$value){
    if($value=="MULTINUM"){
      $query = "SELECT * FROM " . $table . " WHERE " . $grpIDField . "=" . $grpID;
      $result = mysql_query($query,$db);
      $i=0;
      echo "<tr><td></td>";
      for($cols=0;$cols<mysql_num_fields($result);$cols++){
        if(mysql_field_name($result,$cols)!=$grpIDField){
          echo "<td><b>" . mysql_field_name($result,$cols) . "</b></td>";
        }
      }
      echo "</tr>";

      while ($tuple = mysql_fetch_row($result)){
        echo "<tr><td>" . $table . " </td><td>";
        for($cols=0;$cols<mysql_num_fields($result);$cols++){
          if(mysql_field_name($result,$cols)!=$grpIDField){
            echo "<input type=\"Text\" name=\"grp_" . $table . "." .  mysql_field_name($result,$cols) . $i . "\" value=\"" . $tuple[$cols] . "\" size=6>&nbsp;";
          }
        }
        echo "</tr>";
        $i++;
      }
      for($j=0;$j<3;$j++){
        echo "<tr><td>" . $table . " </td>";
        for($cols=0;$cols<mysql_num_fields($result);$cols++){
          if(mysql_field_name($result,$cols)!=$grpIDField){
            echo "<td><input type=\"Text\" name=\"grp_" . $table . "." .  mysql_field_name($result,$cols) . $i . "\" size=6>&nbsp;</td>";
          }
        }
        echo "</tr>";
        $i++;
      }
      echo "<input type=\"hidden\" name=\"num_" . $table  . "\" value=$i>";
    }
  }
  ?>
  </table>
  </p>
  </div>
  <?php 
  if(isset($id)){ ?>
    <div class="post">
    <h1><b>Test Information for TestID <?php echo $id; ?></b></h1>
    <p>
    <?php
    $query = "SELECT ";

    foreach($editableTestFields as $field=>$value){
      if($value!="MULTINUM")
        $query .= $field . ",";
    }
    $query = substr($query,0,-1) . " FROM ";

    foreach($editableTestTables as $table){
      $query.= $table . ",";
    }
    $query = substr($query,0,-1) . " WHERE ";

    foreach($editableTestTables as $table){
      $query.= $table . "." . $testIDField . "=" . $id . " AND ";
    }
    $query .=" $grpIDField=" . $grpID;

    $result = mysql_query($query,$db);
    $row = mysql_fetch_row($result);
    echo "<input type=\"hidden\" name=\"ID\" value=" . $id . ">";
    echo "<table>";
    for ($i = 0; $i < mysql_num_fields($result);$i++){
      $fullFieldName = mysql_field_table($result, $i) . "." . mysql_field_name($result, $i);
      if($editableTestFields[$fullFieldName]=="DROPDOWN"){
        $distinctQuery= "SELECT DISTINCT " . mysql_field_name($result, $i) . " FROM " . mysql_field_table($result, $i) . " ORDER BY " . mysql_field_name($result, $i) . " ASC";
        $options = mysql_query($distinctQuery,$db);
        printf("<tr><td>%s</td><td>",mysql_field_name($result, $i),$row[$i]);
        printf("<select name=\"test_%s\" size=1 STYLE=\"width: 346px\">",$fullFieldName);
        while ($option = mysql_fetch_row($options)){
          printf("<option value=\"%s\"",$option[0]);
          if($option[0] == $row[$i]){
            echo " SELECTED";
          }
          printf(">%s</option>",$option[0]);
        }
        echo "</select>";
      } elseif($editableTestFields[$fullFieldName]== "TEXTAREA"){
        printf("<tr><td>%s </td><td><TEXTAREA name=\"test_%s\" COLS=\"40\" ROWS=\"4\">%s</textarea></td></tr>", mysql_field_name($result, $i), $fullFieldName, $row[$i]);
      } elseif($editableTestFields[$fullFieldName]== "TEXT"){
        printf("<tr><td>%s </td><td><input type=\"Text\" name=\"test_%s\" value=\"%s\" STYLE=\"width: 346px\"></td></tr>", mysql_field_name($result, $i), $fullFieldName, $row[$i]);
      }
    }
    echo "</table>";

    //Now for the fun stuff. We are dealing with N:1 types of fields. 
    //There may be more than one entry per Test ID. The example in 
    //Surfbeam is STR.
    echo "<table>";
    foreach($editableTestFields as $table=>$value){
      if($value=="MULTINUM"){
        $query = "SELECT * FROM " . $table . " WHERE " .$testIDField . "=" . $id;
        $result = mysql_query($query,$db);
        $i=0;
        echo "<tr><td></td>";
        //Print out the column headers
        for($cols=0;$cols<mysql_num_fields($result);$cols++){
          if(mysql_field_name($result,$cols)!=$testIDField){
            echo "<td><center>" . mysql_field_name($result,$cols) . "</center></td>";
          }
        }
        echo "</tr>";

        //Print out the fields
        while ($tuple = mysql_fetch_row($result)){
          echo "<tr><td>" . $table . " </td><td>";
          for($cols=0;$cols<mysql_num_fields($result);$cols++){
            if(mysql_field_name($result,$cols)!=$testIDField){
              echo "<input type=\"Text\" name=\"test_" . $table . "." .  mysql_field_name($result,$cols) . $i . "\" value=\"" . $tuple[$cols] . "\" size=6>&nbsp;";
            }
          }
          echo "</tr>";
          $i++;
        }

        for($j=0;$j<3;$j++){
          echo "<tr><td>" . $table . " </td><td>";
          for($cols=0;$cols<mysql_num_fields($result);$cols++){
            if(mysql_field_name($result,$cols)!=$testIDField){
              echo "<input type=\"Text\" name=\"test_" . $table . "." .  mysql_field_name($result,$cols) . $i . "\" size=6>&nbsp;";
            }
          }
          echo "</tr>";
          $i++;
        }

        echo "<input type=\"hidden\" name=\"num_" . $table  . "\" value=$i>";
      }
    }
    echo "</table>";
    ?>
    </p>
    </div>
<?php } ?>
<P><input type="Submit" name="submit" value="Save Changes"></p>
  <?php
} else {
  ?>
  <form method="get" action="edit.php">
  Enter in the GrpID of the entry you wish to edit: 
  <input type="Text" name="grpID">
  <input type="Submit" name="submit" value="Edit">
  <?php
}
?>

</body>
</html>
