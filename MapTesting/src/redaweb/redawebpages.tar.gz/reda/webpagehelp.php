<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  webpagehelp.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: webpagehelp.php
 * Purpose: Simple page. Displays the webpage help in Reda.
 *
 *****************************************************************************/
?>

<!-- Refer to the comments in index.php for help with basic html, php and help with the title/nav bars. -->
<html>
<head>
<title>Admin Page</title>
  <STYLE>
    <!--
     A{text-decoration:none}
    -->
  </STYLE>
</head>
<?php
include 'func.php';
bodyStyle();
banner();
navbar1("help");
navbar2("admin", "");
navbar3("webpagehelp");
?>
<br>
There are several excellent online resources to help you better utilize this website:<br>
</font>
<br>
<fieldset class="fieldset">
  <legend><font face="arial"><b>PHP</b></font></legend>
  <font face="arial">
  Documentation for PHP can be found <a href="http://www.php.net/manual/en/">here</a>.<br>
  A very in depth tutorial can be found <a href="http://www.w3schools.com/php/default.asp">here</a>.<br>
  <br>
  This entire website was written in PHP.<br>
</fieldset>
</font>
<br>
<br>
<fieldset class="fieldset">
  <legend><font face="arial"><b>mySQL</b></font></legend>
  <font face="arial">
  Documentation for mySQL can be found <a href="http://dev.mysql.com/doc/refman/5.1/en/index.html">here</a>.<br>
  A very in depth tutorial can be found <a href="http://www.w3schools.com/sql/default.asp">here</a>.<br>
  <br>
  All the test results information stored on this webserver is stored using mySQL. To access Webmin's interface with mySQL, click <a href="http://<?php echo $_SERVER['SERVER_NAME'] ?>:10000/mysql/edit_dbase.cgi?db=mydb">here</a>.<br>
</fieldset>
</font>
<br>
<br>
<fieldset class="fieldset">
  <legend><font face="arial"><b>phpMyAdmin</b></font></legend>
  <font face="arial">
  Documentation for phpMyAdmin can be found <a href="http://www.phpmyadmin.net/documentation/">here</a>.<br>
  A very in depth tutorial can be found by asking <a href="mailto:Mike.Foxworthy@viasat.com?subject=OMG HELP THE SERVER DOESN'T WORK!!!!!!!&body=THIS IS URGENT! WHY DOES THIS THING NOT WORK!?! YOU HAVE TO COME TO MY OFFICE ASAP!!!! ALSO I THINK MY CAPS LOCK KEY IS BROKEN. YOU WILL HAVE TO HELP ME FIX THAT TOO.">Mike Foxworthy</a>. In fact, Mike is knowledgable with all aspects of this webpage. Furthermore, he really likes it when you spam his inbox. It makes him feel needed.<br>
  <br>
  PhpMyAdmin provides an nice user interface to interact with mySQL. To access phpMyAdmin, click <a href="http://<?php echo $_SERVER['SERVER_NAME'] ?>/phpmyadmin">here</a>.<br>
</fieldset>
</body>
</html>

