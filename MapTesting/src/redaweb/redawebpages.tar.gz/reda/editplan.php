<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  editplan.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
    

    echo "<html><head>\n";
    echo "  <title>Current Software Release Test Plan</title> \n";
    echo "  <link rel=\"stylesheet\" type=\"text/css\" href=\"reda.css\">\n";
    echo "  <STYLE TYPE=\"text/css\">\n";
    echo "    TD{font-family: Arial; font-size: 12pt;}\n";
    echo "	  TH{font-family: Arial; font-size: 13pt;}\n";
    echo "  </STYLE>\n";
    echo "</head>\n";
    include 'func.php';
    mysqlSetup($db);
    if(isset($_GET["redirect"])) {
        $query="UPDATE ReleaseCycle SET SXRS=\"".$_GET["strs"]."\", Contact=\"".$_GET["contact"]."\", 
            Comments=\"".$_GET["comments"]."\", TestStation=\"".$_GET["station"]."\", Duration=\"".$_GET["duration"]."\", 
            Status=\"".$_GET["status"]."\", Priority=\"".$_GET["priority"]."\", Description=\"".$_GET["description"]."\"
            WHERE CONVERT(TestCase USING utf8 )= \"".$_GET["testname"]."\" AND SoftwareRelease=\"".$_GET["smtsvers"]."\" LIMIT 1";
        echo "Redirect in 1 second...";
        $result = mysql_query($query,$db);
        if(strcmp($_GET["smtsvers"],"")==0) {
            $smtsvers=none;
        } else {
            $smtsvers=$_GET["smtsvers"];

        }

        echo "<meta HTTP-EQUIV=\"REFRESH\" content=\"1; url=testplan.php?viewSMTS=$smtsvers\">";
        echo "</html>";
        exit(0);
    }

    bodyStyle();
    # user has selected to create a new software release
    if(isset($_GET["newtype"])) {
        $newtype="SoftwareRelease";

        $query="INSERT INTO Releases (OfficialRelease, Version, Build, BuildEnd) VALUES (\"".$_GET["release"]."\", 
                \"".$_GET["version"]."\", \"".$_GET["build"]."\", 999)";
        $result = mysql_query($query,$db);
        # the user wants to copy the testplan from a previous release
        if(isset($_GET["copy"])) {
          $query = "SELECT TestCategory, TestCase, SXRS, Priority, Contact, Comments, TestStation, Duration, Status, Description
                FROM ReleaseCycle 
                WHERE SoftwareRelease = \"".$_GET["copy"]."\"";
          $result = mysql_query($query,$db);
          $addedNum = 0;
          while($row = mysql_fetch_row($result)){
            $query="INSERT INTO ReleaseCycle (TestCategory, TestCase, SoftwareRelease, STRS, Priority, Contact, Comments, TestStation, 
                Duration, Status, Description) VALUES (\"".$row[0]."\", \"".$_GET["version"]."\", \"".$_GET["newtype"]."\", \"".$row[1]."\", \"".
                $row[2]."\", \"".$row[3]."\", \"".$row[4]."\", \"".$row[5]."\", \"".$row[6]."\", \"".$row[7]."\"\"".$row[8]."\")";
            $result2 = mysql_query($query,$db);
            $addedNum = $addedNum + 1;
          } 
          echo "Successfully added ".$addedNum." tests to ".$_GET["newtype"]." release ".$_GET["release"].".<br>";
        }
    }
    # if the user has just arrived at this page
    if(!isset($_GET["smtsvers"]) && !isset($_GET["action"])) {
        echo "<h2><center><font color=\"006699\">Test Plan Edit Page</font></center></h2>";
        echo "<h1>Select the release you would like to edit or create:</h1><br>";
        echo "<form action=\"editplan.php\" method=\"get\">";
        echo "Software Release: &nbsp;";
        echo "<select name=\"smtsvers\">\n";
        $query = "SELECT OfficialRelease, Version, Build, BuildEnd FROM Releases ORDER BY Version DESC";
        echo $query."<br>";
        $result = mysql_query($query,$db);
        while($row = mysql_fetch_row($result)){
            echo "<option value=\"".$row[0]."\">".$row[0]."</option>";
        }
        echo "</select><br>\n";

        echo "<input type=\"submit\" value=\"&nbsp; Go! &nbsp; \">";
        echo "</form><br><br><br>";
        
        echo "<form action =\"editplan.php\" method=\"get\">";
        echo "Create a new version with the following information:<br>";
        echo "Release:<font color=\"white\">l</font>&nbsp;<input type=\"text\" name=\"release\"><br>";
        echo "Version:<font color=\"white\">l</font>&nbsp;&nbsp;<input type=\"text\" name=\"version\"><br>";
        echo "Build:<font color=\"white\">.</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"text\" name=\"build\"><br>";
        echo "(optional)&nbsp;Auto-fill from release:&nbsp;&nbsp;<input type=\"text\" name=\"copy\" size=9>&nbsp;e.g. '0.1.0.0'<br>";
        echo "<input type=\"submit\" value=\"Submit\">";
        echo "</form>";
        exit(0);
    }
    elseif(strcmp($_GET["action"],"edit")==0) {
        
        $query = "SELECT Priority, Contact, Comments, TestStation, Duration, SXRs, Status, TestCategory, Description FROM ReleaseCycle WHERE ";
        $query .= "TestCase='".$_GET["test"]."'";
        echo "<div id='full'>";  
        echo "<div class='post'>";
        echo "<h1>Editing entry for <strong>".$_GET["category"]." </strong> test <strong>".$_GET["test"]."</strong> in release ";

        echo $_GET["smts"].".";
        $query .= " AND SoftwareRelease=\"".$_GET["smts"]."\"";

        $result = mysql_query($query,$db);
        $row = mysql_fetch_row($result);
        echo "</h1><form method=\"get\" action=\"/editplan.php\" font face=\"Arial\">";
        if(isset($_GET["from"])) {echo "<input type=\"hidden\" name=\"redirect\" value=\"true\">";}
        echo "<input type=\"hidden\" name=\"update\" value=\"true\">";
        echo "<input type=\"hidden\" name=\"testname\" value=\"".$_GET["test"]."\">";
        echo "<input type=\"hidden\" name=\"smtsvers\" value=\"".$_GET["smts"]."\">";
        echo "<table>";
        echo "<tr><td>Category: </td><td><input type=\"text\" name=\"category\" value=\"".$row[7]."\"</input></td></tr>";
        echo "<tr><td>Description: </td><td><input type=\"text\" name=\"description\" value=\"".$row[8]."\"</input></td></tr>";
        echo "<tr><td>SXRs: </td><td><input type=\"text\" name=\"strs\" value=\"".$row[5]."\"</input></td></tr>";
        echo "<tr><td>Priority: </td><td><input type=\"text\" name=\"priority\" value=\"".$row[0]."\"</input></td></tr>";
        echo "<tr><td>Contact: </td><td><input type=\"text\" name=\"contact\" value=\"".$row[1]."\"</input></td></tr>";
        echo "<tr><td>Comments: </td><td><textarea rows=\"5\" cols=\"30\" name=\"comments\">".$row[2]."</textarea></td></tr>";
        echo "<tr><td>Test Station: </td><td><input type=\"textbox\" name=\"station\" value=\"".$row[3]."\"</input></td></tr>";
        echo "<tr><td>Duration (days): </td><td><input type=\"textbox\" name=\"duration\" value=\"".$row[4]."\"</input></td></tr>";
        echo "<tr><td>Status: </td><td><textarea rows=\"5\" cols=\"30\" name=\"status\">".$row[6]."</textarea></td></tr>";
        echo "<tr><td/><td align=\"right\"><input type=\"submit\"/></td></tr></table>";
        echo "</form></div></div>";
        exit(0);
    }
    elseif(strcmp($_GET["action"],"new")==0) {
        $query = "SELECT OfficialRelease FROM Releases WHERE Version=\"".$_GET["smts"]."\" LIMIT 1";
        $result = mysql_query($query,$db);
        $row = mysql_fetch_row($result);
        $smtsrelease=$row[0];

        echo "<div id='full'>\n";  
        echo "<div class='post'>\n";
        echo "<h1>Creating new test for release ";

        echo $_GET["smts"].".";

        echo "</h1>\n";
        echo "<form method=\"get\" action=\"/editplan.php\">\n";
        echo "<input type=\"hidden\" name=\"makenew\" value=\"true\"/>\n";
        echo "<input type=\"hidden\" name=\"smtsvers\" value=\"".$_GET["smts"]."\">\n";
        echo "<table>\n";

        echo "<tr><td>Test Case: </td><td><input type=\"text\" name=\"testname\" value=\"\"/></td></tr>\n";
        echo "<tr><td>Category: </td><td><input type=\"text\" name=\"category\" value=\"\"/></td></tr>\n";
        echo "<tr><td>Description: </td><td><input type=\"text\" name=\"description\" value=\"\"/></td></tr>\n";
        echo "<tr><td>STRs: </td><td><input type=\"text\" name=\"strs\" value=\"\"</input></td></tr>\n";
        echo "<tr><td>Priority: </td><td><input type=\"text\" name=\"priority\" value=\"\"</input></td></tr>\n";
        echo "<tr><td>Contact: </td><td><input type=\"text\" name=\"contact\" value=\"\"</input></td></tr>\n";
        echo "<tr><td>Test Station: </td><td><input type=\"text\" name=\"station\" value=\"\"</input></td></tr>\n";
        echo "<tr><td>Comments: </td><td><textarea rows=\"5\" cols=\"30\" name=\"comments\"></textarea></td></tr>\n";
        echo "<tr><td>Duration (days): </td><td><input type=\"text\" name=\"duration\" value=\"\"</input></td></tr>\n";
        echo "<tr><td>Status: </td><td><textarea rows=\"5\" cols=\"30\" name=\"status\"></textarea></td></tr>\n";
        echo "<tr><td/><td align=\"right\"><input type=\"submit\"/></td></tr></table>\n";
        echo "</form></div></div>\n";
        exit(0);
    }
    elseif(strcmp($_GET["action"],"delete")==0) {
        echo "<div id='full'>";  
        echo "<div class='get'>";
        echo "<h1>Are you sure you want to delete the ".$_GET["test"]." test from the ";

        echo $_GET["smts"];

        echo " release?";
        echo "</h1><form method=\"get\" action=\"/editplan.php\">";
        echo "<input type=\"hidden\" name=\"delconf\" value=\"true\">";
        echo "<input type=\"hidden\" name=\"smtsvers\" value=\"".$_GET["smts"]."\">";
        echo "<input type=\"hidden\" name=\"testname\" value=\"".$_GET["test"]."\">";
        echo "<tr><td/><td align=\"right\"><input type=\"submit\"/></td></tr></table>";
        echo "</form></div></div>";
        exit(0);
    }
    //implicit else- the user wants to edit a specific release version

    echo "<h2><center><font color=\"006699\">Editing Software Release: ".$_GET["smtsvers"]."</font></center></h2>";
      
    if(strcmp($_GET["update"],"true")==0) {        
        $query="UPDATE ReleaseCycle SET TestCategory=\"".$_GET["category"]."\", SXRS=\"".$_GET["strs"]."\", Contact=\"".$_GET["contact"]."\", 
                Comments=\"".$_GET["comments"]."\", TestStation=\"".$_GET["station"]."\", Duration=\"".$_GET["duration"]."\", 
                Status=\"".$_GET["status"]."\", Priority=\"".$_GET["priority"]."\", Description=\"".$_GET["description"]."\"
            WHERE CONVERT(TestCase USING utf8 )= \"".$_GET["testname"]."\" AND SoftwareRelease=\"".$_GET["smtsvers"]."\" LIMIT 1";

        $result = mysql_query($query,$db);
    }
    if(strcmp($_GET["makenew"],"true")==0) {
        $query="INSERT INTO ReleaseCycle (TestCase, TestCategory, SoftwareRelease, SXRS, Priority, Contact, Comments, TestStation, 
                Duration, Status, Description) 
            VALUES (\"".$_GET["testname"]."\", \"".$_GET["category"]."\", \"".$_GET["smtsvers"]."\", \"".$_GET["strs"]."\",
                \"".$_GET["priority"]."\", \"".$_GET["contact"]."\", \"".$_GET["comments"]."\", \"".$_GET["station"]."\", 
                \"".$_GET["duration"]."\", \"".$_GET["status"]."\", \"".$_GET["description"]."\")";

        $result = mysql_query($query,$db);
    }
    if(strcmp($_GET["delconf"],"true")==0) {
        $query="DELETE FROM ReleaseCycle WHERE TestName=\"".$_GET["testname"]."\" AND SoftwareRelease=\"".$_GET["smtsvers"]."\"  LIMIT 1";

        $result = mysql_query($query,$db);
    }

    echo "<br>";

    $testListArray = array();
    $query = "SELECT DISTINCT TestCase FROM ReleaseCycle WHERE SoftwareRelease='".$_GET["smtsvers"]."' 
            ORDER BY TestCategory, Priority, TestCase";

    $result = mysql_query($query,$db);
    while($testName = mysql_fetch_row($result)) {
        $testListArray[] = $testName[0];	
    }

    echo "<div id='full'>";  
    echo "<div class='get'>";
    echo "<table width='98%' BORDER=1 RULES=ROWS FRAME=HSIDES font face=\"Arial\">";
    echo "<tr><th></th><th></th><th align='left'>Test Name</th><th align='left'>Description</th><th>Category</th><th width=65>Priority</th><th align='left' width=120>Contact</th>";
    //echo "<th align='left' width=25%>Comments</th><th align='left' width=25%>Status</th></tr>";
    echo "<th align='left' width=25%>Comments</th></tr>";
    foreach($testListArray as $test){
        $query = "SELECT TestCategory, Contact, Comments, Priority, Status, Description FROM ReleaseCycle WHERE TestCase='".$test."' AND (";
        
        $query .= "SoftwareRelease='".$_GET["smtsvers"]."')";
        
        $result = mysql_query($query,$db);
        $cycledata=mysql_fetch_row($result);
        echo "<tr><td><a href=\"/editplan.php?action=edit&test=$test&smts=".$_GET["smtsvers"]."\"><img alt=\"Edit\" src=\"images/b_edit.png\" border=\"0\"/></a>
            </td><td><a href=\"/editplan.php?action=delete&test=$test&smts=".$_GET["smtsvers"]."\"><img alt=\"Delete\" src=\"images/b_drop.png\" border=\"0\"/></a></td><td>$test</td><td align='center'>$cycledata[0]</td>";
        echo "<td align='center'>$cycledata[3]</td>";
        //echo "<td>$cycledata[1]</td><td>$cycledata[5]</td><td>".substr($cycledata[2],0,50)."</td><td>".substr($cycledata[4],0,50)."</td></tr>";	
        echo "<td>$cycledata[1]</td><td>$cycledata[5]</td><td>".substr($cycledata[2],0,50)."</td></tr>";	
    }
    echo "</table><br>";
    echo "<form method =\"get\" action=\"editplan.php\">";
    echo "<input type=\"hidden\" name=\"action\" value=\"new\">";
    echo "<input type=\"hidden\" name=\"smts\" value=\"".$_GET["smtsvers"]."\">";
    echo "<input type=\"submit\" value=\"Create New Test\"></form>";
    echo "<form action=\"testplan.php\">";

    echo "<input type=\"hidden\" name=\"viewSMTS\" value=\"".$_GET["smtsvers"]."\">";

    echo "<input type=\"submit\" value=\"Go Home\"></form>";
    echo "</div></div>";
    echo "</body></html>";
?>
