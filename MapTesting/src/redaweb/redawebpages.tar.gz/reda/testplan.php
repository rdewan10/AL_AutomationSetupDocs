<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  testplan.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>

<?php
include 'func.php';
mysqlSetup($db);

if(!isset($_GET["toCsv"])){
  echo "<html>\n";
  echo "<head>\n";
  echo "  <title>Current Software Release Test Plan</title>\n"; 
  echo "  <link rel=\"stylesheet\" type=\"text/css\" href=\"reda.css\">\n";
  echo "  <STYLE TYPE=\"text/css\">\n";
  echo "    TD{font-family: Arial; font-size: 12pt;}\n";
  echo "	TH{font-family: Arial; font-size: 13pt;}\n";
  echo "  </STYLE>\n";
  echo "</head>\n";
  bodyStyle();
  
} else {
  header('Content-type: application/ms-excel');
  header("Content-Disposition: attachment; filename=query.csv");
}

  // The user is new to the page or has selected the current release
if(!isset($_GET["viewSMTS"]) || $_GET["viewSMTS"]==""){
    //We need to get the current official release.
    $query = "SELECT OfficialRelease, Version, Build, BuildEnd FROM Releases ORDER BY Version DESC";
    $result = mysql_query($query,$db);
    
    $row = mysql_fetch_row($result);
    $smtsrelease = $row[0];
    $smtsvers = $row[1];
    $smtsbuild = $row[2];
    $smtsbuildend = $row[3];
} else {
    // Get the release the user chose
    $query = "SELECT OfficialRelease, Version, Build, BuildEnd FROM Releases WHERE OfficialRelease = \"".$_GET["viewSMTS"]."\"";
    $result = mysql_query($query,$db);
    $row = mysql_fetch_row($result);
    $smtsrelease = $row[0];
    $smtsvers = $row[1];
    $smtsbuild = $row[2];
    $smtsbuildend = $row[3];
}	
  // The user is new to the page or has selected the current release
if(!isset($_GET["toCsv"])){
    echo "<form action=\"testplan.php\" method=\"get\">\n";    
    //echo "<center><h2><font size=6 color=\"773300\">Release ".$smtsrelease." Test Plan Status</font></h2>\n";
  } else {
        echo "Release $smtsrelease Test Plan Status\n";
  }
  banner_testplan($smtsrelease);

if(!isset($_GET["toCsv"])){
  
    navbar1("release");
    echo "<div id=\"full\">";
    echo "<div class=\"post\">\n";
    echo " <font color=\"ECF4EC\"> <center>\n";
  
    echo "<a href=\"editplan.php?smtsvers=$smtsrelease\"><b>Edit this test plan</b></a>\n";
    divider();
    echo "<a href=\"/testplan.php?toCsv=true&viewSMTS=".$_GET["viewSMTS"]."\"><b>Save as CSV</b></a>\n";
    divider();
    echo "View different release:&nbsp;\n";
  
    echo "<select name=\"viewSMTS\">\n";
    $query = "SELECT OfficialRelease, Version, Build, BuildEnd FROM Releases ORDER BY Version DESC";
    $result = mysql_query($query,$db);
    while($row = mysql_fetch_row($result)){
        echo "<option value=\"".$row[0]."\"";
        if (strcmp($row[0],$smtsrelease)==0) { echo " SELECTED "; }
        echo ">".$row[0]."</option>\n";
    }
    echo "</select>&nbsp;";  
    
    echo "&nbsp;<input type=\"submit\" value=\"Go!\">\n";
    divider();
    echo "Filter Category:&nbsp;\n";
    echo "<select name=\"filterCat\">\n";
    echo "<option value=\"\">View All</option>\n";
    $query = "SELECT DISTINCT TestCategory FROM ReleaseCycle";
    $result = mysql_query($query,$db);
    while($row = mysql_fetch_row($result)){
        echo "<option value=\"".$row[0]."\"";
        if (strcmp($row[0],$_GET["filterCat"])==0) { echo " SELECTED "; }
        echo ">".$row[0]."</option>\n";
    }
    echo "</select>&nbsp;"; 
    echo "&nbsp;<input type=\"submit\" value=\"Go!\">\n";    
    echo "</font>\n";
    echo "</center>\n";
    echo "</div>";
    echo "</div>";
    
}

/////////////
//
// NEED TO SWITCH BACK TO THE COMMENTED QUERY WHEN THE SAM INTEGRATION OF SMTS SW VERSION IS IN PLACE
//
/////////////

//$showTests = "SELECT TestInfo.GrpID, TestInfo.TestID, TestInfo.TestCase, TestInfo.ExpPassFail, 
//                TestInfo.Datetime, TestInfo.SmtsSwVersion, GroupInfo.GroupName, GroupInfo.TestCase,
//                GroupInfo.ExpPassFail FROM TestInfo, GroupInfo 
//              WHERE (TestInfo.SmtsSwVersion REGEXP '".$smtsvers." build*' ) 
//              AND (SUBSTR( SmtsSwVersion, 15, 3 ) BETWEEN ".$smtsbuild." AND ".$smtsbuildend.") 
//              AND GroupInfo.ReleaseCycle = 'yes'
//              AND GroupInfo.Status != 'invalid'
//              AND TestInfo.Status != 'invalid'
//              ORDER BY TestInfo.GrpID";
$showTests = "SELECT TestInfo.GrpID, TestInfo.TestID, TestInfo.TestCase, TestInfo.ExpPassFail, 
                TestInfo.Datetime, TestInfo.SmtsSwVersion, GroupInfo.GroupName, GroupInfo.TestCase,
                GroupInfo.ExpPassFail FROM TestInfo, GroupInfo 
              WHERE GroupInfo.ReleaseCycle = 'yes'
              AND GroupInfo.Status != 'invalid'
              AND TestInfo.Status != 'invalid'
              AND TestInfo.GrpID=GroupInfo.GrpID
              ORDER BY TestInfo.GrpID";
       
//get all completed tests for this release
$result = mysql_query($showTests,$db);
$testid_index=1;
$grpid_index=0;

$resultsArray = array();
$testsCompleted = array();
$numPassed=0;
$numFailed=0;

while($tuple = mysql_fetch_row($result)){
    $resultsArray[] = $tuple;
    $testsCompleted[] = trim($tuple[8]);
}

$testListArray = array();
if(strcmp($_GET["ord"],"d")==0) {
    $qual = " DESC";
} else {
    $qual = " ASC";
}
if(strcmp($_GET["sort"],"priority")==0) {
    $orderBy = "Priority $qual, TestCase";
} elseif (strcmp($_GET["sort"],"testcase")==0) {
    $orderBy = "TestCase".$qual;
} elseif (strcmp($_GET["sort"],"category")==0) {
    $orderBy = "TestCategory $qual, Priority, TestCase".$qual;
} elseif (strcmp($_GET["sort"],"contact")==0) {
    $orderBy = "Contact $qual, TestCase";
} elseif (strcmp($_GET["sort"],"status")==0) {
    $orderBy = "Status $qual, TestCase";
} elseif (strcmp($_GET["sort"],"strs")==0) {
    $orderBy = "STRS $qual, TestCase";
} else {
    $orderBy = "TestCategory, Priority, TestCase";
}

$query = "SELECT DISTINCT TestCase FROM ReleaseCycle WHERE SoftwareRelease='".$smtsrelease."'";
if(isset($_GET["filterCat"]) && strcmp($_GET["filterCat"],"")!=0) {
    $query .= "AND TestCategory='".$_GET["filterCat"]."'";
}
$query .= " ORDER BY $orderBy";

$result = mysql_query($query,$db);
while($testName = mysql_fetch_row($result)) {
    $testListArray[] = $testName[0];
}

if(!isset($_GET["toCsv"])){
    echo "<div id='full'>\n";
}
$result = mysql_query($showTests,$db);

$testsCompleted = array();
while($tuple = mysql_fetch_row($result)){
    for($i=0;$i<mysql_num_fields($result);$i++){
        if(mysql_field_name($result,$i)=="TestCase"){
            $testsCompleted[] = $tuple[$i];
        }
    }
}
if(!isset($_GET["toCsv"])){
    echo "<div class='tableheader'>\n";
    echo "<table WIDTH=\"98%\" BORDER=\"1\" RULES=\"ROWS\" FRAME=\"BELOW\" CELLSPACING=\"0\">\n";
    if(strcmp($_GET["ord"],"a")==0) {
        $newOrd = "d";
    } else {
        $newOrd = "a";
    }
    if(strcmp($_GET["sort"],"priority")==0) {
        echo "<tr><th width=10></th><th align='left' width=10%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=category&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Category</a></th>\n";
        echo "<th width=15%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=testcase&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Test Case</a></th>\n";
        echo "<th width=65 align='center'><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=priority&filterCat=".urlencode($_GET["filterCat"])."&ord=$newOrd\">Priority</a></th>\n";
        echo "<th align='center'>Reda</th>\n";        
        echo "<th align='left' width=175>Comments</th>\n";
        echo "<th align='left' width=18%>Status</th>\n"; 
        echo "<th align='center'>STRs</th></tr>\n";        
    } elseif(strcmp($_GET["sort"],"category")==0) {
        echo "<tr><th width=10></th><th align='left' width=10%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=category&filterCat=".urlencode($_GET["filterCat"])."&ord=$newOrd\">Category</a></th>\n";
        echo "<th width=15%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=testcase&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Test Case</a></th>\n";
        echo "<th width=65 align='center'><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=priority&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Priority</a></th>\n";
        echo "<th align='center'>Reda</th>\n";        
        echo "<th align='left' width=175>Comments</th>\n";
        echo "<th align='left' width=18%>Status</th>\n";  
        echo "<th align='center'>STRs</th></tr>\n";
    } elseif(strcmp($_GET["sort"],"testcase")==0) {
        echo "<tr><th width=10></th><th align='left' width=10%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=category&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Category</a></th>\n";
        echo "<th width=15%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=testcase&filterCat=".urlencode($_GET["filterCat"])."&ord=$newOrd\">Test Case</a></th>\n";
        echo "<th width=65 align='center'><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=priority&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Priority</a></th>\n";
        echo "<th align='center'>Reda</th>\n";        
        echo "<th align='left' width=175>Comments</th>\n";
        echo "<th align='left' width=18%>Status</th>\n"; 
        echo "<th align='center'>STRs</th></tr>\n";
    } else {
        echo "<tr><th width=3></th><th align='left' width=10%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=category&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Category</a></th>\n";
        echo "<th width=15%><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=testcase&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Test Case</a></th>\n";
        echo "<th width=65 align='center'><a href=\"testplan.php?viewSMTS=".$_GET["viewSMTS"]."&sort=priority&ord=a&filterCat=".urlencode($_GET["filterCat"])."\">Priority</a></th>\n";
        echo "<th align='center'>Reda</th>\n";        
        echo "<th align='left' width=175>Comments</th>\n";
        echo "<th align='left' width=18%>Status</th>\n";  
        echo "<th align='center'>STRs</th></tr>\n";
    }
    echo "</div>\n";
} else { //if we are writing to csv
    echo "Test Name,Priority,Reda,STRs,Comment,Status\n";  
}
$rowNum=0;
foreach($testListArray as $test){

    $rowNum++;
    if ($rowNum%2==0) {
        $bgcolor="F0F0F3";
    } else {
        $bgcolor="FFFFF";
    }
    $query = "SELECT Priority, Comments, Status, SXRS, TestStation, Duration, TestCategory, Description FROM ReleaseCycle 
                WHERE TestCase='".$test."' AND SoftwareRelease='".$smtsrelease."'";
    if(isset($_GET["filterCat"]) && strcmp($_GET["filterCat"],"")!=0) {
        $query .= "AND TestCategory='".$_GET["filterCat"]."'";
}   
    $result2 = mysql_query($query,$db);
	$cycledata=mysql_fetch_row($result2);
	$stat=0;
	$flag=0;
	$iter=0;
	$redaid=array();
    $readlabel=array();
    $pfarray=array();
    $sxrarray=array();
    $sxrarray=explode(",",$cycledata[3]);
    foreach ($resultsArray as $result) {

        if(strcmp($result[7],$test)==0) {
            $sxrquery = "SELECT SXR FROM RelatedSXRs WHERE GrpID=\"".$result[0]."\"";
            $sxrresult = mysql_query($sxrquery,$db);            
            while ($sxrval=mysql_fetch_row($sxrresult)) {
                if (!in_array($sxrval[0],$sxrarray)) {
                    $sxrarray[]=$sxrval[0];
                }
            }
            
            $redaStr=$result[0];
            if(strcmp($result[8],"pass")==0){
        		$stat=1;
        		if(!in_array($result[0],$redaid)){
        		  //$redaid[$iter]=$result[0].' ('.$result[10].','.$result[11].') ';
        		  $redaid[$iter]=$result[0];
        		  $redalabel[$iter]=$redaStr;
                  $pfarray[$iter]="#00CC00";
        		  $iter=$iter+1;		
        		}
        	} elseif(strcmp($result[8],"FAIL")==0) {
        	    $stat=2;
        		if(!in_array($result[0],$redaid)){
        		  //$redaid[$iter]=$result[0].' ('.$result[10].','.$result[11].') ';
        		  $redaid[$iter]=$result[0];
        		  $redalabel[$iter]=$redaStr;
                  $pfarray[$iter]="red";
        		  $iter=$iter+1;
        		}
            } elseif(strcmp($result[8],"provisional pass")==0) {
                if($stat==1) {
                    $stat=0;
                }
        		if(!in_array($result[0],$redaid)){
        		  $redaid[$iter]=$result[0];
        		  $redalabel[$iter]=$redaStr;
        		  //$redaid[$iter]=$result[0].' ('.$result[10].','.$result[11].') ';
                  $pfarray[$iter]="#408080";
        		  $iter=$iter+1;
        		}
            } else {
                if(!in_array($result[0],$redaid)){
        		  $redaid[$iter]=$result[0];
        		  $redalabel[$iter]=$redaStr;
        		  //$redaid[$iter]=$result[0].' ('.$result[10].','.$result[11].') ';
                  $pfarray[$iter]="blue";
        		  $iter=$iter+1;
        		}
            }
        }      
	}
	$iter=0;
    // if it's a priority 3 or above
	if($cycledata[0]>=3){
	    if($stat==0) {
    	    if(!isset($_GET["toCsv"])){
              echo "<tr bgcolor=\"$bgcolor\"><td><a href=\"editplan.php?action=edit&test=$test&smts=$smtsrelease&from=1\">
                        <img src=\"/images/bluegray.bmp\" border=\"0\"/></a></td><td>".$cycledata[6]."</td><td>".$cycledata[7]."</td>
                        <td align='center'>$cycledata[0]</td><td align='center'>\n";
    		} else {
    		  echo ereg_replace(",", "", $test).",$cycledata[0],";
    		}
	    } elseif($stat==1) {
    	    if(!isset($_GET["toCsv"])){
              echo "<tr bgcolor=\"$bgcolor\"><td><a href=\"editplan.php?action=edit&test=$test&smts=$smtsrelease&from=1\">
                        <img src=\"/images/greengray.bmp\" border=\"0\"/></a></td><td>".$cycledata[6]."</td><td>".$cycledata[7]."</td>
                        <td align='center'>".$cycledata[0]."</td><td align='center'>\n";
    		} else {
    		  echo ereg_replace(",", "", $test).",$cycledata[0],";
    		}
	    } elseif($stat==2) {
    	    if(!isset($_GET["toCsv"])){
              echo "<tr bgcolor=\"$bgcolor\"><td><a href=\"editplan.php?action=edit&test=$test&smts=$smtsrelease&category=XXX&from=1\">
                        <img src=\"/images/redgray.bmp\" border=\"0\"/></a></td><td>".$cycledata[6]."</td><td>".$cycledata[7]."</td>
                        <td align='center'>$cycledata[0]</td><td align='center'>\n";
    		} else {
    		  echo ereg_replace(",", "", $test).",$cycledata[0],";
    		}
	    }
    // if it's a high priority test
	} else {
        if($stat==0) {
            if(!isset($_GET["toCsv"])){
                echo "<tr bgcolor=\"$bgcolor\"><td><a href=\"editplan.php?action=edit&test=$test&smts=$smtsrelease&from=1\">
                            <img src=\"/images/blue.bmp\" border=\"0\"/></a></td><td>".$cycledata[6]."</td><td>".$cycledata[7]."</td>
                            <td align='center'>$cycledata[0]</td><td align='center'>\n";
            } else {
                echo ereg_replace(",", "", $test).",$cycledata[0],";
            }
        } elseif($stat==1) {
            if(!isset($_GET["toCsv"])){
                echo "<tr bgcolor=\"$bgcolor\"><td><a href=\"editplan.php?action=edit&test=$test&smts=$smtsrelease&from=1\">
                            <img src=\"/images/green.bmp\" border=\"0\"/></a></td><td>".$cycledata[6]."</td><td>".$cycledata[7]."</td>
                            <td align='center'>$cycledata[0]</td><td align='center'>\n";
            } else {
                echo ereg_replace(",", "", $test).",$cycledata[0],";
            }
        } elseif($stat==2) {
            if(!isset($_GET["toCsv"])){
                echo "<tr bgcolor=\"$bgcolor\"><td><a href=\"editplan.php?action=edit&test=$test&smts=$smtsrelease&from=1\">
                            <img src=\"/images/red.bmp\" border=\"0\"/></a></td><td>".$cycledata[6]."</td><td>".$cycledata[7]."</td>
                            <td align='center'>$cycledata[0]</td><td align='center'>\n";
            } else {
                echo ereg_replace(",", "", $test).",$cycledata[0],";
            }
        }
	}
    $pfcount=0;
	foreach ($redaid as $id) {
		if(!isset($_GET["toCsv"])){
			echo "<a href=\"report.php?grpID=$id\" target=\"_blank\"><font color=\"$pfarray[$pfcount]\">$redalabel[$pfcount]</font></a>&nbsp;\n";
            $pfcount++;
	    } else {
		    echo "$id ";
		}
    }
	if(!isset($_GET["toCsv"])){
		echo "</td>\n";
	} else {
		echo ",";
	}
    
	if(!isset($_GET["toCsv"])){
		echo "<td>&nbsp;$cycledata[1]</td><td>$cycledata[2]</td>\n";
	} else {
		echo ",$cycledata[1],$cycledata[2]\n";
	}
    echo "<td align='center'>";
    foreach ($sxrarray as $str2) {
		if(!isset($_GET["toCsv"])){
			echo "<a href=\"http://vcateam01/scripts/texcel/devtrack/buglist2.dll?IssueList?97&2011&-1&-1&3&-100&0&2011&1&0&1&".
                        $str2."&0&1&1&0& &0#\" target=\"_blank\">".$str2."</a>&nbsp;\n";
		} else {
			echo "$str2 ";
		}
	}
    echo "</td></tr>";
  }
  if(!isset($_GET["toCsv"])) {
    echo "</table>\n";
    echo "</div></form>\n";
    echo "</body>\n";
    echo "</html>\n";
  }
?>
