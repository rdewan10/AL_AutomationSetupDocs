<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  csv.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: csv.php
 * Purpose: Basically, this page prints out the data that would normally be 
 *          displayed on the results table. This allows for someone to
 *          download this page and then save it as a .csv file. The entries 
 *          are comma "," delimited.
 *
 *****************************************************************************/
include 'func.php';
header('Content-type: application/ms-excel');
header("Content-Disposition: attachment; filename=query.csv");
mysqlSetup($db);

//Pull in the variables that the user supplied us...
while(list($key, $value) = each($_GET)){
  $input[$key] = $value;
}

$query = str_replace("\\","",$input["query"]); //The query is saved with escape characters that we need to get rid of.

$result = mysql_query($query,$db);
//Start filling out the CSV table...
for ($i = 0; $i < mysql_num_fields($result);$i++){
  if($i != 0){
    echo ",";
  }
  echo mysql_field_name($result, $i);
}
echo "\n";

while ($myrow = mysql_fetch_row($result)) {
  for ($i = 0; $i < mysql_num_fields($result);$i++){
    if($i !=0){
      echo ",";
    }
    echo $myrow[$i];
  }
  echo "\n";
}
?>

