<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  store.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: store.php
 * Purpose: After a user enters in information to save a query in save.php,
 *          this page will insert the query into the database.
 *
 *****************************************************************************/

include 'func.php'; 
mysqlSetup($db);
while(list($key, $value) = each($_POST)){
  $input[$key] = $value;
}
if($input["submit"]=="Overwrite"){
  $description=str_replace("\\","",$input["desc"]);
  $update="UPDATE queries SET query = \"" . $input["query"] . "\" WHERE description=\"" . $description . "\"";
  mysql_query($update,$db);
  $done=1;
}
?>
<!-- Refer to the comments in index.php for help with basic html, php and help with the title/nav bars. -->
<html>
<head>
<title>Save Query</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
bodyStyle();
banner();
navbar1("results");
navbar2("results", "store", $query);
?>
<br>
<center>
<?php

$insert = "INSERT INTO $savedQueryTableName($savedQueryFieldName,$savedQueryDescriptionFieldName) VALUES (\"" . str_replace("\\","",$input["query"]) . "\",\"" . $input["desc"] . "\")";
if($done==1 || mysql_query($insert,$db)) {
 echo "Your query was stored sucessfully!<br>";
} else {
  echo "Your entry was NOT stored successfully.<br>Press the back button to revise your description.<br>";
}
?>
</center>
</body>
</html>
