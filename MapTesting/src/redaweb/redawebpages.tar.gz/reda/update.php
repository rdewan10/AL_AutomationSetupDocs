<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  update.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: update.php
 * Purpose: After the user makes changes in edit.php, the changes are sent to
 *          this page, which inserts the changes into the database.
 *
 *****************************************************************************/

include 'func.php';
mysqlSetup($db);

//This function puts together a mysql update statement given some values.
function createUpdateQuery($updateValuePairs, $editableTables, $idFieldName, $id){
  $query = "UPDATE ";

  foreach($editableTables as $table){
    $query.= $table . ",";
  }
  $query = substr($query,0,-1) . " SET ";

  foreach($updateValuePairs as $field=>$value){
    $query.=$field . "='" . $value . "',";
  }
  $query = substr($query,0,-1) . " WHERE ";

  foreach($editableTables as $table){
    $query.= $table . "." . $idFieldName . "=" . $id . " AND ";
  }
  $query = substr($query,0,-5);
  return $query;
}

if($_POST != NULL){//There are some input to process...
  while(list($key, $value) = each($_POST)){
    $input[$key] = $value;
  }
  //These two flags will let us know if we were successful.
  $update_test=0;
  $update_group=0;

  //Update the group entries
  $updateValuePairs= array();

  //Process the changes to the group table(s).
  foreach($editableGroupFields as $field=>$value){
    if(isset($input["grp_" . str_replace(".","_",$field)])){
      $updateValuePairs[$field]=str_replace("'","\"",$input["grp_" . str_replace(".","_",$field)]);
    }
  }

  $update = createUpdateQuery($updateValuePairs, $editableGroupTables, $grpIDField, $input["GrpID"]);
  //echo "update = " . $update . "<br>";
  if(mysql_query($update,$db)){
      $update_group=1;
  }

  //Update the test entries
  $updateValuePairs= array();

  foreach($editableTestFields as $field=>$value){
    if(isset($input["test_" . str_replace(".","_",$field)])){
      $updateValuePairs[$field]=$input["test_" . str_replace(".","_",$field)];
    }
  }

  if(isset($input["TestID"])){
    $update = "UPDATE ";

    foreach($editableTestTables as $table){
      $update.= $table . ",";
    }
    $update = substr($update,0,-1) . " SET ";

    foreach($updateValuePairs as $field=>$value){
      $update.=$field . "='" . $value . "',";
    }
    $update = substr($update,0,-1) . " WHERE ";

    foreach($editableTestTables as $table){
      $update.= $table . "." . $testIDField . "=" . $input["TestID"] . " AND " . $table . "." . $grpIDField . "=" . $input["GrpID"] . " AND ";
    }
    $update = substr($update,0,-5);

    //echo $update . "<br>";

    if(mysql_query($update,$db)){
        $update_test=1;
    }

  } else {
    $update_test=1;
  }

  //The fun part...Multinum tables. We will be doing this twice. The first
  //time will be for test tebles.
  $multiNumInsert=1;
  foreach($editableTestFields as $table=>$value){
    if($value=="MULTINUM" && isset($input["num_" . $table])){
      //Delete all values from the database.
      $delete = "DELETE FROM " . $table . " WHERE " . $testIDField . "='" . $input["TestID"] . "'";
      //mysql_query($delete,$db);
      //echo "delete = " . $delete ."<br>";

      //What are the fields?
      $result = mysql_query("SELECT * FROM " . $table . " LIMIT 1",$db);

      $insert = "INSERT INTO " . $table . "(" . $testIDField . ",";
      for($col=0;$col<mysql_num_fields($result);$col++){
        if(mysql_field_name($result,$col)!=$testIDField){
          $insert .= mysql_field_name($result,$col) . ",";
        }
      }
      $insert = substr($insert,0,-1) . ") VALUES";

      //Add new values
      for($i=0;$i<$input["num_" . $table];$i++){
        $addData=0;
        for($col=0;$col<mysql_num_fields($result);$col++){
          if(mysql_field_name($result,$col)!=$testIDField && 
             $input["test_" . $table . "_" .  mysql_field_name($result,$col) . $i]!=""){
            $addData=1;
            break;
          }
        }
        if($addData){
          $insert.="('" . $input["TestID"] . "',";
          for($col=0;$col<mysql_num_fields($result);$col++){
            if(mysql_field_name($result,$col)!=$testIDField){
              $insert.= "'" . $input["test_" . $table . "_" .  mysql_field_name($result,$col) . $i] . "',";
            }
          }
          $insert = substr($insert,0,-1) . "),";
        }
      }
      $insert = substr($insert,0,-1);
      if(!mysql_query($insert,$db)){
        $multiNuminsert=0;
      }
      //echo $insert . "<br>";
    }
  }

  //And we go at it again with group tables...
  foreach($editableGroupFields as $table=>$value){
    if($value=="MULTINUM" && isset($input["num_" . $table])){
      //Delete all values from the database.
      $delete = "DELETE FROM " . $table . " WHERE " . $grpIDField . "='" . $input["GrpID"] . "'";
      mysql_query($delete,$db);
      //echo "delete = " . $delete . "<br>";

      //What are the fields?
      $result = mysql_query("SELECT * FROM " . $table . " LIMIT 1",$db);

      $insert = "INSERT INTO " . $table . "(" . $grpIDField . ",";
      for($col=0;$col<mysql_num_fields($result);$col++){
        if(mysql_field_name($result,$col)!=$grpIDField){
          $insert .= mysql_field_name($result,$col) . ",";
        }
      }
      $insert = substr($insert,0,-1) . ") VALUES";

      //Add new values
      for($i=0;$i<$input["num_" . $table];$i++){
        $addData=0;
        for($col=0;$col<mysql_num_fields($result);$col++){
          if(mysql_field_name($result,$col)!=$grpIDField &&
             $input["grp_" . $table . "_" .  mysql_field_name($result,$col) . $i]!=""){
            $addData=1;
            break;
          }
        }
        if($addData){
          $insert.="('" . $input["GrpID"] . "',";
          for($col=0;$col<mysql_num_fields($result);$col++){
            if(mysql_field_name($result,$col)!=$grpIDField){
              $insert.= "'" . $input["grp_" . $table . "_" .  mysql_field_name($result,$col) . $i] . "',";
            }
          }
          $insert = substr($insert,0,-1) . "),";
        }
      }
      $insert = substr($insert,0,-1);
      if(!mysql_query($insert,$db)){
        $multiNuminsert=0;
      }
      //echo "insert = " . $insert . "<br>";
    }
  }

?>
<!-- Refer to the comments in index.php for help with basic html, php and help with the title/nav bars. -->
<html>
<head>
<title>Update Entry</title>
<?php
  if($multiNumInsert==1 && $update_test==1 && $update_group==1){
    echo "<meta http-equiv='REFRESH' content='3;url=report.php?grpID=" . $input["GrpID"] . "'>";
  }
?>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
bodyStyle();
banner();
navbar1("admin");
navbar2("admin", "");
navbar3("edit");
?>
<br><br>
<font size=4><center>
<?php
  if($multiNumInsert==1 && $update_test==1 && $update_group==1){
    echo "Successfully edited this test/group! Redirecting to report page in a few seconds...<br>";
  } else {
    if($multiNumInsert!=1)
      echo "ERROR: Could not update the MULTINUM values! Table may be corrupted...<br>";
    if($update_test!=1)
       echo "ERROR: Could not update the test table values!<br>";
    if($update_group!=1)
       echo "ERROR: Could not update the group table values!<br>";
  }
} else {
  echo "ERROR: No input specified! (How did you even get to this page?)<br>";
}
?>
</center></font>
</html>
