<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  faq.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?
/******************************************************************************
 *
 & Filename: faq.php
 * Purpose: This page displays the frequently asked questions. Pretty simple.
 *
 *****************************************************************************/
?>


<!-- Refer to comments in index.php for help -->
<html>
<head>
<title>FAQ Page</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
include 'func.php';
bodyStyle();
banner();
navbar1("faq");
?>
<br>
<a NAME="top"></a><b>Frequently Asked Questions:</b><br>
<a href="faq.php#setup">How do I set up Reda?</a><br>
<a href="faq.php#browsers">What browsers will it work with?</a><br>
<a href="faq.php#findentry">I have a <?php echo $testIDField; ?> or <?php echo $grpIDField; ?> how do I find the entry?</a><br>
<a href="faq.php#testvgroup">What is the difference between a Test and a Group anyway?<br>
<a href="faq.php#islike">What does the "is Like" comparison do, and how do I use it?</a><br>
<a href="faq.php#query">What is a query or view?</a><br>
<a href="faq.php#export">How do I export results?</a><br>
<a href="faq.php#upload">How do I upload files?</a><br>
<a href="faq.php#bad">I put a bad test in Reda, what do I do?</a><br>
<a href="faq.php#bug">I found a bug in the interface, what do I do?</a><br>
<br>
<br>
<table><tr><td width="100%"><a NAME="setup"></a><b>How do I set up ReDa?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
Hardly any setup is needed at all.  The first time you open ReDa you will get a welcome message describing the very, very short setup required to access files on the network and export results to Excel.<br>
You can find it <a href="firsttime.php">here</a> as well.<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="browsers"></a><b>What browsers will it work with?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
ReDa has been tested with Internet Explorer and Firefox. See the <a href="firsttime.php">Set Up Tutorial</a> for setup concerns.<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="findentry"></a><b>I have a <?php echo $testIDField; ?> or <?php echo $grpIDField; ?> how do I find the entry?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
1. Go to the <a href="index.php">ReDa Homepage</a>.<br>
2. Under ID search, select <?php echo $testIDField; ?> or <?php echo $grpIDField; ?> from the drop down box.<br>
4. Leave the search criterion as "is Equal to".<br>
5. Enter the <?php echo $testIDField; ?> or <?php echo $grpIDField; ?> in the search box on the right<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="testvgroup"></a><b>What is the difference between a Test and a Group anyway?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
In a nutshell, think of a group as a set of TestCases that are run in a single session.<br>
<br>
The concept of a group is closely tied to the automation software.  SAM supports a test list, in which multiple different TestCases or multiple instances of the same test TestCase may be specified to run in a single session.  To help associate the TestCases that are run in this fashion, reda has the concept of a group.<br>
<br>
For example, a Software Readiness test may cover, Registration, Upgrade/Downgrade, Throughput and Stability test cases.  Of course, each TestCase may also be run individually.<br>
<br>
The group concept also helps with results collection.  Some diagnostics, such as log files and SNMP polling run for the entire automation session.  These make more sense associated with a group rather than an individual test case.<br>
<br>
For instances when there is only one TestCase run, there will be a 1 TestID per GroupID.  If there are five TestCases in a test list, there will be 5 TestIDs for 1 GroupID.<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="islike"></a><b>What does the "is Like" comparison do, and how do I use it?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
The "is Like" comparison will allow you to use wildcards in your search strings. The wildcard symbol is "%" (without the quotations).<br><br>
For example, say you want to see all tests run in the month of September 2006.<br>
First, you would select "Date" as the search field.<br>
Then, you would select "is Like" as the comparison.<br>
Finally, you would type in "2006-09-%".<br><br>
The "%" symbol is the wildcard symbol. The above search would return every entry where the date started with 2006-09-, namely, all the tests run in september.<br>
<br>
<br>

<table><tr><td width="100%"><a NAME="query"></a><b>What is a query or view?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
ReDa is a SQL database, to access the information a query is used.  A query has two purposes.  The first and most obvious is to return entries in the database of interest, such as all the tests on Defiant.  The second is display only the fields of interest, think of it like a view.  For example, if you were only interested in seeing when the last time a version was run on Defiant, you could show only "TestStation" "Date" and "SmtsVersion".<br>
Queries or Views can be saved locally or on the server.  The most popular searches are easily accessed from the Main Page.<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="export"></a><b>How do I export results?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
Simply click the "Export as CSV" link at the top of your results page.<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="upload"></a><b>How do I upload files?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
Click on the open link for an entry.  Copy files into the folder.<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="bad"></a><b>I put a bad test in ReDa, what do I do?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
No worries, just mark the Status field as invalid.  Set your queries to ignore tests that are invalid, or be conscious of this column.<br>
Entries can only be deleted by Administrators and generally should not be deleted.<br>
<br>
<br>
<table><tr><td width="100%"><a NAME="bug"></a><b>I found a bug in the interface, what do I do?</b></td><td><a href="faq.php#top">top&nbsp;&nbsp;</a></td></tr></table>
Contact <a href="mailto:Thomas.Tran@viasat.com">Tom Tran</a>, <a href="mailto:Kim.Horanyi@viasat.com">Kim Horanyi</a> or <a href="mailto:Kevin.Rennie@viasat.com">Kevin Rennie</a>.<br>
<br>
<br>
