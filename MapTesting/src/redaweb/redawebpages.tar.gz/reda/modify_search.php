<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  modify_search.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: modify_search.php
 * Purpose: The advanced search page. Also allows users to modify their query
 *          if they are unhappy with it.
 *
 *****************************************************************************/

include 'func.php';
mysqlSetup($db);
?>
<!-- Refer to the comments in index.php for help with basic html, php and help with the title/nav bars. -->
<html>
<head>
<title>Search Database</title>
<!-- The following are javascript functions that allow parts of the form to be disabled when certain fields are
     selected -->
<script>
//Makes sure that the user has selected either AND or OR when they have more than one search criteria
function joinValidation(joinValue){
  if(joinValue==""){
    alert("You are attempting to select a new search criterion without specifying a joining operation. Please select AND or OR.");
  }
}
//Makes sure we have JUST enough join operators.
function validate(){
  var validCriteriaCount=0;
  var i;
  for (i=1;i<6;i++) {
    if (document.getElementById("searchjoin" + i).value=="" && document.getElementById("searchfield" + i).value==""){
      validCriteriaCount++;
    } else if (document.getElementById("searchjoin" + i).value!="" && document.getElementById("searchfield" +i).value!=""){
      validCriteriaCount++;
    } else {
      alert("Cannot submit search. You are either missing a joining operation or you have one too many.");
      return false;
    }
  }
  return true;
}

//Allows the user to interact with the Fields list.
function enableFields()
{
//The actual name of the input is "fields[]". javascript does not allow us to address it with the "[]",
//Therefore we have to give it an ID and then address the fields form by the id.
document.getElementById("fields").disabled=false;
}

//Opposite of the above.
function disableFields()
{
document.getElementById("fields").disabled=true;
}

</script>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php 
bodyStyle();
banner();
navbar1("modify");

$aggregate=0;

if($_GET != NULL){
  while(list($key, $value) = each($_GET)){
    $input[$key] = $value;
  }
  $query = $input["query"];
  str_replace("\"","'",$query);
  navbar2("results", "modify_query", $query);
  // Generally, select queries take the form:
  //
  //    SELECT <fields> FROM " . <tables> . " WHERE <conditions> ORDER BY <field> GROUP BY <field>
  //
  // Only SELECT <fields> FROM " . <tables> . " is required to be there.
  // Generally the conditions preceed the order by and group by clauses
  // Much of the next 100+ lines is dedicated to parsing out the query, so that
  // we can later place them back into the form.


  // Finding the index of where all the keywords are...
  $query=str_replace("'","",$query);
  $select_index = 6;
  $from_index = strpos(strtolower($query),"from");
  $where_index = strpos(strtolower($query),"where");
  $order_index = strpos(strtolower($query),"order by");
  $group_index = strpos(strtolower($query),"group by");
  
  //We immediately know the select fields start after SELECT and stop right before
  //the keyword FROM.
  //substr() will take a portion of a string (in this case query, starting from
  //index position 7, and continuing for $from_index-8 chars.
  $select_fields = substr($query, 7, $from_index-8);

  //the conditions stated after the WHERE keyword is slightly more difficult.
  //First off, it may nor may not be in the particular query.
  if($where_index != 0){
    //If it is, we have to know what is immediate after the <conditions>.
    if($order_index != 0 && $group_index != 0){
      //It could be ORDER BY...
      if($order_index < $group_index){
        $cond_length = $order_index - $where_index - 7;
      //Or maybe GROUP BY...
      } else {
        $cond_length = $group_index - $where_index - 7;
      }
    } elseif ($order_index != 0) {
      $cond_length = $order_index - $where_index - 7;
    } elseif ($group_index != 0) {
      $cond_length = $group_index - $where_index - 7;
    //Or maybe there is nothing after the conditions at all
    } else {
      $cond_length = 0;
    }

    if($cond_length !=0){ //If there is something after the <conditions>
      $where_fields = substr($query, $where_index + 6, $cond_length);
    } else { //If there is nothing.
      $where_fields = substr($query, $where_index + 6);
    }
  }

  //Checking for an ORDER BY clause
  if($order_index != 0){
    if ($group_index > $order_index) {
      $order_length = $group_index - $order_index - 10;
      $order_fields = substr($query, $order_index + 9, $order_length);
    } else {
      $order_fields = substr($query, $order_index + 9);
    }
  }
  
  //Checking for a GROUP BY clause
  if($group_index != 0){
    if ($order_index > $group_index) {
      $group_length = $order_index - $group_index - 10;
      $group_fields = substr($query, $group_index + 9, $group_length);
    } else {
      $group_fields = substr($query, $group_index + 9);
    }
  }

//  echo "Select:" . $select_fields . "<br>";
//  echo "Where:" . $where_fields . "<br>";
/*
  echo "Order:" . $order_fields . "<br>";
  echo "Group:" . $group_fields . "<br>";
*/
  //It could use an aggregate function (ie. sum(Failing_Steps)
  if(($pos = strpos(strtolower($select_fields),"max(")) !== FALSE){ 
    $aggregate=1;
    $aggregate_op="max";
    $pos2 = strpos(strtolower($select_fields),")");
    $aggregate_field=substr($select_fields, $pos+4, $pos2 - $pos - 4);
  } elseif (($pos = strpos(strtolower($select_fields),"min(")) !== FALSE) {
    $aggregate=1;
    $aggregate_op="min";
    $pos2 = strpos(strtolower($select_fields),")");
    $aggregate_field=substr($select_fields, $pos+4, $pos2 - $pos - 4);
  } elseif (($pos = strpos(strtolower($select_fields),"avg(")) !== FALSE) {
    $aggregate=1;
    $aggregate_op="avg";
    $pos2 = strpos(strtolower($select_fields),")");
    $aggregate_field=substr($select_fields, $pos+4, $pos2 - $pos - 4);
  } elseif (($pos = strpos(strtolower($select_fields),"count(")) !== FALSE) {
    $aggregate=1;
    $aggregate_op="count";
    $pos2 = strpos(strtolower($select_fields),")");
    $aggregate_field=substr($select_fields, $pos+6, $pos2 - $pos - 6);
  } elseif (($pos = strpos(strtolower($select_fields),"sum(")) !== FALSE) {
    $aggregate=1;
    $aggregate_op="sum";
    $pos2 = strpos(strtolower($select_fields),")");
    $aggregate_field=substr($select_fields, $pos+4, $pos2 - $pos - 4);
  }

  //Now that we have the select field, we have to parse that, so that we can
  //get the individual field names.
  $i=0;
  while($pos = strpos($select_fields,",")) {
    //echo $select_fields . ": " . $pos . "<br>";
    $select[$i] = substr($select_fields, 0, $pos);
    $select_fields = substr($select_fields, $pos+1);
    $i++;
  }
  $select[$i]=$select_fields;
  $num_select_fields = $i+1;
/* 
  for($j=0;$j < $num_select_fields; $j++){
    echo $select[$j] . "<br>";
  }
*/

  //Determine if the WHERE conditions have table joining conditions, denoted by te "((" and "))"
  if($where_fields[0] == "(" && $where_fields[1] == "("){
    $endTableJoinPos = strpos(strtolower($where_fields),"))");
    if($endTableJoinPos < strlen($where_fields)-2){
      $where_fields = substr($where_fields, $endTableJoinPos+7);
    } else {
      $where_fields = "";
      $checked_fields="";
    }
  }
  if($where_fields[0] == "("){
    $end_search_fields=strpos(strtolower($where_fields),")");
    $checked_fields =  substr($where_fields,$end_search_fields+6);
    $where_fields = substr($where_fields,1,$end_search_fields-1);
  }
  //echo "WHERE - JOIN CONDITIONS: $where_fields<br>";

  //Repeat the same for the WHERE conditions
  $i=0;
  while(1) {
//    echo $where_fields . "<br>";
    if($pos = strpos(strtolower($where_fields)," or ")) {
        $where[$i] = substr($where_fields, 0, $pos);
        $wherejoin[$i+1] = "or";
        $pos = $pos+4;
    } elseif ($pos = strpos(strtolower($where_fields)," and ")){
        $where[$i] = substr($where_fields, 0, $pos);
        $wherejoin[$i+1] = "and";
        $pos = $pos+5;
    } else {
        $where[$i] = $where_fields;
        break;
    }
    $where_fields = substr($where_fields, $pos);
    $i++;
  }
  $num_where_fields=$i+1;

  //More parsing...
  for($i=0;$i<$num_where_fields;$i++){
    if ($pos = strpos($where[$i], "!=")) {
      $before_pos=$pos - 1;
      $after_pos=$pos + 2;
      while($where[$i][$before_pos] == " "){
        $before_pos--;
      }
      $before_pos++;
      while($where[$i][$after_pos] == " "){
        $after_pos++;
      }
      $where_field[$i] = substr($where[$i], 0, $before_pos);
      $where_op[$i] = "!=";
      $where_match[$i] = str_replace("\\","", substr($where[$i], $after_pos));
    } elseif ($pos = strpos($where[$i], ">=")) {
      $before_pos=$pos - 1;
      $after_pos=$pos + 2;
      while($where[$i][$before_pos] == " "){
        $before_pos--;
      }
      $before_pos++;
      while($where[$i][$after_pos] == " "){
        $after_pos++;
      }
      $where_field[$i] = substr($where[$i], 0, $before_pos);
      $where_op[$i] = ">=";
      $where_match[$i] = str_replace("\\'","", substr($where[$i], $after_pos));
    } elseif ($pos = strpos($where[$i], "<=")) {
      $before_pos=$pos - 1;
      $after_pos=$pos + 2;
      while($where[$i][$before_pos] == " "){
        $before_pos--;
      }
      $before_pos++;
      while($where[$i][$after_pos] == " "){
        $after_pos++;
      }
      $where_field[$i] = substr($where[$i], 0, $before_pos);
      $where_op[$i] = "<=";
      $where_match[$i] = str_replace("\\'","", substr($where[$i], $after_pos));
    } elseif($pos = strpos($where[$i], "=")) {
      //The two following while loops take care of white spaces
      //Because a statement that uses "ID= 5" is just as legal
      //as "ID=5", "ID =5", "ID   =         5" etc.
      $before_pos=$pos - 1;
      $after_pos=$pos + 1;
      while($where[$i][$before_pos] == " "){
        $before_pos--;
      }
      $before_pos++;
      while($where[$i][$after_pos] == " "){
        $after_pos++;
      }
      $where_field[$i] = substr($where[$i], 0, $before_pos);
      $where_op[$i] = "=";
      $where_match[$i] = str_replace("\\","", substr($where[$i], $after_pos));
    } elseif ($pos = strpos($where[$i], ">")) {
      $before_pos=$pos - 1;
      $after_pos=$pos + 1;
      while($where[$i][$before_pos] == " "){
        $before_pos--;
      }
      $before_pos++;
      while($where[$i][$after_pos] == " "){
        $after_pos++;
      }
      $where_field[$i] = substr($where[$i], 0, $before_pos);
      $where_op[$i] = ">";
      $where_match[$i] = str_replace("\\'","", substr($where[$i], $after_pos));
    } elseif ($pos = strpos($where[$i], "<")) {
      $before_pos=$pos - 1;
      $after_pos=$pos + 1;
      while($where[$i][$before_pos] == " "){
        $before_pos--;
      }
      $before_pos++;
      while($where[$i][$after_pos] == " "){
        $after_pos++;
      }
      $where_field[$i] = substr($where[$i], 0, $before_pos);
      $where_op[$i] = "<";
      $where_match[$i] = str_replace("\\'","", substr($where[$i], $after_pos));
    } elseif ($pos = strpos($where[$i], "LIKE")) {
      $before_pos=$pos - 1;
      $after_pos=$pos + 4;
      while($where[$i][$before_pos] == " "){
        $before_pos--;
      }
      $before_pos++;
      while($where[$i][$after_pos] == " "){
        $after_pos++;
      }
      $where_field[$i] = substr($where[$i], 0, $before_pos);
      $where_op[$i] = "LIKE";
      $where_match[$i] = str_replace("\\'","", substr($where[$i], $after_pos));
    }
    $where_match[$i] =  str_replace("\\","",$where_match[$i]);
  }

  //Working with the ORDER BY clause
  $i=0;
  while($pos = strpos($order_fields," ")) {
    $order_field[$i] = substr($order_fields, 0, $pos);
    if($pos2 = strpos($order_fields,",")) {
      $order_op[$i] = substr($order_fields, $pos+1, $pos2 - $pos - 1);
    } else {
      $order_op[$i] = substr($order_fields, $pos+1);
      break;
    }
    $order_fields = substr($order_fields, $pos2+1);
    $i++;
  }
  $num_order_fields=$i+1;
  if($checked_fields != ""){
    if(strpos($checked_fields,"invalid")){
      $invalid_checked =1;
    }
    if(strpos($checked_fields,"DATE_SUB")){
      $relativetime_checked =1;
      preg_match('/INTERVAL (\d+) (\w+)/',$checked_fields,$matches);
      $where_timevalue = $matches[1];
      $where_timeunit = $matches[2];
    }
  }
}
?>
<br><br>
<?php
?>
<form method="get" name="search" onSubmit="return validate()" action="results.php"> <!--Tutorial on Forms: http://www.htmlgoodies.com/tutorials/forms/-->
<div id="leftcolsearch">
<div class="post">
<h1>Display Fields</h1>
<p>
          <!--Refer to index.php for an explanation of the onClick field.-->
          <input type="radio" name="display" value="fields" id="display" <?php if($aggregate==0){echo "checked";} ?>
            onClick="this.form.aggregateop.disabled=true;
                     this.form.aggregatefield.disabled=true;
                     this.form.groupbyfield.disabled=true;
                     enableFields();">
           Show Fields<br>
        <font size=1>Use Ctrl+Click to select multiple fields.</font><br>
        <select name="fields[]" id="fields" multiple size="17" <?php if($aggregate!=0){echo "disabled";} ?>>
          <?php
            echo "<option value=\"default\"";
            if(!isset($select))
              echo " SELECTED";
            echo ">DEFAULT</option>";
          ?>
          <option value="simplified">Group View</option>
          <option disabled value="">-----------------------------------</option>
          <?php
          echo "<option value='" . $grpLevelTableName . "." . $grpIDField . " as Report'>Report Link</option>";
          $allFieldsSorted = getAllFieldsSortedAsArray();
          foreach($allFieldsSorted as $field){
            $tableNameStart = strpos($field,"(")+1;
            $tableNameLength = strlen($field) - 1 - $tableNameStart;
            $tableName = substr($field,$tableNameStart,$tableNameLength);
            $fieldName = substr($field,0,$tableNameStart-2);
            $mysqlFormattedField =$tableName . "." . $fieldName;
            $isSelected = 0;
            for($j = 0; $j< $num_select_fields; $j++){
              if($select[$j] == $mysqlFormattedField){
                $isSelected =1;
                break;
              }
            }
            if($isSelected){
              printf("<option value=\"%s\" SELECTED>%s</option>\n", $mysqlFormattedField,$field);
            } else {
              printf("<option value=\"%s\">%s</option>\n", $mysqlFormattedField,$field);
            }
          }
          ?>
        </select><br>
          <br><INPUT TYPE="radio" NAME="display" VALUE="aggregate" <?php if($aggregate!=0){echo "checked";} ?>
            onClick="this.form.aggregateop.disabled=false;
                     this.form.aggregatefield.disabled=false;
                     this.form.groupbyfield.disabled=false;
                     disableFields();">
        Use An Aggregate Function<br>
        <select name="aggregateop" <?php if($aggregate==0){echo "disabled";} ?> size="1">
          <option <?php if(isset($aggregate_op) && $aggregate_op == "max"){echo "SELECTED";}?> value="max">Maximum of</option>
          <option <?php if(isset($aggregate_op) && $aggregate_op == "min"){echo "SELECTED";}?> value="min">Minimum of</option>
          <option <?php if(isset($aggregate_op) && $aggregate_op == "avg"){echo "SELECTED";}?> value="avg">Average of</option>
          <option <?php if(isset($aggregate_op) && $aggregate_op == "count"){echo "SELECTED";}?> value="count">Count of</option>
          <option <?php if(isset($aggregate_op) && $aggregate_op == "sum"){echo "SELECTED";}?> value="sum">Sum of</option>
        </select>
        <select name="aggregatefield" <?php if($aggregate==0){echo "disabled";} ?> size="1">
          <option SELECTED value=""></option>
          <?php
          $allFieldsSorted = getAllFieldsSortedAsArray();
          foreach($allFieldsSorted as $field){
            $tableNameStart = strpos($field,"(")+1;
            $tableNameLength = strlen($field) - 1 - $tableNameStart;
            $tableName = substr($field,$tableNameStart,$tableNameLength);
            $fieldName = substr($field,0,$tableNameStart-2);
            $mysqlFormattedField =$tableName . "." . $fieldName;
            if($aggregate_field == $mysqlFormattedField){
              printf("<option value=\"%s\" SELECTED>%s</option>\n", $mysqlFormattedField,$field);
            } else {
              printf("<option value=\"%s\">%s</option>\n", $mysqlFormattedField,$field);
            }
          }
          ?>
        </select>
       <p> Group by:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <select name="groupbyfield" <?php if($aggregate==0){echo "disabled";} ?> size="1">
          <option SELECTED value="">None</option>
          <?php
          $allFieldsSorted = getAllFieldsSortedAsArray();
          foreach($allFieldsSorted as $field){
            $tableNameStart = strpos($field,"(")+1;
            $tableNameLength = strlen($field) - 1 - $tableNameStart;
            $tableName = substr($field,$tableNameStart,$tableNameLength);
            $fieldName = substr($field,0,$tableNameStart-2);
            $mysqlFormattedField =$tableName . "." . $fieldName;
            if($group_fields == $mysqlFormattedField){
               printf("<option value=\"%s\" SELECTED>%s</option>\n", $mysqlFormattedField,$field);
            } else {
              printf("<option value=\"%s\">%s</option>\n", $mysqlFormattedField,$field);
            }
          }
          ?>
        </select>
      </p></div>
    </div>
    <div id="rightcolsearch">
<div class="post">
    <h1>Return Results Where</h1>
    <p>
        <?php
        for($j=0; $j<6; $j++){
          if($j!=0){
          ?>
          &nbsp;&nbsp;&nbsp;<select name="searchjoin<?php echo $j ?>" size="1" id="searchjoin<?php echo $j ?>">
          <?php
            if($wherejoin[$j] == "and") { ?>
              <option value=""></option>
              <option value="AND" SELECTED>AND</option>
              <option value="OR">OR</option>
            <?php } elseif($wherejoin[$j] == "or") { ?>
              <option value=""></option>
              <option value="AND">AND</option>
              <option value="OR" SELECTED>OR</option>
             <?php } else { ?>
              <option value="" SELECTED></option>
              <option value="AND">AND</option>
              <option value="OR">OR</option>
             <?php } ?>
            </select><br><br>
          <?php
          }
          ?>
          <select name="searchfield<?php echo $j ?>" size="1"  <?php echo "onclick=\"joinValidation(searchjoin$j.value);\""; ?> id="searchfield<?php echo $j ?>">
            <option SELECTED value=""></option>
            <?php
            $allFieldsSorted = getAllFieldsSortedAsArray();
            foreach($allFieldsSorted as $field){
              $tableNameStart = strpos($field,"(")+1;
              $tableNameLength = strlen($field) - 1 - $tableNameStart;
              $tableName = substr($field,$tableNameStart,$tableNameLength);
              $fieldName = substr($field,0,$tableNameStart-2);
              $mysqlFormattedField =$tableName . "." . $fieldName;
              if($where_field[$j] == $mysqlFormattedField){
                printf("<option value=\"%s\" SELECTED>%s</option>\n", $mysqlFormattedField,$field);
              } else {
                printf("<option value=\"%s\">%s</option>\n", $mysqlFormattedField,$field);
              }
            }
            ?>
          </select>
          <select name="searchop<?php echo $j ?>" size="1">
            <option <?php if(isset($where_op) && $where_op[$j] == "="){echo "SELECTED";} ?>  value="=">is Equal to</option>
            <option <?php if(isset($where_op) && $where_op[$j] == "!="){echo "SELECTED";} ?> value="!=">is Not Equal to</option>
            <option <?php if(isset($where_op) && $where_op[$j] == ">"){echo "SELECTED";} ?> value=">">is Greater than</option>
            <option <?php if(isset($where_op) && $where_op[$j] == ">="){echo "SELECTED";} ?> value=">=">is Greater than/Equal to</option>
            <option <?php if(isset($where_op) && $where_op[$j] == "<"){echo "SELECTED";} ?> value="<">is Less than</option>
            <option <?php if(isset($where_op) && $where_op[$j] == "<="){echo "SELECTED";} ?> value="<=">is Less than/Equal to</option>
            <option <?php if(isset($where_op) && $where_op[$j] == "LIKE"){echo "SELECTED";} ?> value="LIKE">is Like</option>
          </select>
          <?php 
          echo "<input type=\"Text\" name=\"searchmatch" . $j . "\" value=\"";
          if(isset($where_match[$j]))
            echo $where_match[$j];
          echo "\" size=\"15\">"; 
        }
        ?>
        </p></div>
        <div id="checkboxes">
          <input type="checkbox" name="relativetime" value=1 <?php if(isset($relativetime_checked) && $relativetime_checked==1){ echo "CHECKED"; }?>>&nbsp;Started within the past
          <?php 
            echo "<input type=\"Text\" name=\"timevalue\" value=\"";
            if(isset($where_timevalue) && $where_timevalue!="")
              echo $where_timevalue;
            else
              echo 1;
            echo "\" size=\"5\">"; 
          ?>
          <select name="timeunit" size="1">
            <option <?php if(isset($where_timeunit) && $where_timeunit == "HOUR"){echo "SELECTED";} ?> value="HOUR">hour(s)</option>
            <option <?php if(isset($where_timeunit) && $where_timeunit == "DAY"){echo "SELECTED";} ?> value="DAY">day(s)</option>
            <option <?php if(isset($where_timeunit) && $where_timeunit == "WEEK"){echo "SELECTED";} ?> value="WEEK">week(s)</option>
            <option <?php if(isset($where_timeunit) && $where_timeunit == "MONTH"){echo "SELECTED";} ?> value="MONTH">month(s)</option>
          </select>
          <br>
          <input type="checkbox" name="invalid" value=1 <?php if(isset($invalid_checked) && $invalid_checked==1){ echo "CHECKED"; }?>>&nbsp;Ignore entries marked invalid<br>
        </div>
        <br><br><br>
        <div class="post"><h1>Sort by</h1><p>
        <?php
        for($j=0; $j<3; $j++){
          if($j>0){
          ?>
            <br><br>
          <?php } ?>
          <select name="sortfield<?php echo $j ?>" size="1">
            <option SELECTED value=""></option>
		    <?php
            $allFieldsSorted = getAllFieldsSortedAsArray();
            foreach($allFieldsSorted as $field){
              $tableNameStart = strpos($field,"(")+1;
              $tableNameLength = strlen($field) - 1 - $tableNameStart;
              $tableName = substr($field,$tableNameStart,$tableNameLength);
              $fieldName = substr($field,0,$tableNameStart-2);
              $mysqlFormattedField =$tableName . "." . $fieldName;
              if($order_field[$j] == $mysqlFormattedField){
              printf("<option value=\"%s\" SELECTED>%s</option>\n", $mysqlFormattedField,$field);
              } else {
                printf("<option value=\"%s\">%s</option>\n", $mysqlFormattedField,$field);
              }
            }
            ?>
          </select>
          <select name="sortop<?php echo $j ?>" size="1">
            <option <?php if(isset($order_op[$j]) && strtolower($order_op[$j]) == "desc"){echo "SELECTED";}?> value="DESC">Descending</option>
            <option  <?php if(isset($order_op[$j]) && strtolower($order_op[$j]) == "asc"){echo "SELECTED";}?> value="ASC">Ascending</option>
          </select>
        <?php
        }
        ?>
        </p>
        </div>
        <br>
          <div id="searchbutton">
          <input type="hidden" name="searchtype" value="advanced">
          <p class="center"><input type="Submit" name="submit" value="Search!" style="height: 50px; width: 200px; font: normal 25px 'Arial', Arial, Sans-serif;"></p>
           </div>
           </form>
           </div>
<div id="full">
<br><br><center><font color=4><b>- OR -</b></font></center>
<br><br>
<div class="post">
    <h1>Enter Custom mySQL Query (Advanced Users)</h1>
  <p><center><font size="1">If you find that the above search feature does not quite search for what you want, you can enter in your own mySQL query below. Otherwise leave blank.</font>
  <form method="get" name="search" action="results.php"> 
  <TEXTAREA NAME="query" ROWS=5 COLS=80>
  <?php 
    if(isset($query))
      echo $query;
  ?>
  </TEXTAREA></center></p>
  <p class="center"><input type="Submit" name="submit" value="Search"></p>
  </form>
</div>
</div>
</body>
</html>
