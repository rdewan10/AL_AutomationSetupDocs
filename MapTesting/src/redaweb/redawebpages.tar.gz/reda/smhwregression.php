<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  smhwregression.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
include 'func.php';

$codepointTranslation = array(0=>"QPSK-1/2 @ 21",
                              1=>"QPSK-1/2 @ 44",
                              2=>"QPSK-1/2 @ 1",
                              3=>"QPSK-2/3 @ 46",
                              4=>"QPSK-2/3 @ 2",
                              5=>"QPSK-5/6 @ 43",
                              6=>"QPSK-5/6 @ 8",
                              7=>"8PSK-2/3 @ 59",
                              8=>"8PSK-2/3 @ 3",
                              9=>"8PSK-3/4 @ 58",
                              10=>"8PSK-3/4 @ 7",
                              11=>"8PSK-5/6 @ 59",
                              12=>"8PSK-5/6 @ 7",
                              13=>"8PSK-8/9 @ 45",
                              14=>"8PSK-8/9 @ 4",
                              15=>"QPSK-1/3 @ 1");

$codepointPassCriteria = array(0=>"none",
                               1=>"none",
                               2=>"none",
                               3=>"3.9",
                               4=>"3.9",
                               5=>"6.5",
                               6=>"6.5",
                               7=>"7.5",
                               8=>"7.5",
                               9=>"8.8",
                               10=>"8.8",
                               11=>"10.40",
                               12=>"10.40",
                               13=>"12.40",
                               14=>"12.40",
                               15=>"none");

mysqlSetup($db);

function characteristicsInQueries($characteristics,$table){
  for($i=0;$i<count($characteristics);$i++){
    if($i!=0){
      $fieldsToDisplay .=",";
    }
    if($characteristics[$i]=="modem"){
      $fieldsToDisplay .= "$table.Mac";
    } else if($characteristics[$i]=="hwvers"){
    } else if($characteristics[$i]=="hwtype"){
    } else if($characteristics[$i]=="date"){
    }
  }
  return $fieldsToDisplay;
}

function smRegTimeQuery($testID,$characteristics,$type,$testCase){
  $query ="SELECT ";
  $query .= characteristicsInQueries($characteristics,"SmRegTime") .
           ",AVG(SmRegTime.RegTimeMin),
            STD(SmRegTime.RegTimeMin),
            MIN(SmRegTime.RegTimeMin),
            MAX(SmRegTime.RegTimeMin),
            COUNT(*)";
  $query .=" FROM SmRegTime";
  if($type=="H"){
    $query.=",TestConfig,GroupConfig";
  }
  $query.=" WHERE ";
  if($testID!="" && $type=="T"){
    $query .= "SmRegTime.TestID =$testID AND ";
  } else if ($testID!="" && $type=="H"){
    $query .= "SmRegTime.TestID !=$testID AND
               SmRegTime.TestID=TestConfig.TestID AND
               TestConfig.GrpID=GroupConfig.GrpID AND
               GroupConfig.GroupName=\"Sm Hardware Regression\" AND ";
  } else if ($type=="H"){
    $query .= "SmRegTime.TestID=TestConfig.TestID AND
               TestConfig.GrpID=GroupConfig.GrpID AND
               GroupConfig.GroupName=\"Sm Hardware Regression\" AND ";
  }

  $query .= "SmRegTime.LKG=$testCase 
             GROUP BY " . characteristicsInQueries($characteristics,"SmRegTime");
  return $query;
}

function smSwUpgradeQuery($testID,$characteristics,$type,$testCase){
  $query ="SELECT ";
  $query .= characteristicsInQueries($characteristics,"SmSwUpgrade");
  $query .= ",SUM(IF(SmSwUpgrade.PassFail$testCase=\"pass\",1,0))*100/COUNT(*) AS PassPct,
              min(tempTable.PassPct) AS MinPct,max(tempTable.PassPct) AS MaxPct,
              Count(*)
              FROM SmSwUpgrade,";
  if($type=="H"){
    $query.="TestConfig,GroupConfig,";
  }
  $query .= "(SELECT " . characteristicsInQueries($characteristics,"SmSwUpgrade");
  if($type=="T"){
    $query .= ",SmSwUpgrade.TestID";
  }
  $query .= ",SUM(IF(SmSwUpgrade.PassFail$testCase=\"pass\",1,0))*100/COUNT(*) AS PassPct
              FROM SmSwUpgrade";
  if($type=="H"){
   $query.=",TestConfig,GroupConfig";
  }
  if($testID!="" && $type=="T"){
    $query .= " WHERE SmSwUpgrade.TestID=" . $testID; 
  } else if ($testID!="" && $type=="H"){
    $query.= " WHERE SmSwUpgrade.TestID!=" . $testID . " AND
                     SmSwUpgrade.TestID=TestConfig.TestID AND
                     TestConfig.GrpID=GroupConfig.GrpID AND
                     GroupConfig.GroupName=\"Sm Hardware Regression\"";
  } else if($type=="H"){
    $query.= " WHERE SmSwUpgrade.TestID=TestConfig.TestID AND
                     TestConfig.GrpID=GroupConfig.GrpID AND
                     GroupConfig.GroupName=\"Sm Hardware Regression\"";
  }
  $query.="   GROUP BY SmSwUpgrade.Mac
              ORDER BY SmSwUpgrade.Mac) as tempTable";
  $query .= " WHERE SmSwUpgrade.Mac=tempTable.Mac";
  if($testID!="" && $type=="T"){
    $query.= " AND SmSwUpgrade.TestID=" . $testID;
  } else if ($testID!="" && $type=="H"){
    $query.= " AND SmSwUpgrade.TestID!=" . $testID . " AND
                   SmSwUpgrade.TestID=TestConfig.TestID AND
                   TestConfig.GrpID=GroupConfig.GrpID AND
                   GroupConfig.GroupName=\"Sm Hardware Regression\"";
  } else if ($type=="H"){
    $query.= " AND SmSwUpgrade.TestID=TestConfig.TestID AND
                   TestConfig.GrpID=GroupConfig.GrpID AND
                   GroupConfig.GroupName=\"Sm Hardware Regression\"";
  }
  $query.= " GROUP BY " . characteristicsInQueries($characteristics,"SmSwUpgrade");
  return $query;
}


function mrDsBerQuery($testID,$characteristics,$type,$testCase){
  $query ="SELECT ";
  $query .= "MrDsBerAnalysis.QB,
            MrDsBerAnalysis.DsSymRate,";
  $query .= characteristicsInQueries($characteristics,"MrDsBerAnalysis") .
            ",MAX(MrDsBerAnalysis.QefRepSnr) 
            FROM MrDsBerAnalysis";
  if($type=="H"){
    $query.=",TestConfig,GroupConfig";
  }  
  $query.=" WHERE ";
  if($testID!="" && $type=="T"){
    $query .= "MrDsBerAnalysis.TestID =$testID AND ";
  } else if ($testID!="" && $type=="H"){
    $query .= "MrDsBerAnalysis.TestID !=$testID AND 
               MrDsBerAnalysis.TestID=TestConfig.TestID AND
               TestConfig.GrpID=GroupConfig.GrpID AND
               GroupConfig.GroupName=\"Sm Hardware Regression\" AND ";
  } else if ($type=="H"){
    $query .= "MrDsBerAnalysis.TestID=TestConfig.TestID AND
               TestConfig.GrpID=GroupConfig.GrpID AND
               GroupConfig.GroupName=\"Sm Hardware Regression\" AND ";
  }

  $query .= "MrDsBerAnalysis.QefRepSnr > 0 AND 
             MrDsBerAnalysis.MaxFailRepSnr > 0 AND
             MrDsBerAnalysis.DsSymRate = $testCase
             GROUP BY MrDsBerAnalysis.QB,
                      MrDsBerAnalysis.DsSymRate," . 
                      characteristicsInQueries($characteristics,"MrDsBerAnalysis");
  return $query;
}

function biDirPerQuery($testID,$characteristics,$type,$testCase){
  if($type=="H"){
    return biDirPerHistoricQuery($testID,$characteristics,$testCase);
  } else {
    $query = "SELECT ";
    $query .= characteristicsInQueries($characteristics,"IxOsMacToVlan") .
             ",AVG(IxOsTimeSeries.BitRate),STD(IxOsTimeSeries.BitRate),
              MAX(IxOsTimeSeries.BitRate),COUNT(*) 
              FROM IxOsTimeSeries,
                   IxOsMacToVlan,IxOs";
    //Left in on purpose
    if($type=="H"){
      $query.=",TestConfig,GroupConfig";
    }
    $query.=" WHERE IxOs.IxOsID = IxOsTimeSeries.IxOsID AND 
              IxOsMacToVlan.VlanID = IxOsTimeSeries.VlanID AND ";

    if($testID!="" && $type=="T"){
      $query .= "IxOs.TestID =$testID AND ";
    } else if ($testID!="" && $type=="H"){
      $query .= "IxOs.TestID !=$testID AND
                 IxOs.TestID=TestConfig.TestID AND
                 TestConfig.GrpID=GroupConfig.GrpID AND
                 GroupConfig.GroupName=\"Sm Hardware Regression\" AND ";
    }
    $query.= "IxOs.TrafficDirection = '" . $testCase . "' " .
             "AND IxOsTimeSeries.BitRate != 0 
              GROUP BY " .  characteristicsInQueries($characteristics,"IxOsMacToVlan");

    return $query;
  }
}

function biDirPerHistoricQuery($testID,$characteristics,$testCase){
  $query = "SELECT ";
  $query .=characteristicsInQueries($characteristics,"IxOsMacToVlan");
  $query .=",SUM(IxOsTimeSeries.RxFrames*";
  if($testCase=="upstream"){
    $query.="800";
  } else {
    $query.="4000";
  }
  $query.=")/SUM(IxOsTimeSeries.TxDuration) as BitRate,
            MAX(IxOsTimeSeries.RxFrames*";
  if($testCase=="upstream"){
    $query.="800";
  } else {
    $query.="4000";
  }
  $query.="/IxOsTimeSeries.TxDuration) as MaxBitRate,
            COUNT(*)
            FROM IxOsTimeSeries 
            JOIN (IxOsMacToVlan,
                  IxOs,
                  (SELECT MAX(IxOsTimeSeries.ID) as id2
                   FROM IxOsTimeSeries,
                        IxOsMacToVlan,
                        IxOs,
                        TestConfig,
                        GroupConfig
                   WHERE IxOsTimeSeries.VlanID=IxOsMacToVlan.VlanID AND
                         IxOs.TestID=IxOsMacToVlan.TestID AND
                         IxOs.IxOsID=IxOsTimeSeries.IxOsID AND
                         IxOs.TestID=TestConfig.TestID AND
                         TestConfig.GrpID=GroupConfig.GrpID AND
                         GroupConfig.GroupName=\"SM Hardware Regression\" AND
                         TestConfig.TestName=\"VlanPER\" AND";
  if($testID!=""){
    $query.="            IxOs.TestID!=" . $testID . " AND ";
  }
    $query.="            IxOs.TrafficDirection='" . $testCase . "' " .
                  "GROUP BY IxOs.TestID,
                            IxOsMacToVlan.Mac) as maxIdTbl)
            ON IxOsTimeSeries.ID = maxIdTbl.id2 AND
               IxOsTimeSeries.VlanID=IxOsMacToVlan.VlanID AND
               IxOs.TestID=IxOsMacToVlan.TestID AND
               IxOs.IxOsID=IxOsTimeSeries.IxOsID
            GROUP BY " . characteristicsInQueries($characteristics,"IxOsMacToVlan") .
           " ORDER BY " . characteristicsInQueries($characteristics,"IxOsMacToVlan");
  return $query;
}

?>

<!--
All webpages must start with <html> and usually have <head> tags.
-->
<html>
<head>
  <title>ReDa: SurfBeam Test Results Database</title> <!-- The <title> tag denotes what is displayed on bar
                                                         at the top of the browser -->
  <link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
bodyStyle();
banner();
navbar1("smhwregression");
echo "<br>";

if($_GET != NULL){
  while(list($key, $value) = each($_GET)){
    $input[$key] = $value;
  }

  if($input["characteristic"]==""){
    echo "<br><center>ERROR: No characterstic selected</center></body></html>";
    exit();
  }
  if($input["testName"]==""){
    echo "<br><center>ERROR: No test name selected</center></body></html>";
    exit();
  }

  echo "<table width=\"90%\"><tr>
        <td>
          <p class=\"tableheader\">Test Name</p>
        </td>
        <td>
          <p class=\"tableheader\">Test Case</p>
        </td>";
  if($input["grpID"]!=""){
    echo "<td><p class=\"tableheader\">Test ID</p></td>";
  }
  for($i=0;$i<count($input["characteristic"]);$i++){
    if($input["characteristic"][$i]=="modem"){
      echo "<td><p class=\"tableheader\">MAC Address</p></td>";
      //echo "<td><p class=\"tableheader\">Serial</p></td>";
    } else if($input["characteristic"][$i]=="hwvers"){
    } else if($input["characteristic"][$i]=="hwtype"){
    } else if($input["characteristic"][$i]=="date"){
    }
  }
  if($input["grpID"]!=""){
  }

  echo "<td><p class=\"tableheader\">Pass Criteria</p></td>
        <td><p class=\"tableheader\">Pass/Fail</p></td>
        <td ";
  if($input["grpID"]!=""){
    echo "colspan=\"2\"";
  }
  echo " width=\"12%\"><p class=\"tableheader\">Avg</p></td>
        <td ";
  if($input["grpID"]!=""){
    echo "colspan=\"2\"";
  }
  echo " width=\"12%\"><p class=\"tableheader\">Std</p></td>
        <td ";
  if($input["grpID"]!=""){
    echo "colspan=\"2\"";
  }
  echo " width=\"12%\"><p class=\"tableheader\">Min</p></td>
        <td ";
  if($input["grpID"]!=""){
    echo "colspan=\"2\"";
  }
  echo " width=\"12%\"><p class=\"tableheader\">Max</p></td>
        <td ";
  if($input["grpID"]!=""){
    echo "colspan=\"2\"";
  }
  echo " width=\"12%\"><p class=\"tableheader\">Count</p></td>
        \n</tr>";
  echo "$mrDsBerForGrp<br><br><br>$mrDsBerHistoric";
  for($i=0;$i<count($input["testName"]);$i++){

    // ************************************************************************
    //                                 SmRegTime
    // ************************************************************************
    if($input["testName"][$i]=="SmRegTime"){
      $smRegTimeTypes=array("0","1");
      foreach($smRegTimeTypes as $smRegTimeCase){
        if($input["grpID"]!=""){
          $testListQuery = "SELECT DISTINCT TestConfig.TestID FROM TestConfig,SmRegTime WHERE SmRegTime.TestID=TestConfig.TestID AND GrpID=" . $input["grpID"];
          $resultsTestList = mysql_query($testListQuery,$db);while ($rowTestList = mysql_fetch_row($resultsTestList)){
            $smRegTimeHistoric= smRegTimeQuery($rowTestList[0],$input["characteristic"],"H",$smRegTimeCase);
            $smRegTimeForGrp=smRegTimeQuery($rowTestList[0],$input["characteristic"],"T",$smRegTimeCase);
            $resultsGrp = mysql_query($smRegTimeForGrp,$db);
            $resultsHistoric = mysql_query($smRegTimeHistoric,$db);

            $rowGrp = mysql_fetch_row($resultsGrp);
            $rowHistoric = mysql_fetch_row($resultsHistoric);

            while($rowGrp[0]!=""){
              $grpIdentifyingString="";
              $historicIdentifyString="";
              for($j=0;$j<count($input["characteristic"]);$j++){
               $grpIdentifyingString.=$rowGrp[$j];
               $historicIdentifyString.=$rowHistoric[$j];
              }

              if(strcmp($grpIdentifyingString,$historicIdentifyString) < 0 || $historicIdentifyString==""){
                echo "<tr><td><p class=\"table\">SmRegTime</p></td>";
                echo "<td><p class=\"table\">";
                if($smRegTimeCase=="0"){
                  echo "Without LKG";
                  $passCriteria=10;
                } else {
                  echo "With LKG";
                  $passCriteria=3;
                }
                echo "</p></td>
                      <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                for($j=0;$j<mysql_num_fields($resultsGrp);$j++){
                   if($j<count($input["characteristic"])){
                     echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                   } else if($j==count($input["characteristic"])){
                     echo "<td><p class=\"table\">$passCriteria</p></td><td>";
                     if($rowGrp[$j]<$passCriteria){
                       echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                     } else {
                       echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                     }
                   }
                   if($j>=count($input["characteristic"])){
                     echo "<td><p class=\"table\">" . number_format($rowGrp[$j],2) . "</p></td>
                           <td><p class=\"table\">-</p></td>";
                   }
                }
                echo "</tr>";
                $rowGrp = mysql_fetch_row($resultsGrp);
              } else if(strcmp($grpIdentifyingString,$historicIdentifyString) > 0){
                //echo "<tr><td>" . $rowGrp[0] . "/" .  $rowHistoric[0] . "</td></tr>";
                $rowHistoric = mysql_fetch_row($resultsHistoric);
              } else if(strcmp($grpIdentifyingString,$historicIdentifyString)==0){
                echo "<tr><td><p class=\"table\">SmRegTime</p></td>";
                echo "<td><p class=\"table\">";
                if($smRegTimeCase=="0"){
                  echo "Without LKG";
                  $passCriteria=10;
                } else {
                  echo "With LKG";
                  $passCriteria=3;
                }
                echo "</p></td>
                      <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                for($j=0;$j<mysql_num_fields($resultsGrp);$j++){
                  if($j<count($input["characteristic"])){
                    echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                    continue;
                  } else if($j==count($input["characteristic"])){
                    echo "<td><p class=\"table\">$passCriteria</p></td><td>";
                     if($rowGrp[$j]<$passCriteria){
                       echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                     } else {
                       echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                     }
                  }
                  if($j!=mysql_num_fields($resultsGrp)-1){
                    if($rowGrp[$j]>$rowHistoric[$j]){
                      echo "<td><p class=\"table\"><span style=\"color: red;\">" .
                            number_format($rowGrp[$j],2) . "</span></p></td><td><p class=\"table\">" .
                            number_format($rowHistoric[$j],2) ."</p></td>";
                    } else if ($rowGrp[$j]<$rowHistoric[$j]){
                      echo "<td><p class=\"table\"><span style=\"color: green;\">" .
                            number_format($rowGrp[$j],2) . "</span></p></td><td><p class=\"table\">" .
                            number_format($rowHistoric[$j],2) ."</p></td>";
                    } else {
                      echo "<td><p class=\"table\"><span style=\"color: #FF9900;\">" .
                            number_format($rowGrp[$j],2) . "</span></p></td><td><p class=\"table\"> " .
                            number_format($rowHistoric[$j],2) ."</p></td>";
                    }
                  } else {
                    echo "<td><p class=\"table\">" .
                            $rowGrp[$j] . "</p></td><td><p class=\"table\"> " .
                            $rowHistoric[$j] ."</p></td>";
                  }
                }
                echo "</tr>";
                $rowGrp = mysql_fetch_row($resultsGrp);
                $rowHistoric = mysql_fetch_row($resultsHistoric);
              }
            }
          }
        } else {
          $smRegTimeHistoric=smRegTimeQuery("",$input["characteristic"],"H",$smRegTimeCase);
          $resultsHistoric = mysql_query($smRegTimeHistoric,$db);
          while ($rowHistoric = mysql_fetch_row($resultsHistoric)){
            echo "<tr><td><p class=\"table\">SmRegTime</p></td>";
            echo "<td><p class=\"table\">";
            if($smRegTimeCase=="0"){
              echo "Without LKG";
              $passCriteria=10;
            } else {
              echo "With LKG";
              $passCriteria=3;
            }
            echo "</p></td>";
            for($j=0;$j<count($input["characteristic"]);$j++){
              echo "<td><p class=\"table\">" . $rowHistoric[$j] . "</p></td>";
            }
            echo "<td><p class=\"table\">" . $passCriteria . "</p></td><td>";
            if($rowHistoric[$j]<=$passCriteria) {
              echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
            } else {
              echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
            }
            for(;$j<mysql_num_fields($resultsHistoric);$j++){
              echo "<td><p class=\"table\">" . number_format($rowHistoric[$j]) ."</p></td>";
            }
            echo "</tr>";
          }
        }
      }
    // ************************************************************************
    //                                 SmSwUpgrade
    // ************************************************************************
    } else if($input["testName"][$i]=="SmSwUpgrade"){
      $smSwUpgradeTypes=array("Vers","OperStatus");
      foreach($smSwUpgradeTypes as $smSwUpgradeCase){
        if($input["grpID"]!=""){
          $testListQuery = "SELECT DISTINCT TestConfig.TestID FROM TestConfig,SmSwUpgrade WHERE SmSwUpgrade.TestID=TestConfig.TestID AND GrpID=" . $input["grpID"];
          $resultsTestList = mysql_query($testListQuery,$db);
          while ($rowTestList = mysql_fetch_row($resultsTestList)){
            $smSwUpgradeHistoric= smSwUpgradeQuery($rowTestList[0],$input["characteristic"],"H",$smSwUpgradeCase);
            $smSwUpgradeForGrp=smSwUpgradeQuery($rowTestList[0],$input["characteristic"],"T",$smSwUpgradeCase);
            $resultsGrp = mysql_query($smSwUpgradeForGrp,$db);
            $resultsHistoric = mysql_query($smSwUpgradeHistoric,$db);

            $rowGrp = mysql_fetch_row($resultsGrp);
            $rowHistoric = mysql_fetch_row($resultsHistoric);

            while($rowGrp[0]!=""){
              $grpIdentifyingString="";
              $historicIdentifyString="";
              for($j=0;$j<count($input["characteristic"]);$j++){
               $grpIdentifyingString.=$rowGrp[$j];
               $historicIdentifyString.=$rowHistoric[$j];
              }
              //There are no other matches for this particular set of characteristics.
              if(strcmp($grpIdentifyingString,$historicIdentifyString) < 0 || $historicIdentifyString==""){
                echo "<tr><td><p class=\"table\">SmSwUpgrade</p></td>";
                echo "<td><p class=\"table\">";
                if($smSwUpgradeCase=="Vers"){
                  echo "Version Status";
                } else {
                  echo "Oper Status";
                }
                echo "</p></td>
                      <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                for($j=0;$j<mysql_num_fields($resultsGrp);$j++){
                   if($j<count($input["characteristic"])){
                     echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                     continue;
                   } else if($j==count($input["characteristic"])){
                     echo "<td><p class=\"table\">100</p></td><td>";
                     if($rowGrp[$j]>=100){
                       echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                     } else {
                       echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                     }
                   } else if($j==mysql_num_fields($resultsGrp)-3){
                     echo "<td><p class=\"table\">-</p></td>
                           <td><p class=\"table\">-</p></td>";
                   }
                   echo "<td><p class=\"table\">" . number_format($rowGrp[$j]) .
                        "</p></td><td><p class=\"table\">-</p></td>";
                }
                echo "</tr>";
                $rowGrp = mysql_fetch_row($resultsGrp);
              } else if(strcmp($grpIdentifyingString,$historicIdentifyString) > 0){
                //echo "<tr><td>" . $rowGrp[0] . "/" .  $rowHistoric[0] . "</td></tr>";
                $rowHistoric = mysql_fetch_row($resultsHistoric);
              } else if(strcmp($grpIdentifyingString,$historicIdentifyString)==0){
                echo "<tr><td><p class=\"table\">SmSwUpgrade</p></td>";
                echo "<td><p class=\"table\">";
                if($smSwUpgradeCase=="Vers"){
                  echo "Version Status";
                } else {
                  echo "Oper Status";
                }
                echo "</p></td>
                      <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                for($j=0;$j<mysql_num_fields($resultsGrp);$j++){
                  if($j<count($input["characteristic"])){
                    echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                    continue;
                  } else if($j==count($input["characteristic"])){
                     echo "<td><p class=\"table\">100</p></td><td>";
                     if($rowGrp[$j]>=100){
                       echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                     } else {
                       echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                     }
                  } else if($j==mysql_num_fields($resultsGrp)-3){
                    echo "<td><p class=\"table\">-</p></td>
                          <td><p class=\"table\">-</p></td>";
                  }
                  if($j!=mysql_num_fields($resultsGrp)-1){
                    if(number_format($rowGrp[$j])>number_format($rowHistoric[$j])){
                      echo "<td><p class=\"table\"><span style=\"color: green;\">" . 
                            number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" . 
                            number_format($rowHistoric[$j]) ."</p></td>";
                    } else if (number_format($rowGrp[$j])<number_format($rowHistoric[$j])){
                      echo "<td><p class=\"table\"><span style=\"color: red;\">" . 
                            number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" . 
                            number_format($rowHistoric[$j]) ."</p></td>";
                    } else {
                      echo "<td><p class=\"table\"><span style=\"color: #FF9900;\">" . 
                            number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" . 
                            number_format($rowHistoric[$j]) ."</p></td>";
                    }
                  } else {
                    echo "<td><p class=\"table\">" .
                            number_format($rowGrp[$j]) . "</p></td><td><p class=\"table\">" .
                            number_format($rowHistoric[$j]) ."</p></td>";
                  }
                }
                echo "</tr>";
                $rowGrp = mysql_fetch_row($resultsGrp);
                $rowHistoric = mysql_fetch_row($resultsHistoric);
              }
            }
          }
        } else {
          $smSwUpgradeHistoric=smSwUpgradeQuery("",$input["characteristic"],"H",$smSwUpgradeCase); 
          $resultsHistoric = mysql_query($smSwUpgradeHistoric,$db);
          while ($rowHistoric = mysql_fetch_row($resultsHistoric)){
            echo "<tr><td><p class=\"table\">SmSwUpgrade</p></td>";
            echo "<td><p class=\"table\">";
            if($smSwUpgradeCase=="Vers"){
              echo "Version Status";
            } else {
              echo "Oper Status";
            }
            echo "</p></td>";
            for($j=0;$j<count($input["characteristic"]);$j++){
              echo "<td><p class=\"table\">" . $rowHistoric[$j] . "</p></td>";
            }
            echo "<td><p class=\"table\">100</p></td><td>";
            if(number_format($rowHistoric[$j])>=100) {
              echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
            } else {
              echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
            }
            for(;$j<mysql_num_fields($resultsHistoric);$j++){
              if($j==mysql_num_fields($resultsHistoric)-3){
                echo "<td><p class=\"table\">-</p></td>";
              }
              echo "<td><p class=\"table\">" . number_format($rowHistoric[$j]) ."</p></td>";
            }
            echo "</tr>";
          }
        }
      }
    // ************************************************************************
    //                                  MrDsBer
    // ************************************************************************
    } else if($input["testName"][$i]=="MrDsBer"){
        $mrDsBerTypes=array("22.5","30");
        foreach($mrDsBerTypes as $mrDsBerCase){
          if($input["grpID"]!=""){
            $testListQuery = "SELECT DISTINCT TestConfig.TestID FROM TestConfig,MrDsBerAnalysis WHERE MrDsBerAnalysis.TestID=TestConfig.TestID AND GrpID=" . $input["grpID"];
            $resultsTestList = mysql_query($testListQuery,$db);
            while ($rowTestList = mysql_fetch_row($resultsTestList)){
              $mrDsBerHistoric = mrDsBerQuery($rowTestList[0],$input["characteristic"],"H",$mrDsBerCase);
              $mrDsBerForGrp = mrDsBerQuery($rowTestList[0],$input["characteristic"],"T",$mrDsBerCase);
              $resultsGrp = mysql_query($mrDsBerForGrp,$db);
              $resultsHistoric = mysql_query($mrDsBerHistoric,$db);
            
              $rowGrp = mysql_fetch_row($resultsGrp);
              $rowHistoric = mysql_fetch_row($resultsHistoric);
            
              while($rowGrp[0]!=""){
                $grpIdentifyingString=$rowGrp[0] . $rowGrp[1];
                $historicIdentifyString=$rowHistoric[0] . $rowHistoric[1];
                for($j=2;$j<(count($input["characteristic"])+2);$j++){
                  $grpIdentifyingString.=$rowGrp[$j];
                  $historicIdentifyString.=$rowHistoric[$j];
                }
                //There are no other matches for this particular set of characteristics.
                if(strcmp($grpIdentifyingString,$historicIdentifyString) < 0 || $historicIdentifyString==""){
                  echo "<tr><td><p class=\"table\">MrDsBer</p></td>";
                  echo "<td><p class=\"table\">$mrDsBerCase ";
                  echo $codepointTranslation[$rowGrp[0]];
                  echo "</p></td>
                        <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                   for($j=2;$j<mysql_num_fields($resultsGrp);$j++){
                    if($j<(count($input["characteristic"])+2)){
                      echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                    } else {
                      echo "<td><p class=\"table\">" . $codepointPassCriteria[$rowGrp[0]] . "</p></td><td>";
                      if($codepointPassCriteria[$rowGrp[0]]=="none"){
                        echo "<p class=\"table\">n/a</p></td>";
                      } else if($rowGrp[$j]<=$codepointPassCriteria[$rowGrp[0]]){
                        echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                      } else {
                        echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                      }
                      echo "<td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">" . $rowGrp[$j] .
                           "</p></td><td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">-</p></td>
                            <td><p class=\"table\">-</p></td>";
                    }
                  }
                  echo "</tr>";
                  $rowGrp = mysql_fetch_row($resultsGrp);
                } else if(strcmp($grpIdentifyingString,$historicIdentifyString) > 0){
                  //echo "<tr><td>" . $rowGrp[0] . "/" .  $rowHistoric[0] . "</td></tr>";
                  $rowHistoric = mysql_fetch_row($resultsHistoric);
                } else if(strcmp($grpIdentifyingString,$historicIdentifyString)==0){
                  echo "<tr><td><p class=\"table\">MrDsBer</p></td>";
                  echo "<td><p class=\"table\">$mrDsBerCase ";
                  echo $codepointTranslation[$rowGrp[0]];
                  echo "</p></td>
                        <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                  for($j=2;$j<mysql_num_fields($resultsGrp);$j++){
                    if($j<(count($input["characteristic"])+2)){
                      echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                    } else {
                       echo "<td><p class=\"table\">" . $codepointPassCriteria[$rowGrp[0]] . "</p></td><td>";
                       if($codepointPassCriteria[$rowGrp[0]]=="none"){
                         echo "<p class=\"table\">n/a</p></td>";
                       } else if($rowGrp[$j]<=$codepointPassCriteria[$rowGrp[0]]){
                         echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                       } else {
                         echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                       }
                       echo "<td><p class=\"table\">-</p></td>
                             <td><p class=\"table\">-</p></td>
                             <td><p class=\"table\">-</p></td>
                             <td><p class=\"table\">-</p></td>
                             <td><p class=\"table\">-</p></td>
                          <td><p class=\"table\">-</p></td>";
                       if($j!=mysql_num_fields($resultsGrp)-1){
                         if($rowGrp[$j]>$rowHistoric[$j]){
                           echo "<td><p class=\"table\"><span style=\"color: red;\">" . 
                           $rowGrp[$j] . "</span></p></td><td><p class=\"table\">" . 
                           $rowHistoric[$j] ."</p></td>";
                         } else if ($rowGrp[$j]<$rowHistoric[$j]){
                           echo "<td><p class=\"table\"><span style=\"color: green;\">" . 
                           $rowGrp[$j] . "</span></p></td><td><p class=\"table\">" . 
                           $rowHistoric[$j] ."</p></td>";
                         } else {
                           echo "<td><p class=\"table\"><span style=\"color: #FF9900;\">" . 
		           $rowGrp[$j] . "</span></p></td><td><p class=\"table\">" . 
                           $rowHistoric[$j] ."</p></td>";
                         }
                       } else {
                         echo "<td><p class=\"table\">" .
                         number_format($rowGrp[$j],2) . "</p></td><td><p class=\"table\"> " .
                         number_format($rowHistoric[$j],2) ."</p></td>";
                       }
                       echo "<td><p class=\"table\">-</p></td><td><p class=\"table\">-</p></td>";
	            }
                  }
  	          echo "</tr>";
                  $rowGrp = mysql_fetch_row($resultsGrp);
                  $rowHistoric = mysql_fetch_row($resultsHistoric);
                }
              }
            }
          } else {
        $mrDsBerHistoric=mrDsBerQuery("",$input["characteristic"],"H",$mrDsBerCase);
        $resultsHistoric = mysql_query($mrDsBerHistoric,$db);
        while ($rowHistoric = mysql_fetch_row($resultsHistoric)){
          echo "<tr><td><p class=\"table\">MrDsBer</p></td>";
          echo "<td><p class=\"table\">$mrDsBerCase ";
          echo $codepointTranslation[$rowHistoric[0]];
          echo "</p></td>";
          for($j=2;$j<mysql_num_fields($resultsHistoric);$j++){
            if($j<(count($input["characteristic"])+2)){
              echo "<td><p class=\"table\">" . $rowHistoric[$j] . "</p></td>";
            } else {
              echo "<td><p class=\"table\">" . $codepointPassCriteria[$rowHistoric[0]] . "</p></td><td>";
              if($codepointPassCriteria[$rowHistoric[0]]=="none"){
                echo "<p class=\"table\">n/a</p></td>";
              } else if(number_format($rowHistoric[$j],2)<=$codepointPassCriteria[$rowHistoric[0]]){
                echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
              } else {
                echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
              }
              echo "<td><p class=\"table\">-</p></td>
                    <td><p class=\"table\">-</p></td>
                    <td><p class=\"table\">-</p></td>
                    <td><p class=\"table\">" . number_format($rowHistoric[$j],2) ."</p></td>
                    <td><p class=\"table\">-</p></td>";
            }  
          }
          echo "</tr>";
        }
      }
    }
    // ************************************************************************
    //                               BidirectionalPER
    // ************************************************************************
    } else if($input["testName"][$i]=="BidirectionalPER"){
      $biDirPerTypes=array("downstream","upstream");
      foreach($biDirPerTypes as $biDirPerCase){
        if($input["grpID"]!=""){
          $testListQuery = "SELECT DISTINCT TestConfig.TestID 
                            FROM TestConfig,
                                 IxOsMacToVlan 
                            WHERE IxOsMacToVlan.TestID=TestConfig.TestID AND 
                                  GrpID=" . $input["grpID"];
          $resultsTestList = mysql_query($testListQuery,$db);
          while ($rowTestList = mysql_fetch_row($resultsTestList)){
            $biDirPerHistoric = biDirPerQuery($rowTestList[0],$input["characteristic"],"H",$biDirPerCase);
            $biDirPerForGrp = biDirPerQuery($rowTestList[0],$input["characteristic"],"T",$biDirPerCase);
            $resultsGrp = mysql_query($biDirPerForGrp,$db);
            $resultsHistoric = mysql_query($biDirPerHistoric,$db);

            $rowGrp = mysql_fetch_row($resultsGrp);
            $rowHistoric = mysql_fetch_row($resultsHistoric);

            while($rowGrp[0]!=""){
              $grpIdentifyingString="";
              $historicIdentifyString="";
              for($j=0;$j<count($input["characteristic"]);$j++){
                $grpIdentifyingString.=$rowGrp[$j];
                $historicIdentifyString.=$rowHistoric[$j];
              }
              //There are no other matches for this particular set of characteristics.
              if(strcmp($grpIdentifyingString,$historicIdentifyString) < 0 || $historicIdentifyString==""){
                echo "<tr><td><p class=\"table\">BidirectionalPER</p></td>";
                echo "<td><p class=\"table\">";
                if($biDirPerCase=="upstream"){
                  echo "Upstream";
                  $passRate=260000;
                } else {
                  echo "Downstream";
                  $passRate=1512000;
                }
                echo " BPS</p></td>
                      <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                for($j=0;$j<mysql_num_fields($resultsGrp);$j++){
                  if($j<count($input["characteristic"])){
                    echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                  } else {
                     echo "<td><p class=\"table\">$passRate</p></td><td>";
                     if($rowGrp[$j]>=$passRate){
                       echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                     } else {
                       echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                     }
                    echo "<td><p class=\"table\">" . number_format($rowGrp[$j]) . "</p></td><td><p class=\"table\">-</p></td>
                          <td><p class=\"table\">" . number_format($rowGrp[$j+1]) . "</p></td><td><p class=\"table\">-</p></td>
                          <td><p class=\"table\">-</p></td>
                          <td><p class=\"table\">-</p></td>
                          <td><p class=\"table\">" . number_format($rowGrp[$j+2]) . "</p></td><td><p class=\"table\">-</p></td>
                          <td><p class=\"table\">" . number_format($rowGrp[$j+3]) . "</p></td><td><p class=\"table\">-</p></td>";
                    break;
                  }
                }
                echo "</tr>";
                $rowGrp = mysql_fetch_row($resultsGrp);
              } else if(strcmp($grpIdentifyingString,$historicIdentifyString) > 0){
                //echo "<tr><td>" . $rowGrp[0] . "/" .  $rowHistoric[0] . "</td></tr>";
                $rowHistoric = mysql_fetch_row($resultsHistoric);
              } else if(strcmp($grpIdentifyingString,$historicIdentifyString)==0){
                echo "<tr><td><p class=\"table\">BidirectionalPER</p></td>";
                echo "<td><p class=\"table\">";
                if($biDirPerCase=="upstream"){
                  echo "Upstream";
                  $passRate=256000;
                } else {
                  echo "Downstream";
                  $passRate=1512000;
                }
                echo " BPS</p></td>
                       <td><p class=\"table\">" . $rowTestList[0] . "</p></td>";
                for($j=0;$j<mysql_num_fields($resultsGrp);$j++){
                  if($j<count($input["characteristic"])){
                    echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
                    continue;
                  } else if($j==count($input["characteristic"])){
                    echo "<td><p class=\"table\">$passRate</p></td><td>";
                     if($rowGrp[$j]>=$passRate){
                       echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                     } else {
                       echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                     }
                  } else if($j==mysql_num_fields($resultsGrp)-2){
                    echo "<td><p class=\"table\">-</p></td><td><p class=\"table\">-</p></td>";
                  }
                 
                  if($j==mysql_num_fields($resultsGrp)-4){ 
                    if($rowGrp[$j]>$rowHistoric[$j]){
                      echo "<td><p class=\"table\"><span style=\"color: green;\">" .
                            number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" .
                            number_format($rowHistoric[$j]) ."</p></td>";
                    } else if ($rowGrp[$j]<$rowHistoric[$j]){
                      echo "<td><p class=\"table\"><span style=\"color: red;\">" .
                            number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" .
                            number_format($rowHistoric[$j]) . "</p></td>";
                    } else {
                      echo "<td><p class=\"table\"><span style=\"color: #FF9900;\">" .
                      number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" .
                      number_format($rowHistoric[$j]) ."</p></td>";
                    }
                  } else if($j==mysql_num_fields($resultsGrp)-3){
                    echo "<td><p class=\"table\">" . number_format($rowGrp[$j]) . "</p></td><td><p class=\"table\">-</p></td>";
                  } else if($j==mysql_num_fields($resultsGrp)-2){
                    if($rowGrp[$j]>$rowHistoric[$j-1]){
                      echo "<td><p class=\"table\"><span style=\"color: green;\">" .
                            number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" .
                            number_format($rowHistoric[$j-1]) ."</p></td>";
                    } else if ($rowGrp[$j]<$rowHistoric[$j-1]){
                      echo "<td><p class=\"table\"><span style=\"color: red;\">" .
                            number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" .
                            number_format($rowHistoric[$j-1]) . "</p></td>";
                    } else {
                      echo "<td><p class=\"table\"><span style=\"color: #FF9900;\">" .
                      number_format($rowGrp[$j]) . "</span></p></td><td><p class=\"table\">" .
                      number_format($rowHistoric[$j-1]) ."</p></td>";
                    }
                  } else {
                    echo "<td><p class=\"table\">" .
                            number_format($rowGrp[$j]) . "</p></td><td><p class=\"table\"> " .
                            number_format($rowHistoric[$j-1]) ."</p></td>";
                  }
                }
                echo "</tr>";
                $rowGrp = mysql_fetch_row($resultsGrp);
                $rowHistoric = mysql_fetch_row($resultsHistoric);
              }
            }
          }
        } else {
          $biDirPerHistoric = biDirPerQuery("",$input["characteristic"],"H",$biDirPerCase);
          $resultsHistoric = mysql_query($biDirPerHistoric,$db);

          while($rowHistoric = mysql_fetch_row($resultsHistoric)){
            echo "<tr><td><p class=\"table\">BidirectionalPER</p></td>";
            echo "<td><p class=\"table\">";
            if($biDirPerCase=="upstream"){
              echo "Upstream";
              $passRate=256000;
            } else {
              echo "Downstream";
              $passRate=1512000;
            }
            echo " BPS</p></td>";
            for($j=0;$j<mysql_num_fields($resultsHistoric);$j++){
              if($j<count($input["characteristic"])){
                echo "<td><p class=\"table\">" . $rowGrp[$j] . "</p></td>";
              } else {
                echo "<td><p class=\"table\">$passRate</p></td><td>";
                if($rowGrp[$j]>=$passRate){
                  echo "<p class=\"table\"><span style=\"color: green;\">Pass</span></p></td>";
                } else {
                  echo "<p class=\"table\"><span style=\"color: red;\">Fail</span></p></td>";
                }
                echo "<td><p class=\"table\">" . number_format($rowHistoric[$j]) . "</p></td>
                      <td><p class=\"table\">" . number_format($rowHistoric[$j+1]) . "</p></td>
                      <td><p class=\"table\">-</p></td>
                      <td><p class=\"table\">" . number_format($rowHistoric[$j+2]) . "</p></td>
                      <td><p class=\"table\">" . number_format($rowHistoric[$j+3]) . "</p></td>";
                break;
              }
            }
            echo "</tr>";
          }
        } //else
      } //foreach
    } // if BiDirectionalPER
  }//foreach testname
  echo "\n</table>\n";
} else {
  echo "ERROR: You did not make any selections.";
}
?>
</body>
</html>
