<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  save.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: save.php
 * Purpose: This page allows user to save queries that they think would be nice
 *          to have. After clicking on "Save Query" from the results.php page,
 *          the user can either save the query as a new query or overwrite a
 *          previously saved search on this page.
 *
 *****************************************************************************/
?>

<!-- Refer to the comments in index.php for help with basic html, php and help with the title/nav bars. -->
<html>
<head>
<title>Save Query</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
include 'func.php';
mysqlSetup($db);
while(list($key, $value) = each($_GET)){
  $input[$key] = $value;
}
$query = $input["query"];
?>
<?php
bodyStyle();
banner();
navbar1("save");
navbar2("results", "save", $query);
?>
<br>
<form method="post" action="store.php">
</font>
<fieldset class="fieldset">
  <legend><font face="arial"><b>New Query</b></font></legend><font face="arial">
  <font size=1>Please keep it brief.</font><br>
  <input type="text" size=40 name="desc">
  <input type="hidden" name="query" value="<?php echo $input["query"] ?>">
  &nbsp;&nbsp;&nbsp;<input type="Submit" name="submit" value="Save">
</form>
</fieldset>
<form method="post" action="store.php">
</font>
<fieldset class="fieldset">
  <legend>
    <font face ="arial"><b>Overwrite Saved Search</b></font>
  </legend><font face ="arial">
  <input type="hidden" name="query" value="<?php echo $input["query"] ?>">
  <select name="desc" size="1">
    <option value="" selected></option>
    <?php
    //Get a list of saved searches.
    $query = "SELECT $savedQueryDescriptionFieldName FROM $savedQueryTableName ORDER BY $savedQueryDescriptionFieldName ASC";
    $result = mysql_query($query,$db);
    while ($myrow = mysql_fetch_row($result)){
      printf("<option value=\"%s\">%s</option>", $myrow[0], $myrow[0]);
    }
    ?>
  </select>
  &nbsp;&nbsp;&nbsp;<input type="Submit" name="submit" value="Overwrite">
</fieldset>
</html>
