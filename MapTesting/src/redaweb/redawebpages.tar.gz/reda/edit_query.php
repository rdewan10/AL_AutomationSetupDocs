<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  edit_query.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: edit_query.php
 * Purpose: This page allows users to edit saved queries.
 *
 *****************************************************************************/

include 'func.php';
mysqlSetup($db);
// the following code gathers all data sent to this page using the POST method.
while(list($key, $value) = each($_POST)){
  $input[$key] = $value;
}
$done=0;
?>
<!-- Refer to the comments in index.php for help with basic html and help with the title/nav bars. -->
<html>
<head>
<title>Edit Saved Query</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
bodyStyle();
banner();
navbar1("help");
navbar2("admin", "");
navbar3("edit_query");
?>
<br><br>
<?php
if($input["confirm"] != "") {
  // DELETE function in mySQL does exactly what you'd think it does: delete one or more entries matching the
  // criteria.
  $query ="DELETE FROM $savedQueryTableName WHERE $savedQueryFieldName=" . "\"" . $input["query"] . "\" LIMIT 1"; //
  $query =str_replace("\\","",$query);
  if(mysql_query($query,$db)) {
    echo "<br><br><center>Saved Query Deleted Successfully.</center>";
  } else {
    // UH OH...something bad happened.
    echo "<br><br><center>ERROR!</center>";
  }
} elseif ($input["rename"] != "") {
  if($input["query"] != "") {
    $query=str_replace("\\","",$input["query"]);
    $update="UPDATE $savedQueryFieldName SET $savedQueryDescriptionFieldName = '" . $input["rename"] . "' WHERE $savedQueryFieldName=\"" . $query . "\"";
    if(mysql_query($update,$db) || $done==1){
      echo "<br><br><center>Saved Query Renamed Successfully.</center>";
    } else {
      echo "<br><br><center>ERROR!</center>";
    }
  }
} elseif ($input["query"] != "") {
  ?>
  <br><br>
  <center>
  Really Delete From Entry?
  <form method="post" action="edit_query.php">
  <input type="Hidden" name="query" value="<?php echo $input["query"] ?>">
  <input type="Submit" name="confirm" value="OK">
  </center>
  <?php
} else {
?>
<form method="post" action="edit_query.php"> <!--Tutorial on Forms: http://www.htmlgoodies.com/tutorials/forms/-->
</font>
<fieldset class="fieldset">
  <legend><font face="arial">Select Query For Deletion</font></legend><font face="arial">
  <select name="query" size="1">
    <option value="" selected></option>
    <?php
    //Print out all the queries that one can edit
    $query = "SELECT $savedQueryFieldName,$savedQueryDescriptionFieldName FROM $savedQueryTableName ORDER BY $savedQueryDescriptionFieldName ASC";
    $result = mysql_query($query,$db);
    while ($myrow = mysql_fetch_row($result)){
      printf("<option value=\"%s\">%s</option>", $myrow[0], $myrow[1]);
    }
    ?>
  </select>
  <input type="Submit" name="submit" value="Delete Query">
</fieldset>
</form>
<form method="post" action="edit_query.php"> <!--Tutorial on Forms: http://www.htmlgoodies.com/tutorials/forms/-->
</font>
<fieldset class="fieldset">
  <legend><font face="arial">Rename a Query</font></legend><font face="arial">
  <select name="query" size="1">
    <option value="" selected></option>
    <?php
    //Print out all queries.
    $query = "SELECT $savedQueryFieldName,$savedQueryDescriptionFieldName FROM $savedQueryTableName ORDER BY $savedQueryDescriptionFieldName ASC";
    $result = mysql_query($query,$db);
    while ($myrow = mysql_fetch_row($result)){
      printf("<option value=\"%s\">%s</option>", $myrow[0], $myrow[1]);
    }
    ?>
  </select>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;New Name: <input type="text" name="rename" size="40">
<P ALIGN="right"><input type="Submit" name="submit" value="Rename Query">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
</fieldset>
</form>
<?php } ?>
</body>
</html>
