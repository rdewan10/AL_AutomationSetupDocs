<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  resource_check_hw.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
include 'func.php';
mysqlSetup($db);
?>

<html>
<head>
  <title>LeapFrog HW Lab Resource Check-In/Out</title> <!-- The <title> tag denotes what is displayed on bar
                                                         at the top of the browser -->
  <link rel="stylesheet" type="text/css" href="reda.css">
</head>

<?php
bodyStyle();
$header_bg = "images/bg_hdr1.gif";
$header_font_color = "#ECF4EC";
$cell_bg = "#F0F0F0";
?>

<div id="banner"><h4><center>HW Lab Resource Check-In/Out</center></h4><h5><center><b>LeapFrog</b></center></h5></div>
<form action="resource_update_hw.php" method="post">
<br>
<div><center>
<?php
  // primary query to get info on all resources
  $query = "SELECT ResourceID,State,Name,Type,Description,User,Running,Timestamp,DurationHrs,CPB_SN,RTM_SN FROM ResourcesHW"; 

  if($_POST != NULL){
    $query .= " WHERE";
    
    // get form inputs
    while(list($key, $value) = each($_POST)){
      $input[$key] = $value;
      // add all form inputs except check-type to query
      if ($key != "check") {
        $query .= " ResourceID=$value OR";
        echo "<input type=\"hidden\" name=\"ResourceID$value\" value=\"$value\">\n";
      }
    }
    
    $query = substr($query, 0, -3);

    $result = mysql_query($query,$db);
  
    echo "<table cellpadding=2 cellspacing=2 border=0><tr>";

    // loop to print table header row
    for ($i = 1; $i < mysql_num_fields($result);$i++){

      $tableAndField = mysql_field_table($result,$i) . "." . mysql_field_name($result, $i);
    
      echo "<td BACKGROUND=\"$header_bg\"><font face=\"arial\" size=2 color=\"$header_font_color\"><b><center>";

      echo mysql_field_name($result, $i) . "</b></a></center></font></td>";
    }
     
    echo "</tr>";
      
    // assume resources are not reserved unless found otherwise later
    $reserved=0;
    $free=0;

    // loop through all rows of resources
    while($myrow = mysql_fetch_row($result)){
   
      // loop through each field for this resource
      for ($i = 0; $i < mysql_num_fields($result);$i++){

        // check if this field indicates that resource is reserved
        if ($myrow[$i] == "reserved") {
          $reserved += 1;
        } elseif ($myrow[$i] == "free") {
          $free += 1;
        }

        // check if this is the resource id and record it
        if (mysql_field_name($result, $i) == "ResourceID") {
          $resourceID = $myrow[$i];
        } elseif (mysql_field_name($result, $i) == "DurationHrs") {
          if ($myrow[$i] == "0.0") {
            echo "<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"></p></td>";
          } else {
            // print the field value
            printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
          }
        } elseif (mysql_field_name($result, $i) == "Timestamp") {
          if ($myrow[$i] == "0000-00-00 00:00:00") {
            echo "<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"></p></td>";
          } else {
            // print the field value
            printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
          }
        } else {
          printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
        }
      }

      echo "</tr>";
    }
?>
  </table><br>
  </center></div>

  <br>
  <div><center>

<?php

  echo "<table><td><font face=\"arial\" size 2>";
    
  if ($input[check] == "Free") {
    echo "<input type=\"radio\" name=\"State\" value=\"free\" checked> Free<br>";
    echo "<input type=\"radio\" name=\"State\" value=\"reserved\" disabled> Reserve<br>";
    echo "</font></td></tr></table>";
  } else {
    echo "<input type=\"radio\" name=\"State\" value=\"free\" disabled> Free<br>";
    echo "<input type=\"radio\" name=\"State\" value=\"reserved\" checked> Reserve<br>";
    echo "</font></td></tr></table>";
    echo "<br><font face=\"arial\" size=2>To receive email reminders, please enter user in format \"first . last\"</font>";
    echo "<br><br><table>";
    echo "<tr><td><font face=\"arial\" size 2>User</font></td>";
    echo "<td><input type=\"text\" name=\"User\"><br></td></tr>";
    echo "<tr><td><font face=\"arial\" size 2>Running</font></td>";
    echo "<td><input type=\"text\" name=\"Running\"><br></td></tr>";
    echo "<tr><td><font face=\"arial\" size 2>Estimated Duration (hrs)</font></td>";
    echo "<td><input type=\"text\" name=\"DurationHrs\"><br></td></tr>";
    echo "</table><br>";
  }
  echo "<font face=\"arial\" size 2>";
  echo "<button name=\"submit\" value=\"submit\" type=\"submit\">Submit</button>";
  echo "</font>";
?>

  </center></div>
  </form>
<?php

} else {
  echo "Error: you must use this page via report_status_hw.php!"; 
}
?>
</html>
