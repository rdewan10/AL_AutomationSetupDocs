<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  getreleases.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: getreleases.php
 * Purpose: This page is never seen by the user. Instead, it is called through
 *          an ajaz function in index.php and will return a list of releases
 *          associated with a particular piece of software.
 * NOTE: THIS PAGE IS MADE SPECIFICALLY FOR REDA AND WILL NOT WORK ON OTHER
 *       PROJECTS WITHOUT SOME MODIFICATIONS.
 *
 *****************************************************************************/

include 'func.php';
mysqlSetup($db);

if($_GET != NULL){
  while(list($key, $value) = each($_GET)){
    $input[$key] = $value;
  }

  $query = "SELECT DISTINCT OfficialRelease FROM Releases WHERE FieldName='" . $input["fieldName"] . "' ORDER BY OfficialRelease ASC";
  $result = mysql_query($query,$db);
  //Prints out the entire input field.
  echo "<select name='OfficialRelease" . $input["id"] . "'><option value='any'>Any</option>";
  while($release = mysql_fetch_row($result)){
    echo "<option value='" . $release[0] . "'>" . $release[0] . "</option>";
  }
  echo "</select>";
}

