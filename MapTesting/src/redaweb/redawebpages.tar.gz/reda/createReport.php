<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  createReport.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="reda.css">
		<title>Create Reda Report</title>
	</head>
	<?php
		include 'func.php';
		bodyStyle();
	?>
		<div id="banner"><h4><center>Reda 2.0</center></h4><h5><center><b>Reda Manual Report Entry</b></center></h5></div>
	<?php
		navbar1("admin");
		navbar2("admin", "");
		navbar3("manual_entry");
	?>
	</body>
	<h2>&nbsp;</h2>
	<center>
		<p style="font: normal 20px 'Arial', Arial, Sans-serif;">Test Case, Release Cycle, SMTS Software Version and UT Software Version fields are mandatory to be filled.</p>
		<h2>&nbsp;</h2>
		<form action="manualReport.php" method="post" enctype="multipart/form-data">
			<table style="font: normal 16px 'Arial', Arial, Sans-serif;" BORDER=6 CELLSPACING=6 CELLPADDING=10>
				<tbody>
					<tr>
						<td>Test Case:</td>
						<td><input type="text" maxlength="25" name="testCase" size="100">
						</td>
						<td>Release Cycle:</td>
						<td>
							<select style="width: 635px" name="releaseCycle">
							  <option value="yes">Yes</option>
							  <option value="no">No</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>SMTS Software Version:</td>
						<td><input type="text" maxlength="20" name="smtsSwVersion" size="100"></td>
                        <td>UT Software Version:</td>
                        <td><input type="text" maxlength="80" name="utSoftwareVersion" size="100"></td>
					</tr>
                    <tr>
                        <td>User:</td>
						<td><input type="text" maxlength="80" name="user" size="100"></td>
                        <td>Spec Pass/Fail:</td>
                        <td>
                            <select style="width: 635px" name="specPassFail">
                              <option value="pass">Pass</option>
                              <option value="fail">Fail</option>
                              <option value="unverified">Unverified</option>
                            </select>
                        </td>
					</tr>
					<tr>
						<td>Status:</td>
						<td>
							<select style="width: 635px" name="status">
							  <option value="complete">Complete</option>
							  <option value="running">Running</option>
							  <option value="invalid">Invalid</option>
							</select>
						</td>
						<td>Date and Time:</td>
						<td><input type="text" maxlength="80" name="dateTime" size="100"></td>
					</tr>
					<tr>
						<td>Duration Hours:</td>
						<td><input type="text" maxlength="5" name="durationHrs" size="100"></td>
						<td>Station Name:</td>
						<td><input type="text" maxlength="80" name="stationName" size="100"></td>
					</tr>
					<tr>
						<td>Station Type:</td>
						<td>
							<select style="width: 635px" name="stationName">
							  <option value="stf">BSMAC STF</option>
							  <option value="pct">BSMAC PCT</option>
							  <option value="bsmac">BSMAC to MSMAC</option>
							  <option value="g35">G35</option>
							  <option value="mac">MAC to MAC</option>
							  <option value="macPhy">MAC-PHY</option>
							  <option value="phy">PHY</option>
							</select>
						</td>
						<td>Start Time:</td>
						<td><input type="text" maxlength="25" name="startTime" size="100"></td>
					</tr>
					<tr>
						<td>SMTS Type:</td>
						<td><input type="text" maxlength="80" name="smtsType" size="100"></td>
						<td>UT Type:</td>
						<td><input type="text" maxlength="80" name="utType" size="100"></td>
					</tr>
					<tr>
						<td>Group Name:</td>
						<td><input type="text" maxlength="80" name="groupName" size="100"></td>
						<td>SAM Version:</td>
						<td><input type="text" maxlength="11" name="samVersion" size="100"></td>
					</tr>
					<tr>
						<td>SAM Station:</td>
						<td><input type="text" maxlength="40" name="samStation" size="100"></td>
						<td>SAM Run Mode:</td>
						<td><input type="text" maxlength="40" name="samRunMode" size="100"></td>
					</tr>
					<tr>
						<td>SAM Test Case:</td>
						<td><input type="text" maxlength="80" name="samTestCase" size="100"></td>
						<td>Description:</td>
						<td><input type="text" maxlength="80" name="description" size="100"></td>
					</tr>
					<tr>
						<td>UT Start Total:</td>
						<td><input type="text" maxlength="11" name="utStartTotal" size="100"></td>
						<td>UT End Total:</td>
						<td><input type="text" maxlength="11" name="utEndTotal" size="100"></td>
					</tr>
					<tr>
						<td>UT Online Total:</td>
						<td><input type="text" maxlength="11" name="utOnlineTotal" size="100"></td>
						<td>UT Online Percentage:</td>
						<td><input type="text" maxlength="11" name="utOnlinePct" size="100"></td>
					</tr>
					<tr>
						<td>MSM Start Total:</td>
						<td><input type="text" maxlength="11" name="msmStartTotal" size="100"></td>
						<td>MSM End Total:</td>
						<td><input type="text" maxlength="11" name="msmEndTotal" size="100"></td>
					</tr>
					<tr>
						<td>MSM Online Total:</td>
						<td><input type="text" maxlength="11" name="msmOnlineTotal" size="100"></td>
						<td>MSM Online Percentage:</td>
						<td><input type="text" maxlength="11" name="msmOnlinePct" size="100"></td>
					</tr>
					<tr>
						<td>User Rating:</td>
						<td>
							<select style="width: 635px" name="userRating">
							  <option value="saveForAnalysis">Save for Analysis</option>
							  <option value="criticalFailure">Critical Failure</option>
							  <option value="partiallyWorking">Partially Working/Minor Failure</option>
							  <option value="metExpectations">Met Expectations</option>
							  <option value="metSpec">Met Spec - Ship it!</option>
							</select>
						</td>
						<td>Notes:</td>
						<td><input type="text" maxlength="80" name="notes" size="100"></td>
					</tr>
					<tr>
						<td>Script Name:</td>
						<td><input type="text" maxlength="40" name="scriptName" size="100"></td>
                        <td>Result Value:</td>
                        <td><input type="text" maxlength="80" name="resultValue" size="100"></td>
					</tr>
					<tr>
						<td>Script Version:</td>
						<td><input type="text" maxlength="11" name="scriptVersion" size="100"></td>
						<td>SAM Param File:</td>
						<td><input type="text" maxlength="80" name="samParamFile" size="100"></td>
					</tr>
				</tbody>
			</table>
			<h2>&nbsp;</h2>
			<p style="font: normal 20px 'Arial', Arial, Sans-serif;">Choose a file to be uploaded. (.zip or .rar file format only)</p>
			<input type="file" name="zippedFile" style="height: 40px; width: 250px; font: normal 20px 'Arial', Arial, Sans-serif;">
			<h2>&nbsp;</h2>
			<input type="submit" value="Create Report" style="height: 40px; width: 150px; font: normal 20px 'Arial', Arial, Sans-serif;">
		</form>
	</center>
</html>
