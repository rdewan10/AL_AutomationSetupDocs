<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  resource_status.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php

include 'func.php';
mysqlSetup($db);
?>

<html>
<head>
  <title>LeapFrog Resource Status</title> <!-- The <title> tag denotes what is displayed on bar
                                                         at the top of the browser -->
  <link rel="stylesheet" type="text/css" href="reda.css">
</head>

<?php
bodyStyle();
$header_bg = "images/bg_hdr1.gif";
$header_font_color = "#ECF4EC";
$cell_bg = "#F0F0F0";
?>

<div id="banner"><h4><center>Resource Status</center></h4><h5><center><b>LeapFrog</b></center></h5></div>
<br>
<a href="file://///C:/Perforce/Broadband/TestTools/SAM/leapfrog/config/IndexFiles/DeviceIndex.csv">Terminal Server Info (must sync C:/Perforce/Broadband/TestTools/SAM/leapfrog/config/IndexFiles/DeviceIndex.csv)<a>
<br>
<a href="http://share.hq.corp.viasat.com/leapfrog/Technical/NetworkSimulator/Documents/PHY Simulator/PhySim Execution Instructions.doc">PhySim Documentation<a>
<br>
<br>
<div><center>

<p align=left><b>Filter by Lab</b></p>
<?php
  $query = "SELECT DISTINCT Lab FROM Resources"; 
  $result = mysql_query($query,$db);
  while($myrow = mysql_fetch_row($result)){
    echo "<p align=left><a href=\"resource_status.php?lab=$myrow[0]\">$myrow[0]</a></p>";
  }
  echo "<p align=left><a href=\"resource_status.php\">Clear</a></p>";
?>
<br>
<form action="resource_check.php" name=input_form method="post">
<table cellpadding=2 cellspacing=2 border=0>
<tr>
<?php
  // primary query to get info on all resources
  $query = "SELECT ResourceID,State,Lab,Name,Type,Description,User,Running,Notes,Timestamp,DurationHrs FROM Resources"; 
  
  // check if we have a sort request
  if($_GET != NULL){
    while(list($key, $value) = each($_GET)){
      $input[$key] = $value;
    }
 
    // append lab filter to query 
    if(isset($input["lab"])) {
      $query .= " WHERE Lab='" . $input["lab"] . "' ";
      $labInput = "lab=$input[lab]&";
    } else {
      $labInput = "";
    }

    // append sort order to query
    if(isset($input["sortasc"])) {
      $query .= " ORDER BY " . $input["sortasc"] . " ASC";
    } elseif (isset($input["sortdesc"])) {
      $query .= " ORDER BY " . $input["sortdesc"] . " DESC";
    } else {
      $query .= " ORDER BY Resources.State, Resources.Type, Resources.Description, Resources.Name ASC";
    }
  } else {
      $query .= " ORDER BY Resources.State, Resources.Type, Resources.Description, Resources.Name ASC";
  }

  $result = mysql_query($query,$db);
  
  echo "<td BACKGROUND=\"$header_bg\"><font face=\"arial\" size=2 color=\"$header_font_color\"><b><center>Select</center></td>";

  // loop to print table header row
  for ($i = 1; $i < mysql_num_fields($result);$i++){

    $tableAndField = mysql_field_table($result,$i) . "." . mysql_field_name($result, $i);

    // decide what sort link to use for each column
    if(isset($input["sortasc"]) && ($tableAndField==$input["sortasc"])) {
      echo "<td BACKGROUND=\"$header_bg\"><font face=\"arial\" size=2 color=\"$header_font_color\"><b><center>
            <a href=\"resource_status.php?$labInput" . "sortdesc=";
    } else {
      echo "<td BACKGROUND=\"$header_bg\"><font face=\"arial\" size=2 color=\"$header_font_color\"><b><center>
            <a href=\"resource_status.php?$labInput" . "sortasc=";
    }

    // add table name to link
    if(mysql_field_table($result, $i)){
      echo mysql_field_table($result, $i) . ".";
    }
    // add field name to link, and field name to display in cell
    echo mysql_field_name($result, $i) . "\">" . mysql_field_name($result, $i) . "</b>";
    echo "</a></center></font></td>";
  }
     
  echo "<td BACKGROUND=\"$header_bg\"><font face=\"arial\" size=2 color=\"$header_font_color\"><b><center>RemainingHrs</center></td>";
  echo "</tr>";

  // loop through all rows of resources
  while($myrow = mysql_fetch_row($result)){
   
    // assume resources is not reserved unless found otherwise later
    $reserved=0;
      


    // loop through each field for this resource
    for ($i = 0; $i < mysql_num_fields($result);$i++){
    
      // check if this field indicates that resource is reserved
      if ($myrow[$i] == "reserved") {
        $reserved = 1;
        $color = red;	
      } elseif ($myrow[$i] == "free") {
        $color = green;
      } else {
        $color = black;
      }

      // check if this is the resource id and record it
      if (mysql_field_name($result, $i) == "ResourceID") {
        $resourceID = $myrow[$i];
        // add checkbox
        echo "<td bgcolor=\"$cell_bg\"><p class=\"table\"><INPUT TYPE=CHECKBOX NAME=\"$resourceID\" VALUE=\"$resourceID\"></p></td>";
      } elseif (mysql_field_name($result, $i) == "DurationHrs") {
        if ($myrow[$i] == "0.0") {
          echo "<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"></p></td>";
          $duration = 0;
        } else {
	  // print the field value
	  printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
          $duration = $myrow[$i];
        }
      } elseif (mysql_field_name($result, $i) == "Timestamp") {
        if ($myrow[$i] == "0000-00-00 00:00:00") {
          echo "<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"></p></td>";
          $timestamp = 'none';
        } else {
	  // print the field value
	  printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
          $timestamp = $myrow[$i];
        }
      } elseif (mysql_field_name($result, $i) == "Name") {
        $resourceName=$myrow[$i];
        printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2> <p class=\"table\"><a href=http://wiki.viasat.com/display/LEAP/Lab#Lab-%s>%s</a></p></td>", $myrow[$i], $myrow[$i]);
      } elseif (mysql_field_name($result, $i) == "Type") {
        $resourceType=$myrow[$i];
        printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
      } elseif (mysql_field_name($result, $i) == "Description") {
        $resourceDescr=$myrow[$i];
        printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
      } elseif (mysql_field_name($result, $i) == "User") {
        printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2> <p class=\"table\"><a href=\"mailto:%s?subject=Resource Reservation\">%s</a></p></td>", $myrow[$i], $myrow[$i]);
      } else {
        printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %s </p></td>", $myrow[$i]);
      }
    }
 
    if (($duration != 0) && ($timestamp != 'none')) {
      $time_remaining = $duration - (strtotime('now') - strtotime($timestamp))/3600.0;
      if ($time_remaining < 0) {
        printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=red> <p class=\"table\">expired</p></td>");
      } else {
        printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"> %.1f </p></td>", $time_remaining);
      }
    } else {
      printf("<td bgcolor=\"$cell_bg\"><font face=\"arial\" size=2 color=\"$color\"> <p class=\"table\"></p></td>");
    }
 
    echo "</tr>";
  }
?>
</table><br>
<button name="check" value="Reserve" type="submit">Reserve/Renew</button>
<button name="check" value="Free" type="submit">Free</button>
</form>
</center></div>
<?php
//echo "$query";
//echo "<br>";
//echo "$row_query";
//echo "<br>";
//echo "$grp_query";
?>
</html>
