<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  status.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>

<?php
include 'func.php';
mysqlSetup($db);

?>

<!--
All webpages must start with <html> and usually have <head> tags.
-->
<html>
<head>
  <title>ReDa: LeapFrog Test Results Database</title> <!-- The <title> tag denotes what is displayed on bar
                                                         at the top of the browser -->
  <link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
bodyStyle();
banner();
navbar1("");
?> <!-- be sure to close php code with ?> -->
<br> <!-- <br> tag (short for break) is used to start a new line. NOTE: HTML WILL IGNORE WHITESPACES, INCLUDING NEWLINES, UNLESS YOU SPECIFIY A NEW LINE WITH <br>. -->
<?php
if($_GET != NULL){
  //Pull in the GET values. (which is just ID or GrpID)
  while(list($key, $value) = each($_GET)){
    $input[$key] = $value;
  }


  echo "<h2><center><font color=\"006699\">Release Report</font></center></h2>";
  echo "<div class='post'><h1>Release Summary</h1>";
  echo "<br>";
  $releaseCriteria= array();
  for($i=0;$i<$input['maxSelections'];$i++){
    if(isset($input["OfficialRelease" . $i]) && $input["OfficialRelease" . $i]!='any'){
      $releaseCriteria[$input['FieldName' . $i]]=$input["OfficialRelease" . $i];
    }
  }
  echo "<p><font color=\"006699\">Release Identification</font></p>";
  echo "<table>";
  if(isset($releaseCriteria['SmSoftwareVersion']) && 
     $releaseCriteria['SmSoftwareVersion']!='any' && 
     (!isset($releaseCriteria['SmtsSoftwareVersion']) || $releaseCriteria['SmtsSoftwareVersion']=='any')){
     echo "<tr><td><p>SM Release</p></td><td><p>" . $releaseCriteria['SmSoftwareVersion'] . "</p></td></tr>";
     //A specific SM software version is selected, but SMTS is not.
    $query = "SELECT OfficialRelease FROM Releases WHERE OfficialRelease<'" . $releaseCriteria['SmSoftwareVersion'] . "' AND FieldName='SmSoftwareVersion' ORDER BY OfficialRelease DESC LIMIT 1";
    $result = mysql_query($query,$db);
    $row = mysql_fetch_row($result);
    if($row!=NULL){
      $prevRelease=$row[0];
      $query = "SELECT OfficialRelease 
                FROM Releases 
                WHERE OfficialRelease>'" . $prevRelease . "' AND 
                      OfficialRelease<='" . $releaseCriteria['SmSoftwareVersion'] . "' AND 
                      FieldName='SmtsSoftwareVersion'";
      $result = mysql_query($query,$db);
      if(mysql_num_rows($result)!=0){
        //Print out all the SMTS releases associated with this SM release.
        $stringRelease = "";
        while($release = mysql_fetch_row($result)){
           $stringRelease .= $release[0] . ",";
        }
        $stringRelease=substr($stringRelease,0,-1);
        echo "<tr><td><p>SMTS Release</p></td><td><p>" . $stringRelease . "</p></td></tr>";
      } else {
        $query = "SELECT OfficialRelease
                FROM Releases
                WHERE OfficialRelease<='" . $releaseCriteria['SmSoftwareVersion'] . "' AND
                      FieldName='SmtsSoftwareVersion' ORDER BY OfficialRelease DESC LIMIT 1";
        $result = mysql_query($query,$db);
        if(mysql_num_rows($result)!=0){
          //Print out all the SMTS releases associated with this SM release.
          $release = mysql_fetch_row($result);
          echo "<tr><td><p>SMTS Release</p></td><td><p>" . $release[0] . "</p></td></tr>";
        } else {
          echo "<tr><td><p>SMTS Release</p></td><td><p>Unknown</p></td></tr>"; 
        }
      }
    } else {
      $query = "SELECT OfficialRelease
                FROM Releases
                WHERE OfficialRelease<='" . $releaseCriteria['SmSoftwareVersion'] . "' AND
                      FieldName='SmtsSoftwareVersion' ORDER BY OfficialRelease DESC LIMIT 1";
      $result = mysql_query($query,$db);
      if(mysql_num_rows($result)!=0){
        //Print out all the SMTS releases associated with this SM release.
        $release = mysql_fetch_row($result);
        echo "<tr><td><p>SMTS Release</p></td><td><p>" . $release[0] . "</p></td></tr>";
      } else {
        echo "<tr><td><p>SMTS Release</p></td><td><p>Unknown</p></td></tr>";
      }
    } 
  } elseif ((!isset($releaseCriteria['SmSoftwareVersion']) || $releaseCriteria['SmSoftwareVersion']=='any') &&
            isset($releaseCriteria['SmtsSoftwareVersion']) && $releaseCriteria['SmtsSoftwareVersion']!='any'){
    $query = "SELECT OfficialRelease FROM Releases WHERE OfficialRelease<'" . $releaseCriteria['SmtsSoftwareVersion'] . "' AND FieldName='SmtsSoftwareVersion' ORDER BY OfficialRelease DESC LIMIT 1";
    $result = mysql_query($query,$db);
    $row = mysql_fetch_row($result);
    if($row!=NULL){
      $prevRelease=$row[0];
      $query = "SELECT OfficialRelease
                FROM Releases
                WHERE OfficialRelease>'" . $prevRelease . "' AND
                      OfficialRelease<='" . $releaseCriteria['SmtsSoftwareVersion'] . "' AND
                      FieldName='SmSoftwareVersion'";
      $result = mysql_query($query,$db);
      if(mysql_num_rows($result)!=0){
        //Print out all the SMTS releases associated with this SM release.
        $stringRelease = "";
        while($release = mysql_fetch_row($result)){
           $stringRelease .= $release[0] . ",";
        }
        $stringRelease=substr($stringRelease,0,-1);
        echo "<tr><td><p>SM Release</p></td><td><p>" . $stringRelease . "</p></td></tr>";
      } else {
        $query = "SELECT OfficialRelease
                FROM Releases
                WHERE OfficialRelease<='" . $releaseCriteria['SmtsSoftwareVersion'] . "' AND
                      FieldName='SmSoftwareVersion' ORDER BY OfficialRelease DESC LIMIT 1";
        $result = mysql_query($query,$db);
        if(mysql_num_rows($result)!=0){
          //Print out all the SMTS releases associated with this SM release.
          $release = mysql_fetch_row($result);
          echo "<tr><td><p>SM Release</p></td><td><p>" . $release[0] . "</p></td></tr>";
        } else {
          echo "<tr><td><p>SM Release</p></td><td><p>Unknown</p></td></tr>";
        }
      }
    } else {
      $query = "SELECT OfficialRelease
                FROM Releases
                WHERE OfficialRelease<='" . $releaseCriteria['SmtsSoftwareVersion'] . "' AND
                      FieldName='SmSoftwareVersion' ORDER BY OfficialRelease DESC LIMIT 1";
      $result = mysql_query($query,$db);
      if(mysql_num_rows($result)!=0){
        //Print out all the SMTS releases associated with this SM release.
        $release = mysql_fetch_row($result);
        echo "<tr><td><p>SM Release</p></td><td><p>" . $release[0] . "</p></td></tr>";
      } else {
        echo "<tr><td><p>SM Release</p></td><td><p>Unknown</p></td></tr>";
      }
    }
    echo "<tr><td><p>SMTS Release</p></td><td><p>" . $releaseCriteria['SmtsSoftwareVersion'] . "</p></td></tr>";
  } elseif ((!isset($releaseCriteria['SmSoftwareVersion']) || $releaseCriteria['SmSoftwareVersion']=='any') &&
            (!isset($releaseCriteria['SmtsSoftwareVersion']) || $releaseCriteria['SmtsSoftwareVersion']=='any')){ //I.E. no selection
    echo "<tr><td><p>SM Release</p></td><td><p>All</p></td></tr>";
    echo "<tr><td><p>SMTS Release</p></td><td><p>All</p></td></tr>";
  } else { //Both are specified.
    echo "<tr><td><p>SM Release</p></td><td><p>" . $releaseCriteria['SmSoftwareVersion'] . "</p></td></tr>";
    echo "<tr><td><p>SMTS Release</p></td><td><p>" . $releaseCriteria['SmtsSoftwareVersion'] . "</p></td></tr>";
  }

  echo "</table><br>";
  $getSXRs   = "SELECT DISTINCT SXR
                FROM TestConfig,
                     RelatedSXRs
                WHERE SmtsSoftwareVersion REGEXP 'smtsApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                      SmSoftwareVersion REGEXP 'smApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                      Status!='invalid' AND
                      TestConfig.GrpID=RelatedSXRs.GrpID";
  $findHours = "SELECT SUM(DurationHrs)
                FROM TestConfig
                WHERE SmtsSoftwareVersion REGEXP 'smtsApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                      SmSoftwareVersion REGEXP 'smApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                      Status!='invalid'";
  $dateRange = "SELECT MIN(Date),MAX(Date)
                FROM TestConfig
                WHERE SmtsSoftwareVersion REGEXP 'smtsApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                      SmSoftwareVersion REGEXP 'smApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                      Status!='invalid'";
  $showTests = "SELECT tc1.GrpID,
                       tc1.TestID,
                       tc1.TestName,
                       TestPassFail,
                       tc1.Date,
                       tc1.Time,
                       SmtsSoftwareVersion,
                       SmSoftwareVersion,
                       GroupConfig.Description,
                       GroupResultsSummary.Notes
                FROM TestConfig as tc1,
                     TestResultsSummary,
                     GroupConfig,
                     GroupResultsSummary,
                     (SELECT ";
  if($input["show"]=="recent"){
    $showTests.="     max(tc2.TestID) as maxID,";
  } else { 
    $showTests.="     tc2.TestID as maxID,";
  }
  $showTests.="       tc2.TestName
                      FROM TestConfig as tc2
                      WHERE SmtsSoftwareVersion REGEXP 'smtsApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                            SmSoftwareVersion REGEXP 'smApp-R[0-9][0-9][0-9]_B[0-9][0-9][0-9]*' AND
                            Status!='invalid'";

  $releaseCriteria= array();
  for($i=0;$i<$input['maxSelections'];$i++){
    if(isset($input["OfficialRelease" . $i]) && $input["OfficialRelease" . $i]!='any'){
      $releaseCriteria[$input['FieldName' . $i]]=$input["OfficialRelease" . $i];
      if($input['FieldName' . $i]=="SmtsSoftwareVersion"){
        $releaseIndex=10;
        $buildIndex=15;
      } else {
        $releaseIndex=8;
        $buildIndex=13;
      }

      $query = "SELECT Version,Build FROM Releases WHERE OfficialRelease='" . $input["OfficialRelease" . $i] . "' AND FieldName='" . $input['FieldName' . $i] . "'";

      $result = mysql_query($query,$db);
      $row = mysql_fetch_row($result);
      $myVersion=$row[0];
      $myBuild=$row[1];
  
      $query = "SELECT Version,Build FROM Releases WHERE OfficialRelease<'" . $input["OfficialRelease" . $i] . "' AND FieldName='" . $input['FieldName' . $i] . "' ORDER BY OfficialRelease DESC LIMIT 1";
      $result = mysql_query($query,$db);
      $row = mysql_fetch_row($result);
      if($row!=NULL){
        $prevVersion=$row[0];
        $prevBuild=$row[1];

        if($prevVersion==$myVersion){
          $getSXRs .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $prevVersion . $prevBuild . " AND " .  $myVersion . $myBuild;
          $findHours .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $prevVersion . $prevBuild . " AND " .  $myVersion . $myBuild;
          $dateRange .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $prevVersion . $prevBuild . " AND " .  $myVersion . $myBuild;
          $showTests .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $prevVersion . $prevBuild . " AND " .  $myVersion . $myBuild;
        } else {
          $getSXRs .=" AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
          $findHours .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
          $dateRange .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
          $showTests .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
        }
      } else {
        $getSXRs .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
        $findHours .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
        $dateRange .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
        $showTests .= " AND CONCAT(SUBSTR(" . $input['FieldName' . $i] . "," . $releaseIndex . ",3),SUBSTR(" . $input['FieldName' . $i] . "," . $buildIndex . ",3)) BETWEEN " . $myVersion . "000 AND " .  $myVersion . $myBuild;
      }
    }
  }

  $result = mysql_query($getSXRs,$db);
  echo "<p><font color=\"006699\">Related SXRs</font></p><table>";
  if(mysql_num_rows($result)==0){
    echo "<tr><td><p>none</p></td>";
  }

  $col=0;
  while($sxr = mysql_fetch_row($result)){
    if($col==0)
      echo "<tr>";
    echo "<td><p><a href=\"http://vcateam01/scripts/texcel/devtrack/BugInfo.dll?OnePage?97&1&" . $sxr[0] ."&0&0&0&1\">" . $sxr[0] . "</a></p></td>";
    if($col==4)
      echo "</tr>";
    $col=($col+1)%5;
  }
  echo "</table>";

  if($input["show"]=="recent"){
    $showTests.="    GROUP BY tc2.TestName";
  }
  $showTests.=") as temptable
               WHERE temptable.maxID=tc1.TestID AND
                     tc1.TestID=TestResultsSummary.TestID AND
                     tc1.GrpID=GroupConfig.GrpID AND 
                     tc1.GrpID=GroupResultsSummary.GrpID
               ORDER BY TestPassFail DESC,tc1.TestName";

  $result = mysql_query($showTests,$db);
  $testid_index=1;
  $grpid_index=0;
  $numCompletedTests=mysql_num_rows($result);

  $resultsArray = array();
  $testsCompleted = array();
  $numPassed=0;
  $numFailed=0;
  $numUnknown=0;
  $numNotExecuted=0;

  while($tuple = mysql_fetch_row($result)){
    $resultsArray[] = $tuple;
    $testsCompleted[] = $tuple[2];
    if($tuple[3]=="pass"){
      $numPassed++;
    } elseif($tuple[3]=="FAIL"){
      $numFailed++;
    } else {
      $numUnknown++;
    }
  }

  $query = "SELECT DISTINCT TestName FROM TestConfig WHERE Date>'2008-01-01' ORDER BY TestName";
  $result = mysql_query($query,$db);
  while($test = mysql_fetch_row($result)){
    if(!in_array($test[0],$testsCompleted)){
      $numNotExecuted++;
    }
  }

  echo "<br><p><font color=\"006699\">Test Coverage Summary</font></p><table>";
  echo "<tr><td><p><b>Tests Completed</b></p></td><td><p><b>" . $numCompletedTests . "</b></p></td></tr>";
  echo "<tr><td><p>&nbsp;&nbsp;&nbsp;&nbsp;Passed</p></td><td><p>" . $numPassed . "</p></td></tr>";
  echo "<tr><td><p>&nbsp;&nbsp;&nbsp;&nbsp;Failed</p></td><td><p>" . $numFailed . "</p></td></tr>";
  echo "<tr><td><p>&nbsp;&nbsp;&nbsp;&nbsp;Unknown</p></td><td><p>" . $numUnknown . "</p></td></tr>";
  echo "<tr><td><p>Tests Not Executed</p></td><td><p>" . $numNotExecuted . "</p></td></tr>";
  echo "</table>";
  echo "<br>";

  echo "<br><p><font color=\"006699\">Test Duration Summary</font></p><table>";
  
  $result = mysql_query($findHours,$db);
  $hours = mysql_fetch_row($result);
  echo "<tr><td><p>Total Hours Testing</p></td><td><p>" . $hours[0] . "</p></td></tr>";

  $result = mysql_query($dateRange,$db);
  $dates = mysql_fetch_row($result);
  echo "<tr><td><p>Testing Started</p></td><td><p>" . $dates[0] . "</p></td></tr>";
  echo "<tr><td><p>Testing Finished</p></td><td><p>" . $dates[1] . "</p></td></tr>";
  echo "</table>";
  echo "<br>";

  echo "</div>";

  $result = mysql_query($showTests,$db);
  echo "<div class='post'><h1>Tests Completed</h1>";
  echo "<br>";
  echo "<table border=0>";
  echo "<tr>";

  for($i=0;$i<mysql_num_fields($result);$i++){
    echo "<td BACKGROUND=\"cellpic1.gif\"><center><font face=\"arial\" size=2><font color=\"006699\"><b>" . mysql_field_name($result,$i) . "</b></font></center></td>";
  }
  echo "</tr>";

  $testsCompleted = array();
  while($tuple = mysql_fetch_row($result)){
    echo "<tr>";
    for($i=0;$i<mysql_num_fields($result);$i++){
      if(mysql_field_name($result,$i)=="TestName"){
        $testsCompleted[] = $tuple[$i];
      }
      if ($i == $testid_index){
        $grpResult = mysql_query("SELECT $grpIDField FROM $testLevelTableName WHERE $testIDField=" . $tuple[$i],$db);
        $temp_row = mysql_fetch_row($grpResult);
        $grpID=$temp_row[0];
        printf("<td bgcolor=\"F5F5F5\"><font size=2><a href=\"report.php?grpID=%s\"><b><center>%s</center></b></a></font></td>",$grpID,$tuple[$i]);
      } elseif ($i == $grpid_index){
        echo "<td bgcolor=\"F5F5F5\"><font size=2><a href=\"results.php?query=SELECT " . getDefaultFields() .
             " FROM " . getDefaultTables() . " WHERE ((" . tableLink(getDefaultTablesAsArray()) .
             ")) AND $grpLevelTableName.$grpIDField=" . $tuple[$i] . "\"><b><center>" . $tuple[$i] . "</center></b></a></font></td>";
      } else {
        echo "<td bgcolor=\"F5F5F5\"><center><p>" . $tuple[$i] . "</p></center></td>";
      }
    }
    echo "</tr>";
  }

  echo "</table><br>";
  echo "</div>";
  echo "<div class='post'><h1>Tests Not Executed</h1>";
  echo "<table width='400px'>";
  $query = "SELECT DISTINCT TestName FROM TestConfig WHERE Date>'2008-01-01' ORDER BY TestName";
  $result = mysql_query($query,$db);

  $odd=FALSE;
  while($test = mysql_fetch_row($result)){
    if(!$odd){
      echo "<tr>";
    }
    if(!in_array($test[0],$testsCompleted)){
      if(!$odd){
        echo "<tr>";
      }
      echo "<td><p>" . $test[0] . "</p></td>";
      if($odd){
        echo "</tr>";
      }
      $odd=!$odd;
    }
  }
  echo "</table>";
  echo "</div>";

}

?>
