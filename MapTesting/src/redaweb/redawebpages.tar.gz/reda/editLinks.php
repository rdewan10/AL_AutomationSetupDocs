<?php
/*
 * ---------------------------------------------------------------
 *
 * File:  editLinks.php
 *
 * Classification:  UNCLASSIFIED
 *
 * Copyright (C) 2013 ViaSat, Inc.
 *
 * All rights reserved.
 * The information in this software is subject to change without notice and
 * should not be construed as a commitment by ViaSat, Inc.
 *
 * ViaSat Proprietary
 * The information provided herein is proprietary to ViaSat and
 * must be protected from further distribution and use. Disclosure to others,
 * use or copying without express written authorization of ViaSat, is strictly
 * prohibited.
 *
 * ---------------------------------------------------------------
 */
?>
<?php
/******************************************************************************
 *
 & Filename: edit.php
 * Purpose: This page is used to edit some fields of a test result. The fields 
 *          that can be edited should be specified in the func.php file.
 *
 *****************************************************************************/
include 'func.php';

mysqlSetup($db);
?>
<!-- Refer to the comments in index.php for help with basic html and help with the title/nav bars. -->
<html>
<head>
<title>Editing Linked Groups</title>
<link rel="stylesheet" type="text/css" href="reda.css">
</head>
<?php
//Header, navigation bar, etc.
bodyStyle();
banner();
navbar1("help");
navbar2("admin", "");
navbar3("editLink");
?>
<br><br>
<?php

if($_GET != NULL){
    //Pull in the GET values. (which is just ID or GrpID)
    while(list($key, $value) = each($_GET)){
        $input[$key] = $value;
    }
    $grpID = $input["grpID"];
    $action = $input["action"];
    $addedGroup = $input["addedGroup"];
    $deletedGroup = $input["deletedGroup"];
    $confirm = $input["confirm"];
    $result = mysql_query("SELECT LinkedSet FROM GroupInfo WHERE GrpID=".$grpID,$db);
    $linkId =  mysql_fetch_row($result);
    //if there is no linking information for this group
    if ( $linkId[0]=="" ) {
        //get the highest link set id
        $result = mysql_query("SELECT MAX(LinkedSet) FROM GroupInfo",$db);
        $maxId =  mysql_fetch_row($result);
        $newId = $maxId[0]+1;
        //then update the groupconfig with a new unused id
        $result = mysql_query("UPDATE GroupInfo SET LinkedSet=".$newId." WHERE GroupInfo.GrpID=".$grpID." LIMIT 1",$db);
        $result = mysql_query("SELECT LinkedSet FROM GroupInfo WHERE GrpID=".$grpID,$db);
        $linkId =  mysql_fetch_row($result);
    }
    if ($addedGroup != "") {
        //check to see if the group to be added is part of a linked set already.  if so, display a confirmation first
        $result = mysql_query("SELECT LinkedSet FROM GroupInfo WHERE GrpID=".$addedGroup,$db);
        $prevLinkId =  mysql_fetch_row($result);
        if ( $prevLinkId[0] != "" && $confirm == "" ) {
            echo "Group ID $addedGroup is already a part of linked set <a href=\"editLinks.php?grpID=$addedGroup\">$prevLinkId[0]</a>.  Really change its linked group?<br>\n";
            echo "<form method =\"get\" action=\"editLinks.php\">\n";
            echo "<input type=\"hidden\" name=\"grpID\" value=\"$grpID\">\n";
            echo "<input type=\"hidden\" name=\"action\" value=\"$action\">\n";
            echo "<input type=\"hidden\" name=\"addedGroup\" value=\"$addedGroup\">\n";
            echo "<input type=\"hidden\" name=\"confirm\" value=\"true\">\n";
            echo "<input type=\"submit\" value=\"Confirm\"></form>";
        } else {
            $result = mysql_query("UPDATE GroupInfo SET LinkedSet=$linkId[0] WHERE GroupInfo.GrpID=".$addedGroup." LIMIT 1",$db);        
            echo "Added group $addedGroup to linked set $linkId[0]\n";
        }
    }
    if ($action=="delete") {        
        $result = mysql_query("UPDATE GroupInfo SET LinkedSet=NULL WHERE GroupInfo.GrpID=".$deletedGroup." LIMIT 1",$db);
        echo "Deleted group $deletedGroup from linked set $linkId[0]\n";
    }
?>

  <div class="post">
  <h1><b>Related Groups for Linked Set <?php echo $linkId[0]; ?></b></h1>  
  <table>
<?php
    $result = mysql_query("SELECT GrpID FROM GroupInfo WHERE LinkedSet=".$linkId[0],$db);
    while ($singleGrpId =  mysql_fetch_row($result)) {
        echo "<tr><td><a href=\"report.php?grpID=$singleGrpId[0]\">".$singleGrpId[0]."</td>";
        echo "<td><a href=\"editLinks.php?action=delete&deletedGroup=$singleGrpId[0]&grpID=".$grpID."\"><img alt=\"Delete\" src=\"images/b_drop.png\" border=\"0\"/></td></tr>";
    }
    echo "</table>";
    echo "<form method =\"get\" action=\"editLinks.php\">\n";
    echo "<input type=\"text\" size=5 name=\"addedGroup\">\n";
    echo "<input type=\"hidden\" name=\"grpID\" value=\"$grpID\">\n";
    echo "<input type=\"submit\" value=\"Add Group\">\n";
    echo "</form><br>\n";
    echo "<form method =\"get\" action=\"report.php\">\n";
    echo "<input type=\"hidden\" name=\"grpID\" value=\"$grpID\">\n";
    echo "<input type=\"submit\" value=\"   Done   \">\n";
    echo "</form>\n";
    echo "</div>\n";
} else {
  ?>
  <form method="get" action="editLinks.php">
  Enter the GroupID of the entry you wish to edit: 
  <input type="Text" name="grpID">
  <input type="Submit" name="submit" value="Edit">
  </form>
  <?php
}
?>

</body>
</html>
